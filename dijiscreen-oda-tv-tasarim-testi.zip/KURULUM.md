# Oda televizyonu test tasarımı

ZIP içindeki hotel-tv klasörünün içeriğini test sunucusundaki mevcut server/public/hotel-tv/ klasörüne birlikte yükleyin. Yönetimden **Hotel TV → TV Önizlemesi** ekranını açın ve oteli seçin. **Örnek misafirle test et** bağlantısı kurgusal Deniz Yılmaz ismini gösterir. **Misafir ekranını aç** bağlantısı genel karşılama ekranını açar.

Canlı TV ilk açılışta odaktadır. OK ile kanal listesine girin. Yukarı ve aşağı ile kanal değiştirin. OK yayını tam ekrana alır. Geri ile önce listeye, sonra ana ekrana dönün. Kanal isimleri mevcut TV Modülleri kayıtlarından gelir. Tarayıcının medya formatı desteği ve otomatik oynatma ayarları yayına göre değişebilir.

Otele özel PNG logoyu aynı klasöre tv-logo-OTEL_ID.png adıyla koyabilirsiniz. Örneğin otel kimliği 1 ise tv-logo-1.png. Logo eklenene kadar otelin adı görünür. Arka plan için örnek oda fotoğrafı kullanılır. Kaynak [Unsplash oda fotoğrafı](https://images.unsplash.com/photo-1611892440504-42a792e24d32) ve [Unsplash License](https://unsplash.com/license).

Gerçek rezervasyon adının ekranda gösterilmesi oda bazında yetkilendirilmiş bir bağlantı gerektirir. Bu paket mevcut otel bağlantısını kullanır ve denemede örnek isim dışında misafir verisi yüklemez. SQL, cron veya APK değişikliği gerekmez.

1920×1080 Chromium, yerel MariaDB ve örnek video ile ana ekran, demo bağlantısı, varsayılan kart odağı, kanal seçimi, oynatma önizlemesi, tam ekran ve Geri doğrulandı. Fiziksel TV kumandası ve gerçek yayın kaynakları test sunucusunda ayrıca denenecek.
