# DijiScreen evrensel PMS ve oda TV güncellemesi

Bu paket PMS/oda eşleştirme paketinin üzerine uygulanır. Önce test veritabanına migrations/003_hotel_pms_universal.sql geçişini uygulayın. Ardından hotel-tv içeriğini test sunucusundaki server/public/hotel-tv/ klasörüne yükleyin. Mevcut 001 ve 002 geçişleri önceki otel yetkileri ve televizyon eşleştirmesi için gereklidir.

## Yönetim

Hotel TV → PMS → Sağlayıcı seçimi ve olay kuyruğu üzerinden oteli, sağlayıcıyı ve veri alma yöntemini seçip test bağlantısı oluşturun. Bağlantı durumu, son alım, son hazırlık, bekleyen olaylar ve son işleme denemeleri aynı ekrandadır. Otel yöneticileri kendi otellerinin bağlantılarını görür. Sistem yöneticisi mevcut PMS Kurulum ekranında harici oda kodlarını yerel odalara eşler.

Cloudbeds, Mews, Oracle OPERA Cloud ve Diğer PMS test profilleri standart giriş sözleşmesini kullanır. Sağlayıcıların kendi API'leriyle iletişim, izinler ve native webhook doğrulaması bu paketle etkinleştirilmez. Önceki PMS sayfaları ve webhook uç noktaları kullanılabilir.

## Standart giriş sözleşmesi

Olay türleri reservation.created, reservation.updated, guest.checked_in, guest.checked_out, room.changed ve guest.updated. Her olay bir rezervasyona bağlıdır. Örnekle aynı veri yapısını kullanın:

```json
{
  "event_id": "demo-001",
  "type": "room.changed",
  "reservation_id": "reservation-001",
  "occurred_at": "2026-11-19T15:20:00+03:00",
  "room_id": "202",
  "previous_room_id": "201",
  "guest_id": "guest-001",
  "guest_name": "Örnek Misafir",
  "arrival_at": "2026-11-19T14:00:00+03:00",
  "departure_at": "2026-11-20T11:00:00+03:00"
}
```

arrival_at ve departure_at isteğe bağlıdır. previous_room_id sadece oda değişiminde zorunludur. Sağlayıcı kimlikleri metin olmalıdır. ISO 8601 tarihlerinde saat dilimi zorunludur.

- **Kontrollü içe aktarma** olay nesnelerinin JSON dizisini kabul eder. Doğrula ve önizle düğmesinin ardından aynı içerik onaylanır.
- **Webhook** POST pms_event_receive.php?connection_id=ID&channel=webhook tek olay nesnesi kabul eder.
- **API** POST pms_event_receive.php?connection_id=ID&channel=api en fazla 50 nesne içeren bir `{"events":[...]}` kabul eder. Bu alıcı API'dir. Sağlayıcıdan otomatik veri çeken bağlayıcı ayrıca yazılır.

HTTP girişinde istek gövdesi 64 KiB ile sınırlıdır. Her bağlantı ve kanalın ayrı imza anahtarı sunucu tarafından HMAC-SHA256 ile türetilir. Türetilen anahtar, sunucu app_key değeri ile `hotel-pms-universal:v1:ID:CHANNEL` metninin HMAC-SHA256 değerinin küçük harfli onaltılık gösterimidir. Bağlayıcıya yalnızca ilgili bağlantının türetilmiş anahtarını güvenli kanaldan verin. app_key sunucuda kalır. X-Diji-Timestamp başlığı Unix saniyesini, X-Diji-Signature başlığı ise bu türetilmiş anahtarla `timestamp.ham_gövde` dizisinin HMAC-SHA256 değerini (küçük harfli hex) taşır. Gövde, imzalandıktan sonra değiştirilmemelidir.

Yeni olay HTTP 202, aynı standart içerikle tekrar HTTP 200, aynı kimlikle farklı içerik HTTP 409 döndürür. Bir toplu istekte kimlik çatışması varsa istek içindeki yeni kayıtlar da geri alınır. Bağlantıyı kapatmak yeni alımı ve kuyruk işlemeyi durdurur.

## Kuyruk ve sağlayıcı uzantıları

Test ortamında PHP CLI ile pms_event_worker.php çalıştırılır. Bir çalıştırma en fazla 100 kayıt işler. Kilit zaman aşımı ve deadlock gibi geçici hatalar gecikmeli ve en fazla beş işleme denemesiyle ele alınır. Oda eşlemesi eksikse eşleme düzeltildikten sonra yönetim ekranından yeniden kuyruğa alınabilir. Kuyruk ve hazırlık kaydı aynı veritabanı işlemi içinde güncellenir.

pms/adapters.php içindeki HtvPmsAdapter sözleşmesi sağlayıcıya özel dönüştürücülerin giriş noktasıdır. Yeni bağlayıcı için sağlayıcının olay kimliği, kalıcı rezervasyon kimliği, saat dilimi, olay anlamları ve yetkilendirmesi test hesabıyla doğrulanır. Yerel testte dört profil standart bağlayıcıyı kullanır. Profil adlarının varlığı sağlayıcı bağlantısının doğrulandığı anlamına gelmez.

Olay zamanları ortak kuyrukta UTC tutulur. Eski hazırlık ekranı için giriş ve çıkış saatleri otelin saat dilimine çevrilir. İşleyici mevcut hazırlık tablosunu kullanır. Misafir ve konaklama tablolarına otomatik yazma bu aşamada devreye alınmaz. Canlı geçişten önce gerçek sağlayıcı sözleşmesi, veri saklama süresi ve kişisel veri erişimi ayrıca doğrulanmalıdır.
