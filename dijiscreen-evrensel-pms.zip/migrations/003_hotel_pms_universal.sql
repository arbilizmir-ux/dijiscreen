CREATE TABLE IF NOT EXISTS hotel_pms_adapter_profiles (
    connection_id BIGINT UNSIGNED NOT NULL,
    provider_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    ingress ENUM('api','webhook','manual') NOT NULL,
    last_received_at DATETIME DEFAULT NULL,
    last_staged_at DATETIME DEFAULT NULL,
    PRIMARY KEY (connection_id),
    CONSTRAINT fk_pms_adapter_connection FOREIGN KEY (connection_id) REFERENCES hotel_pms_connections(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS hotel_pms_event_inbox (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    connection_id BIGINT UNSIGNED NOT NULL,
    external_event_id VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    event_type VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    external_reservation_id VARCHAR(190) NOT NULL,
    occurred_at_utc DATETIME NOT NULL,
    payload_json JSON NOT NULL,
    payload_sha256 CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    status ENUM('queued','retry','needs_mapping','staged','failed') NOT NULL DEFAULT 'queued',
    attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_error_code VARCHAR(40) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at DATETIME DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_pms_inbox_event (connection_id, external_event_id),
    KEY idx_pms_inbox_work (status, available_at, id),
    CONSTRAINT fk_pms_inbox_profile FOREIGN KEY (connection_id) REFERENCES hotel_pms_adapter_profiles(connection_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS hotel_pms_event_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_id BIGINT UNSIGNED NOT NULL,
    outcome ENUM('retry','needs_mapping','failed','staged','requeued') NOT NULL,
    error_code VARCHAR(40) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pms_attempt_event (event_id, id),
    CONSTRAINT fk_pms_attempt_event FOREIGN KEY (event_id) REFERENCES hotel_pms_event_inbox(id) ON DELETE CASCADE
) ENGINE=InnoDB;
