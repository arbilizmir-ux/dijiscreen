<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('id');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
function pms_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$hotels = $pdo->query("SELECT id,name FROM hotel_properties WHERE $hotelScope ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$hotelId = filter_input(INPUT_GET, 'hotel_id', FILTER_VALIDATE_INT) ?: (int)($hotels[0]['id'] ?? 0);
$validHotelIds = array_map(static fn($h) => (int)$h['id'], $hotels);
if (!in_array($hotelId, $validHotelIds, true)) { $hotelId = (int)($hotels[0]['id'] ?? 0); }
$connections = [];
$recent = [];
$missingMigration = false;
if ($hotelId) {
    $stmt = $pdo->prepare('SELECT id,provider_name,connection_type,status,last_sync_at,created_at FROM hotel_pms_connections WHERE hotel_id = ? ORDER BY id DESC');
    $stmt->execute([$hotelId]);
    $connections = $stmt->fetchAll(PDO::FETCH_ASSOC);
    try {
        $stmt = $pdo->prepare('SELECT r.id,r.started_at,r.finished_at,r.status,r.records_received,r.records_updated,r.records_skipped,r.error_message,c.provider_name FROM hotel_pms_sync_runs r JOIN hotel_pms_connections c ON c.id=r.connection_id WHERE c.hotel_id=? ORDER BY r.id DESC LIMIT 30');
        $stmt->execute([$hotelId]);
        $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Missing migration is the only expected failure; other DB failures should be visible in server logs.
        if ($e->getCode() !== '42S02') { error_log('Hotel PMS panel: '.$e->getMessage()); }
        $missingMigration = true;
    }
}
?><!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DijiScreen | PMS Durumu</title>
<style>body{margin:0;background:#f3f5f9;color:#17253d;font:15px system-ui,Arial,sans-serif}.wrap{max-width:1100px;margin:36px auto;padding:0 20px}.panel{background:white;border:1px solid #e0e5ee;border-radius:14px;padding:22px;margin:18px 0;overflow:auto}h1{margin:0 0 8px}a{color:#1c579b}table{width:100%;border-collapse:collapse;min-width:650px}th,td{padding:12px;text-align:left;border-bottom:1px solid #e9edf2}th{background:#f8fafc}select{padding:9px;border:1px solid #ccd4df;border-radius:8px}.muted{color:#627187}.warning{background:#fff3dc;padding:14px;border-radius:8px}</style></head>
<body><main class="wrap"><a href="index.php">← Hotel TV</a><h1>PMS Entegrasyon Merkezi</h1><p class="muted">Bağlantı ve senkronizasyon izleme · Güvenli, salt okunur ilk sürüm</p>
<div class="panel"><form method="get"><label for="hotel_id">Otel: </label><select id="hotel_id" name="hotel_id" onchange="this.form.submit()">
<?php foreach ($hotels as $hotel): ?><option value="<?= (int)$hotel['id'] ?>" <?= (int)$hotel['id']===$hotelId?'selected':'' ?>><?= pms_h($hotel['name']) ?></option><?php endforeach; ?></select><noscript><button type="submit">Göster</button></noscript></form></div>
<?php if ($missingMigration): ?><div class="warning">PMS ek tabloları bulunamadı veya sorgulanamadı. SQL geçişini çalıştırın ve sunucu hata kayıtlarını kontrol edin.</div><?php endif; ?>
<p><a href="pms_integrations.php?hotel_id=<?= $hotelId ?>">Sağlayıcı seçimi ve olay kuyruğu</a></p>
<section class="panel"><h2>PMS Bağlantıları</h2><table><thead><tr><th>Sağlayıcı</th><th>Bağlantı tipi</th><th>Durum</th><th>Son senkronizasyon</th></tr></thead><tbody>
<?php foreach ($connections as $c): ?><tr><td><?= pms_h($c['provider_name']) ?></td><td><?= pms_h($c['connection_type']) ?></td><td><?= pms_h($c['status']) ?></td><td><?= pms_h($c['last_sync_at'] ?: 'Henüz yok') ?></td></tr><?php endforeach; ?>
<?php if (!$connections): ?><tr><td colspan="4">Henüz PMS bağlantısı tanımlanmamış.</td></tr><?php endif; ?></tbody></table></section>
<section class="panel"><h2>Son Senkronizasyon İşlemleri</h2><table><thead><tr><th>Sağlayıcı</th><th>Başlangıç</th><th>Durum</th><th>Alınan</th><th>Güncellenen</th><th>Atlanan</th><th>Hata</th></tr></thead><tbody>
<?php foreach ($recent as $r): ?><tr><td><?= pms_h($r['provider_name']) ?></td><td><?= pms_h($r['started_at']) ?></td><td><?= pms_h($r['status']) ?></td><td><?= (int)$r['records_received'] ?></td><td><?= (int)$r['records_updated'] ?></td><td><?= (int)$r['records_skipped'] ?></td><td><?= pms_h(htv_is_superadmin() ? ($r['error_message'] ?: '—') : '—') ?></td></tr><?php endforeach; ?>
<?php if (!$recent): ?><tr><td colspan="7">Henüz senkronizasyon çalıştırılmadı.</td></tr><?php endif; ?></tbody></table></section>
<p class="muted">Bu sayfa bağlantı kurmaz, veri çekmez veya konaklama kayıtlarını değiştirmez. Gerçek sağlayıcı adaptörleri ayrıca etkinleştirilmelidir.</p></main></body></html>
