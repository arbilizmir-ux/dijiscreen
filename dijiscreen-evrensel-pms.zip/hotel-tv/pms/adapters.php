<?php
declare(strict_types=1);

interface HtvPmsAdapter
{
    /** Return a provider-neutral event from the provider or its gateway. */
    public function normalize(array $input): array;
}

final class HtvPmsCanonicalAdapter implements HtvPmsAdapter
{
    public function normalize(array $input): array
    {
        return [
            'event_id' => htv_pms_text($input, 'event_id', 190),
            'type' => htv_pms_text($input, 'type', 32),
            'reservation_id' => htv_pms_text($input, 'reservation_id', 190),
            'occurred_at' => htv_pms_utc($input, 'occurred_at'),
            'room_id' => htv_pms_text($input, 'room_id', 190),
            'previous_room_id' => htv_pms_text($input, 'previous_room_id', 190, false),
            'guest_id' => htv_pms_text($input, 'guest_id', 190),
            'guest_name' => htv_pms_text($input, 'guest_name', 190),
            'arrival_at' => htv_pms_utc($input, 'arrival_at', false),
            'departure_at' => htv_pms_utc($input, 'departure_at', false),
        ];
    }
}

function htv_pms_providers(): array
{
    return ['cloudbeds'=>'Cloudbeds', 'mews'=>'Mews', 'opera_cloud'=>'Oracle OPERA Cloud', 'other'=>'Diğer PMS'];
}

function htv_pms_adapter(string $provider): HtvPmsAdapter
{
    // These profiles use the canonical gateway. Native adapters replace this
    // mapping only after their provider contract and connection are verified.
    if (!isset(htv_pms_providers()[$provider])) throw new InvalidArgumentException('Sağlayıcı geçersiz.');
    return new HtvPmsCanonicalAdapter();
}

function htv_pms_event(HtvPmsAdapter $adapter, array $input): array
{
    $event = $adapter->normalize($input);
    if (!preg_match('/^[A-Za-z0-9_.:-]{1,190}$/D', $event['event_id'])) {
        throw new InvalidArgumentException('Olay kimliği geçersiz.');
    }
    if (!in_array($event['type'], ['reservation.created','reservation.updated','guest.checked_in',
        'guest.checked_out','room.changed','guest.updated'], true)) {
        throw new InvalidArgumentException('Olay türü desteklenmiyor.');
    }
    if ($event['type'] === 'room.changed' &&
        (!$event['previous_room_id'] || $event['previous_room_id'] === $event['room_id'])) {
        throw new InvalidArgumentException('Oda değişikliğinde farklı bir önceki oda kodu gerekli.');
    }
    if ($event['arrival_at'] && $event['departure_at'] && $event['departure_at'] <= $event['arrival_at']) {
        throw new InvalidArgumentException('Ayrılış tarihi girişten sonra olmalı.');
    }
    return $event;
}

function htv_pms_text(array $input, string $field, int $limit, bool $required = true): ?string
{
    $value = $input[$field] ?? null;
    if (!$required && ($value === null || $value === '')) return null;
    if (!is_string($value) || ($value = trim($value)) === '' || !preg_match('//u', $value)
        || mb_strlen($value, 'UTF-8') > $limit || preg_match('/[\x00-\x1f\x7f]/', $value)) {
        throw new InvalidArgumentException($field . ' alanı geçersiz.');
    }
    return $value;
}

function htv_pms_utc(array $input, string $field, bool $required = true): ?string
{
    $value = htv_pms_text($input, $field, 25, $required);
    if ($value === null) return null;
    if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/D', $value)) {
        throw new InvalidArgumentException($field . ' için saat dilimli ISO 8601 zaman gerekli.');
    }
    $value = str_ends_with($value, 'Z') ? substr($value, 0, -1) . '+00:00' : $value;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:sP', $value);
    if (!$date || $date->format('Y-m-d\TH:i:sP') !== $value || (int) substr($value, 0, 4) < 1001) {
        throw new InvalidArgumentException($field . ' tarihi geçersiz.');
    }
    return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z');
}
