<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit;
}
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/pms/inbox.php';

$summary = ['staged'=>0, 'needs_mapping'=>0, 'retry'=>0, 'failed'=>0];
try {
    for ($index = 0; $index < 100; $index++) {
        $outcome = htv_pms_run_next($pdo);
        if ($outcome === null) break;
        $summary[$outcome]++;
    }
    echo json_encode($summary, JSON_THROW_ON_ERROR) . PHP_EOL;
} catch (Throwable $ex) {
    fwrite(STDERR, "PMS kuyruğu işlenemedi. Veritabanı ve migration durumunu kontrol edin.\n");
    exit(1);
}
exit($summary['failed'] ? 1 : 0);
