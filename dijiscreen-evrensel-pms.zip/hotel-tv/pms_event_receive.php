<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/pms/inbox.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function htv_pms_reply(int $status, array $result): never
{
    http_response_code($status);
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    htv_pms_reply(405, ['error'=>'POST gerekli.']);
}
$connectionId = filter_input(INPUT_GET, 'connection_id', FILTER_VALIDATE_INT) ?: 0;
$channel = filter_input(INPUT_GET, 'channel') ?? '';
$key = $config['app_key'] ?? '';
if (!$connectionId || !in_array($channel, ['api','webhook'], true)) htv_pms_reply(400, ['error'=>'Bağlantı veya kanal geçersiz.']);
if (!is_string($key) || strlen($key) < 32) htv_pms_reply(503, ['error'=>'İmza anahtarı yapılandırılmalı.']);
$timestamp = $_SERVER['HTTP_X_DIJI_TIMESTAMP'] ?? '';
$signature = $_SERVER['HTTP_X_DIJI_SIGNATURE'] ?? '';
if (!preg_match('/^[0-9]{10}$/D', $timestamp) || abs(time()-(int) $timestamp) > 300
    || !preg_match('/^[a-f0-9]{64}$/D', $signature)) htv_pms_reply(401, ['error'=>'İmza veya zaman damgası geçersiz.']);
$body = file_get_contents('php://input', false, null, 0, 65537);
if (!is_string($body) || strlen($body) > 65536) htv_pms_reply(413, ['error'=>'Gövde sınırı 64 KiB.']);
$secret = hash_hmac('sha256', "hotel-pms-universal:v1:$connectionId:$channel", $key);
if (!hash_equals(hash_hmac('sha256', $timestamp . '.' . $body, $secret), $signature)) {
    htv_pms_reply(401, ['error'=>'İmza geçersiz.']);
}
try {
    $connection = htv_pms_connection($pdo, $connectionId);
    if (!htv_pms_can_receive($connection, $channel)) htv_pms_reply(403, ['error'=>'Bağlantı bu kanal için açık değil.']);
    $data = json_decode($body, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($data)) throw new InvalidArgumentException('JSON nesnesi gerekli.');
    $adapter = htv_pms_adapter($connection['provider_code']);
    $events = $channel === 'webhook' ? [$data] : ($data['events'] ?? null);
    if (!is_array($events) || !array_is_list($events) || count($events) < 1 || count($events) > 50) {
        throw new InvalidArgumentException('İstek 1–50 olay içermeli.');
    }
    $normalized = [];
    foreach ($events as $event) {
        if (!is_array($event)) throw new InvalidArgumentException('Olay nesnesi gerekli.');
        $normalized[] = htv_pms_event($adapter, $event);
    }
    $counts = htv_pms_queue($pdo, $connection, $normalized);
    htv_pms_reply($counts['queued'] ? 202 : 200, $counts);
} catch (JsonException | InvalidArgumentException $ex) {
    htv_pms_reply(422, ['error'=>$ex->getMessage()]);
} catch (DomainException $ex) {
    htv_pms_reply(409, ['error'=>$ex->getMessage()]);
} catch (Throwable $ex) {
    error_log('[Hotel TV PMS ingress] connection=' . $connectionId . ' error=' . get_class($ex));
    htv_pms_reply(503, ['error'=>'PMS isteği kaydedilemedi.']);
}
