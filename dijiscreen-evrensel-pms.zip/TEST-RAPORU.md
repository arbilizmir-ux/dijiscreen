# Test raporu

## PMS altyapısı

Yerel MariaDB, PHP HTTP ve PHP CLI üzerinde dört sağlayıcı profili, üç giriş yöntemi ve altı olay türü doğrulandı. Saat dilimi normalizasyonu, aynı olayın tekrarı, farklı içerikli aynı kimlikte tutarlı geri alma, onaysız içe aktarma engeli, oda eşleme sonrası yeniden kuyruğa alma ve geçici kilit hatası için gecikmeli yeniden deneme geçti. İki ayrı otelle panel kapsamı ve mevcut PMS webhook/inceleme akışı doğrulandı. Misafir ve konaklama tablo sayımları değişmedi.

Gerçek Cloudbeds, Mews ve Oracle OPERA Cloud bağlantısı denenmedi. MySQL 8 ve test sunucusundaki barındırma ayarları ayrıca doğrulanmalı.

## Oda TV

Yerel 1920×1080 Chromium ve MariaDB ile ana ekran, Canlı TV ilk odağı, kanal seçimi, oynatma, tam ekran ve Geri akışı tekrar doğrulandı. Restoran ve hizmet kartlarına kumanda odağı eklendi. Restoran fiyatı, hizmet açıklaması ve iki radyo kaynağı arasında geçiş sınandı. İkinci radyo oynarken ilkinin durduğu ve ana ekrana dönüldüğünde oynatıcının kaldırıldığı doğrulandı. Önceki tasarım ve yazı tipleri kullanıldı.

Bu paket fiziksel TV ve üretim verisiyle test edilmedi.
