CREATE TABLE IF NOT EXISTS hotel_tv_room_displays (
    room_id BIGINT UNSIGNED NOT NULL,
    hotel_id BIGINT UNSIGNED NOT NULL,
    pairing_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
    pairing_expires_at DATETIME DEFAULT NULL,
    session_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
    session_expires_at DATETIME DEFAULT NULL,
    PRIMARY KEY (room_id),
    UNIQUE KEY uq_htv_pairing_hash (pairing_hash),
    UNIQUE KEY uq_htv_session_hash (session_hash),
    CONSTRAINT fk_htv_display_hotel FOREIGN KEY (hotel_id) REFERENCES hotel_properties(id) ON DELETE CASCADE,
    CONSTRAINT fk_htv_display_room FOREIGN KEY (room_id) REFERENCES hotel_rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB;
