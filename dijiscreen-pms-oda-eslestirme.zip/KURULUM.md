# Hotel TV · PMS hazırlık ve oda eşleştirme

Bu paket kişisel karşılama paketi üzerine uygulanır. Test veritabanında migrations/002_hotel_tv_room_displays.sql dosyasını çalıştırın. ZIP içindeki hotel-tv dosyalarını test sunucusundaki mevcut server/public/hotel-tv/ klasörüne yükleyin. Test adresi HTTPS kullanmalıdır.

## Oda televizyonu

1. Yönetimden **Hotel TV → TV Önizlemesi → Oda TV eşleştirme** bölümünü açın.
2. Odayı seçip **Kod oluştur** düğmesine basın. Kod tek kullanımlıktır ve 15 dakika geçerlidir.
3. Oda TV tarayıcısında aynı test sitenizin hotel-tv klasöründeki tv_pair_room.php sayfasını açın ve kodu girin.
4. Açılan oda ekranını TV tarayıcısında kaydedin. Eşleştirme en fazla 180 gün geçerlidir. Tarayıcı verileri silinirse veya eşleştirme kaldırılırsa yeni kod gerekir.
5. DijiScreen’de odanın misafirini giriş, sonra çıkış yapılmış duruma alın. Açık ekran misafir adını yaklaşık 15 saniyede bir kontrol eder. Yeni misafir için oda yeniden eşleştirilmez.

Her oda için bir etkin tarayıcı kaydı vardır. Yeni kod kullanılırsa önceki tarayıcı kaydı kapanır. **Eşleştirmeyi kaldır** düğmesi kodu ve tarayıcı erişimini iptal eder. Çerezdeki ve koddaki rastgele değerlerin yalnızca özetleri veritabanında tutulur. Mevcut kısa süreli ekran bağlantıları da kullanılabilir.

## PMS

İmzalı standart webhook gerçek misafir veya konaklama tablolarına yazmadan hazırlık kaydı oluşturur. Birebir aynı isteğin tekrarı yeni kayıt açmaz. Aynı olay kimliği farklı içerikle tekrar gönderilirse HTTP 409 döner. Yeniden kontrol, reddedilmiş kayıtların durumunu korur ve odanın ilgili otele ait ve etkin olmasını denetler.

Yerel MariaDB’de sentetik rezervasyon oluşturma, güncelleme, giriş, çıkış ve oda değişikliği olayları denendi. Olaylar hazırlık kayıtlarına ulaşır. Bir sağlayıcıya ait gerçek API çağrısı ve rezervasyonun otomatik uygulanması bu paket kapsamında etkin değildir. Yeni iş akışı için bir PMS test hesabı, sağlayıcı olay örnekleri, kalıcı rezervasyon kimliği, değişiklik sırası ve saat dilimi sözleşmesi gerekir.

## Doğrulama

Yerel Chromium ve MariaDB ile eşleştirme, aynı TV’de çıkış ve sonraki misafire geçiş, tek kullanımlık kod ve iptal senaryoları test edilir. Test sunucusunda fiziksel TV ve gerçek sağlayıcı doğrulaması ayrıca gerekir. Cihaz API’si ve Android APK’sı bu pakette yer almaz.
