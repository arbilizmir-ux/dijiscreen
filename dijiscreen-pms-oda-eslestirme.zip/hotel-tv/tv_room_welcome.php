<?php
declare(strict_types=1);

function htv_room_ticket(string $key, int $hotelId, int $roomId, int $stayId, int $guestId, int $expires): string
{
    return hash_hmac('sha256', "hotel-tv-room:v1:$hotelId:$roomId:$stayId:$guestId:$expires", $key);
}

function htv_current_room_stays(PDO $pdo, int $hotelId, ?array $roomTicket = null, int $pairedRoomId = 0): array
{
    $filter = $roomTicket ? 'AND s.room_id = ? AND s.id = ? AND s.guest_id = ?'
        : ($pairedRoomId ? 'AND s.room_id = ?' : '');
    $columns = $roomTicket || $pairedRoomId
        ? 'g.first_name, g.last_name'
        : 's.id, s.guest_id, r.id AS room_id, r.room_number, b.name AS branch_name';
    $query = $pdo->prepare(
        "SELECT $columns
         FROM hotel_stays s
         JOIN hotel_properties h ON h.id = s.hotel_id AND h.status = 'active'
         JOIN hotel_branches b ON b.id = s.branch_id AND b.hotel_id = s.hotel_id AND b.status = 'active'
         JOIN hotel_rooms r ON r.id = s.room_id AND r.branch_id = b.id AND r.status = 'active'
         JOIN hotel_guests g ON g.id = s.guest_id AND g.hotel_id = s.hotel_id
         WHERE s.hotel_id = ? AND s.status = 'checked_in' AND s.check_in_at <= NOW()
           AND (s.check_out_at IS NULL OR s.check_out_at > NOW())
           AND NOT EXISTS (
             SELECT 1 FROM hotel_stays other
             WHERE other.hotel_id = s.hotel_id AND other.room_id = s.room_id
               AND other.id <> s.id AND other.status = 'checked_in' AND other.check_in_at <= NOW()
               AND (other.check_out_at IS NULL OR other.check_out_at > NOW())
           )
           $filter
         ORDER BY b.name, r.room_number, s.id"
    );
    $query->execute(array_merge([$hotelId], $roomTicket ?: ($pairedRoomId ? [$pairedRoomId] : [])));
    return $query->fetchAll(PDO::FETCH_ASSOC);
}
