<?php
declare(strict_types=1);

function htv_paired_room(PDO $pdo): ?array
{
    $secret = $_COOKIE['htv_room_display'] ?? '';
    if (!is_string($secret) || !preg_match('/^[a-f0-9]{64}$/D', $secret)) return null;
    $stmt = $pdo->prepare("SELECT d.room_id, b.hotel_id
        FROM hotel_tv_room_displays d
        JOIN hotel_rooms r ON r.id=d.room_id AND r.status='active'
        JOIN hotel_branches b ON b.id=r.branch_id AND b.hotel_id=d.hotel_id AND b.status='active'
        JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
        WHERE d.session_hash=? AND d.session_expires_at > NOW()");
    $stmt->execute([hash('sha256', $secret)]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
