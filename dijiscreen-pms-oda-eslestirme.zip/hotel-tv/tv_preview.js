'use strict';

const config = JSON.parse(document.getElementById('tv-data').textContent);
const tabs = Array.from(document.querySelectorAll('[data-type]'));
const section = document.getElementById('section');
const guestScreen = document.body.classList.contains('guest-screen');
const fullscreen = document.getElementById('fullscreen');

if (fullscreen && document.fullscreenEnabled && document.documentElement.requestFullscreen) {
    fullscreen.hidden = false;
    fullscreen.addEventListener('click', async () => {
        try {
            if (document.fullscreenElement) await document.exitFullscreen();
            else await document.documentElement.requestFullscreen();
        } catch {
            fullscreen.textContent = 'Tam ekran kullanılamıyor';
        }
    });
    document.addEventListener('fullscreenchange', () => {
        fullscreen.textContent = document.fullscreenElement ? 'Tam ekrandan çık' : 'Tam ekran';
    });
}
const labels = Object.fromEntries(tabs.map(tab => [tab.dataset.type, tab.textContent.trim()]));

function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text != null) node.textContent = text;
    if (className) node.className = className;
    return node;
}

function sourceUrl(value) {
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && !url.username && !url.password ? url : null;
    } catch {
        return null;
    }
}

function addSource(card, item, type) {
    const url = sourceUrl(item.resource_url);
    if (!url) return;
    const mediaType = type === 'tv' ? 'video' : type === 'radio' ? 'audio' : null;
    if (mediaType) {
        const play = element('button', 'Yayını oynat');
        play.type = 'button';
        play.addEventListener('click', () => {
            const player = element(mediaType);
            const status = element('p');
            status.setAttribute('role', 'status');
            player.controls = true;
            player.tabIndex = 0;
            player.preload = 'none';
            player.setAttribute('aria-label', item.title);
            if (mediaType === 'video') player.playsInline = true;
            const unavailable = () => {
                status.textContent = 'Yayın bu cihazda oynatılamadı. Yayın bağlantısını açabilirsiniz.';
            };
            player.addEventListener('error', unavailable);
            player.src = url.href;
            play.replaceWith(player, status);
            player.focus();
            const attempt = player.play();
            if (attempt) attempt.catch(unavailable);
        });
        card.append(play);
    }
    const link = element('a', mediaType ? 'Yayın bağlantısı' : 'Ayrıntıları aç');
    link.href = url.href;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    const actions = element('p');
    card.append(actions);
    actions.append(link);
}

function renderCard(item, type) {
    const card = element('article', null, 'card');
    card.append(element('h3', item.title));
    if (item.subtitle) card.append(element('p', item.subtitle, 'subtitle'));
    if (item.description) card.append(element('p', item.description));
    if (item.price != null && item.price !== '' && Number.isFinite(Number(item.price))) {
        const currency = /^[A-Z]{3}$/.test(item.currency) ? item.currency : 'TRY';
        const price = new Intl.NumberFormat('tr-TR', {style: 'currency', currency}).format(Number(item.price));
        card.append(element('strong', price));
    }
    addSource(card, item, type);
    return card;
}

function renderFlights() {
    if (config.flightError) section.append(element('p', 'Otomatik uçuş verisi okunamadı.', 'message'));
    for (const [direction, rows] of Object.entries(config.flights || {})) {
        const title = direction === 'arrivals' ? 'Gelen uçuşlar' : 'Giden uçuşlar';
        if (!rows.length) {
            section.append(element('p', title + ' için güncel kayıt bulunamadı.', 'message'));
            continue;
        }
        if (rows.some(row => Number(row.age_seconds) > 900)) {
            section.append(element('p', title + ' listesindeki bazı kayıtlar 15 dakikadan eski.', 'message'));
        }
        const table = element('table');
        table.append(element('caption', title));
        const head = table.createTHead().insertRow();
        for (const title of ['Planlanan', 'Tahmini', 'Uçuş', 'Havalimanı', 'Güzergâh', 'Durum']) {
            const label = element('th', title);
            label.scope = 'col';
            head.append(label);
        }
        const body = table.createTBody();
        for (const flight of rows) {
            const row = body.insertRow();
            for (const value of [flight.scheduled_at, flight.estimated_at, flight.flight_number,
                flight.airport_code, flight.destination, flight.flight_status]) {
                row.insertCell().textContent = value || '—';
            }
        }
        const wrap = element('div', null, 'table-wrap');
        if (guestScreen) {
            wrap.tabIndex = 0;
            wrap.setAttribute('aria-label', title);
        }
        wrap.append(table);
        section.append(wrap);
    }
}

const homeOrder = ['tv', 'restaurant', 'services', 'radio', 'flights'];
const homeNames = {tv: 'Canlı TV', restaurant: 'Restoran', services: 'Hizmetler', radio: 'Radyo', flights: 'Uçuşlar'};
const backButton = document.getElementById('guest-back');
const remoteHint = document.getElementById('remote-hint');
const welcomeName = document.querySelector('.welcome-name');

function setWelcomeName(name) {
    if (!welcomeName) return;
    welcomeName.textContent = name;
    welcomeName.hidden = !name;
    if (document.body.dataset.screen === 'home') {
        document.getElementById('section-title').textContent = name ? 'Hoş geldiniz,' : 'Hoş geldiniz';
    }
}

if (config.roomWelcome && welcomeName) {
    const welcomeUrl = new URL(window.location.href);
    welcomeUrl.searchParams.set('welcome', '1');
    let running = false;
    async function refreshWelcome() {
        if (running) return;
        running = true;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 7000);
        try {
            const response = await fetch(welcomeUrl.href, {
                cache: 'no-store', credentials: config.paired ? 'same-origin' : 'omit', signal: controller.signal
            });
            if (config.paired && response.status === 403) {
                setWelcomeName('');
                window.location.replace('tv_pair_room.php');
                return;
            }
            if (!response.ok) throw new Error('Welcome unavailable');
            const data = await response.json();
            setWelcomeName(typeof data.name === 'string' ? data.name : '');
        } catch {
            setWelcomeName('');
        } finally {
            clearTimeout(timeout);
            running = false;
        }
    }
    window.addEventListener('pageshow', refreshWelcome);
    window.addEventListener('online', refreshWelcome);
    window.addEventListener('offline', () => setWelcomeName(''));
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) setWelcomeName('');
        else refreshWelcome();
    });
    setInterval(refreshWelcome, 15000);
}

function goHome() {
    show('home');
    section.querySelector('button').focus();
}

function renderChannels(items) {
    if (!items.length) return;
    const layout = element('div', null, 'channel-layout');
    const list = element('div', null, 'channel-list');
    list.setAttribute('aria-label', 'Kanallar');
    const stage = element('div', null, 'channel-stage');
    const player = element('video');
    player.playsInline = true;
    player.muted = true;
    player.preload = 'none';
    const label = element('p', null, 'channel-status');
    label.setAttribute('role', 'status');
    const source = element('a', 'Yayın bağlantısını aç', 'channel-source');
    source.hidden = true;
    source.target = '_blank';
    source.rel = 'noopener noreferrer';
    stage.append(player, label, source);
    layout.append(list, stage);
    section.append(layout);

    let active = -1;
    function select(index) {
        if (active === index) return;
        active = index;
        buttons.forEach((button, pos) => button.setAttribute('aria-pressed', String(pos === index)));
        const item = items[index];
        const url = sourceUrl(item.resource_url);
        player.pause();
        player.removeAttribute('src');
        player.load();
        player.setAttribute('aria-label', item.title);
        source.hidden = true;
        label.textContent = url ? 'Yayın yükleniyor…' : 'Bu kanalın yayın adresi yok.';
        if (url) {
            source.href = url.href;
            player.muted = true;
            player.src = url.href;
            const attempt = player.play();
            if (attempt) attempt.catch(error => {
                if (active === index && error.name !== 'AbortError') {
                    label.textContent = 'Önizleme açılamadı. OK ile tekrar deneyin.';
                    source.hidden = false;
                }
            });
        } else {
            source.removeAttribute('href');
        }
    }

    function openChannel(index) {
        select(index);
        if (!player.getAttribute('src')) return;
        player.muted = false;
        const attempt = player.play();
        if (attempt) attempt.catch(() => {
            if (active === index) {
                label.textContent = 'Yayın bu cihazda oynatılamadı.';
                source.hidden = false;
            }
        });
        stage.classList.add('expanded');
        if (document.fullscreenEnabled && stage.requestFullscreen && !document.fullscreenElement) {
            stage.requestFullscreen().catch(() => {});
        }
    }

    player.addEventListener('playing', () => { label.textContent = ''; source.hidden = true; });
    player.addEventListener('error', () => {
        label.textContent = 'Yayın bu cihazda oynatılamadı.';
        source.hidden = !source.hasAttribute('href');
    });
    const buttons = items.map((item, index) => {
        const number = String(index + 1).padStart(2, '0');
        const button = element('button', number + '  ' + item.title, 'channel');
        button.type = 'button';
        button.addEventListener('focus', () => select(index));
        button.addEventListener('click', () => openChannel(index));
        list.append(button);
        return button;
    });
    select(0);
}

if (backButton) backButton.addEventListener('click', goHome);
document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement) {
        const stage = section.querySelector('.channel-stage.expanded');
        if (stage) {
            stage.classList.remove('expanded');
            stage.querySelector('video').muted = true;
        }
    }
});

function show(type) {
    tabs.forEach(tab => tab.setAttribute('aria-current', tab.dataset.type === type ? 'page' : 'false'));
    document.body.dataset.screen = type;
    document.getElementById('section-title').textContent = type === 'home'
        ? (welcomeName?.textContent ? 'Hoş geldiniz,' : 'Hoş geldiniz') : labels[type];
    if (remoteHint) remoteHint.textContent = type === 'home' ? '← → Gezin     OK Aç'
        : type === 'tv' ? '↑ ↓ Kanal seç     OK Tam ekran     Geri Ana ekran'
        : 'Yön tuşlarıyla gezin     OK Aç     Geri Ana ekran';
    if (backButton) backButton.hidden = type === 'home';
    section.querySelectorAll('audio, video').forEach(player => player.pause());
    section.textContent = '';
    const tiles = element('div', null, 'tiles');

    if (type === 'home') {
        const homeTabs = guestScreen ? homeOrder.map(key => tabs.find(tab => tab.dataset.type === key)) : tabs.slice(1);
        for (const tab of homeTabs) {
            const key = tab.dataset.type;
            const tile = element('button', guestScreen ? null : labels[key], 'card');
            if (guestScreen) {
                const icon = element('img', null, 'tile-icon');
                icon.src = 'tv-icon-' + key + '.png';
                icon.alt = '';
                icon.setAttribute('aria-hidden', 'true');
                tile.append(icon, element('span', homeNames[key]));
            }
            tile.type = 'button';
            tile.addEventListener('click', () => {
                show(tab.dataset.type);
                if (guestScreen) (section.querySelector('button, a, [tabindex]') || backButton).focus();
                else tab.focus();
            });
            tiles.append(tile);
        }
    } else if (guestScreen && type === 'tv') {
        renderChannels(config.items.tv || []);
    } else {
        if (type === 'flights') renderFlights();
        for (const item of config.items[type] || []) tiles.append(renderCard(item, type));
    }
    if (tiles.childElementCount) section.append(tiles);
    if (!section.childElementCount) section.append(element('p', 'Bu bölümde henüz içerik yok.', 'message'));
}

tabs.forEach(tab => tab.addEventListener('click', () => show(tab.dataset.type)));
document.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.defaultPrevented) return;
    const target = event.target;
    if (guestScreen && ['Escape', 'Backspace', 'BrowserBack', 'GoBack', 'Back'].includes(event.key)
        && tabs[0].getAttribute('aria-current') !== 'page') {
        const stage = section.querySelector('.channel-stage.expanded');
        if (stage) {
            event.preventDefault();
            if (document.fullscreenElement === stage) document.exitFullscreen().catch(() => {});
            stage.classList.remove('expanded');
            const player = stage.querySelector('video');
            if (player) player.muted = true;
            section.querySelector('.channel[aria-pressed="true"]')?.focus();
            return;
        }
        event.preventDefault();
        goHome();
        return;
    }
    if (target.closest && target.closest('.toolbar, audio, video')) return;
    const keys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'];
    if (!keys.includes(event.key)) return;
    if (guestScreen && target.classList && target.classList.contains('table-wrap')
        && ['ArrowDown', 'ArrowUp'].includes(event.key) && target.scrollHeight > target.clientHeight) {
        const down = event.key === 'ArrowDown';
        const end = target.scrollTop + target.clientHeight >= target.scrollHeight - 1;
        if ((down && !end) || (!down && target.scrollTop > 0)) {
            event.preventDefault();
            target.scrollTop += down ? 110 : -110;
            return;
        }
    }
    if (guestScreen && target.classList?.contains('channel') && ['ArrowDown', 'ArrowUp'].includes(event.key)) {
        const channels = Array.from(section.querySelectorAll('.channel'));
        const step = event.key === 'ArrowDown' ? 1 : -1;
        channels[(channels.indexOf(target) + step + channels.length) % channels.length].focus();
        event.preventDefault();
        return;
    }
    const contentControls = Array.from(section.querySelectorAll('button, a, audio, video[controls], .table-wrap[tabindex]'))
        .filter(control => !control.hidden);
    const controls = guestScreen ? contentControls : tabs.concat(contentControls);
    if (backButton && !backButton.hidden) controls.unshift(backButton);
    if (fullscreen && !fullscreen.hidden) controls.unshift(fullscreen);
    const index = controls.indexOf(target);
    if (index < 0 && target !== document.body) return;
    event.preventDefault();
    if (index < 0) {
        if (guestScreen) controls[0]?.focus();
        else tabs.find(tab => tab.getAttribute('aria-current') === 'page').focus();
        return;
    }
    const step = ['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1;
    controls[(index + step + controls.length) % controls.length].focus();
});

function tick() {
    const now = new Date();
    let timezone = config.timezone;
    try {
        new Intl.DateTimeFormat('tr-TR', {timeZone: timezone});
    } catch {
        timezone = 'Europe/Istanbul';
    }
    document.getElementById('clock').textContent = now.toLocaleTimeString('tr-TR',
        {hour: '2-digit', minute: '2-digit', timeZone: timezone});
    document.getElementById('date').textContent = now.toLocaleDateString('tr-TR',
        {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: timezone});
}
show('home');
if (guestScreen) section.querySelector('button').focus();
tick();
setInterval(tick, 30000);
