<?php
declare(strict_types=1);
/** DijiScreen PMS v6: signed provider-neutral staging endpoint. Does not modify guests or stays. */
require dirname(__DIR__, 2) . '/app/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
function pms6_reply(int $status, string $message): void {
    http_response_code($status);
    echo json_encode(['success'=>$status<300,'message'=>$message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') pms6_reply(405,'POST gerekli');
$id=filter_var($_GET['connection_id'] ?? null,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
if (!$id) pms6_reply(400,'Bağlantı kimliği geçersiz');
if (!isset($config['app_key']) || strlen((string)$config['app_key'])<32) pms6_reply(503,'Sunucu anahtarı yapılandırılmamış');
$body=file_get_contents('php://input',false,null,0,65537);
if (!is_string($body) || strlen($body)>65536) pms6_reply(413,'En fazla 64 KB');
$timestamp=(string)($_SERVER['HTTP_X_DIJI_TIMESTAMP'] ?? '');
$signature=strtolower((string)($_SERVER['HTTP_X_DIJI_SIGNATURE'] ?? ''));
$eventId=(string)($_SERVER['HTTP_X_DIJI_EVENT_ID'] ?? '');
if (!preg_match('/^[0-9]{10}$/D',$timestamp) || abs(time()-(int)$timestamp)>300) pms6_reply(401,'Zaman damgası geçersiz');
if (!preg_match('/^[a-f0-9]{64}$/D',$signature) || !preg_match('/^[A-Za-z0-9_.:-]{1,190}$/D',$eventId)) pms6_reply(401,'İmza/olay kimliği geçersiz');
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
try {
    $q=$pdo->prepare("SELECT id,hotel_id,status,provider_name FROM hotel_pms_connections WHERE id=? AND connection_type='webhook' LIMIT 1");
    $q->execute([$id]); $connection=$q->fetch(PDO::FETCH_ASSOC);
    if (!$connection || $connection['status']!=='active') pms6_reply(403,'Aktif webhook bağlantısı bulunamadı');
    $secret=hash_hmac('sha256','hotel-pms-webhook-v3:'.$id,(string)$config['app_key']);
    $expected=hash_hmac('sha256',$timestamp.'.'.$eventId.'.'.$body,$secret);
    if (!hash_equals($expected,$signature)) pms6_reply(401,'İmza geçersiz');
    $data=json_decode($body,true);
    if (!is_array($data) || array_is_list($data)) pms6_reply(400,'JSON nesnesi gerekli');
    // Canonical contract, independent of any PMS vendor's native API.
    $type=$data['event_type'] ?? '';
    $allowed=['reservation.created','reservation.updated','guest.checked_in','guest.checked_out','room.changed'];
    if (!is_string($type) || !in_array($type,$allowed,true)) pms6_reply(422,'Desteklenmeyen olay türü');
    foreach (['external_room_id','external_guest_id','guest_name'] as $field) {
        if (!isset($data[$field]) || !is_string($data[$field]) || trim($data[$field])==='' || mb_strlen($data[$field])>190) pms6_reply(422,$field.' gerekli (en fazla 190 karakter)');
    }
    $room=trim($data['external_room_id']); $guest=trim($data['external_guest_id']); $name=trim($data['guest_name']);
    $dates=[];
    foreach (['arrival_at','departure_at'] as $field) {
        $value=$data[$field] ?? null;
        if ($value===null || $value==='') { $dates[$field]=null; continue; }
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D',$value)) pms6_reply(422,$field.' biçimi YYYY-MM-DD HH:MM:SS olmalı');
        $dt=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$value);
        if (!$dt || $dt->format('Y-m-d H:i:s')!==$value) pms6_reply(422,$field.' geçersiz');
        $dates[$field]=$value;
    }
    if ($dates['arrival_at'] && $dates['departure_at'] && $dates['departure_at'] <= $dates['arrival_at']) {
        pms6_reply(422, 'Çıkış girişten sonra olmalı');
    }
    $q=$pdo->prepare("SELECT r.id FROM hotel_pms_room_mappings m
        JOIN hotel_rooms r ON r.id=m.room_id AND r.status='active'
        JOIN hotel_branches b ON b.id=r.branch_id AND b.hotel_id=m.hotel_id AND b.status='active'
        JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
        WHERE m.connection_id=? AND m.hotel_id=? AND m.external_room_id=? LIMIT 1");
    $q->execute([$id,$connection['hotel_id'],$room]);
    $mapped=(bool)$q->fetchColumn();
    $status=$mapped?'ready':'needs_mapping';
    $note=$mapped?'Oda eşleşti; manuel onay bekliyor':'Oda eşleştirmesi gerekli';
    $q=$pdo->prepare('INSERT INTO hotel_pms_import_staging (connection_id,hotel_id,external_event_id,external_room_id,external_guest_id,event_type,guest_name,arrival_at,departure_at,status,validation_note,payload_sha256) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    $payloadHash = hash('sha256', $body);
    try {
        $q->execute([$id,$connection['hotel_id'],$eventId,$room,$guest,$type,$name,$dates['arrival_at'],$dates['departure_at'],$status,$note,$payloadHash]);
    } catch (PDOException $ex) {
        if ((int) ($ex->errorInfo[1] ?? 0) !== 1062) throw $ex;
        $existing = $pdo->prepare('SELECT payload_sha256 FROM hotel_pms_import_staging WHERE connection_id=? AND hotel_id=? AND external_event_id=?');
        $existing->execute([$id, $connection['hotel_id'], $eventId]);
        $existingHash = $existing->fetchColumn();
        if (!is_string($existingHash)) throw $ex;
        if (!hash_equals($existingHash, $payloadHash)) {
            pms6_reply(409, 'Bu olay kimliği farklı içerikle daha önce kullanıldı');
        }
        pms6_reply(200, 'Olay daha önce kaydedildi');
    }
    pms6_reply(202,'Olay güvenli hazırlık alanına alındı: '.$status);
} catch (PDOException $e) {
    error_log('[PMS v6 ingest] '.$e->getMessage());
    pms6_reply(500,'Veritabanı işlemi başarısız; sunucu hata kaydını kontrol edin');
} catch (Throwable $e) {
    error_log('[PMS v6 ingest] '.$e->getMessage());
    pms6_reply(500,'Sunucu işlemi başarısız');
}
