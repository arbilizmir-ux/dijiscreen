<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';

header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
$manager = filter_input(INPUT_GET, 'manage') === '1';
$code = '';
$error = '';
$message = '';
$rooms = [];
if ($manager) {
    htv_require_manager();
    $roomScope = htv_hotel_scope('b.hotel_id');
}
try {
    if ($manager && $_SERVER['REQUEST_METHOD'] === 'POST') {
        htv_check_csrf();
        $roomId = filter_input(INPUT_POST, 'room_id', FILTER_VALIDATE_INT) ?: 0;
        $action = $_POST['action'] ?? '';
        $query = $pdo->prepare("SELECT b.hotel_id FROM hotel_rooms r
            JOIN hotel_branches b ON b.id=r.branch_id AND b.status='active'
            JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
            WHERE r.id=? AND r.status='active' AND $roomScope");
        $query->execute([$roomId]);
        $hotelId = (int) $query->fetchColumn();
        if (!$hotelId) htv_access_denied();

        if ($action === 'issue') {
            $code = bin2hex(random_bytes(16));
            $stmt = $pdo->prepare("INSERT INTO hotel_tv_room_displays (room_id, hotel_id, pairing_hash, pairing_expires_at)
                VALUES (?, ?, ?, NOW() + INTERVAL 15 MINUTE)
                ON DUPLICATE KEY UPDATE
                    session_hash=IF(hotel_id=VALUES(hotel_id),session_hash,NULL),
                    session_expires_at=IF(hotel_id=VALUES(hotel_id),session_expires_at,NULL),
                    hotel_id=VALUES(hotel_id), pairing_hash=VALUES(pairing_hash), pairing_expires_at=VALUES(pairing_expires_at)");
            $stmt->execute([$roomId, $hotelId, hash('sha256', $code)]);
            $message = 'Eşleştirme kodu 15 dakika geçerli.';
        } elseif ($action === 'revoke') {
            $stmt = $pdo->prepare('DELETE FROM hotel_tv_room_displays WHERE room_id=?');
            $stmt->execute([$roomId]);
            $message = 'Oda televizyonunun eşleştirmesi kaldırıldı.';
        }
    } elseif (!$manager && $_SERVER['REQUEST_METHOD'] === 'POST') {
        htv_check_csrf();
        $given = $_POST['code'] ?? '';
        if (is_string($given) && preg_match('/^[a-fA-F0-9]{32}$/D', trim($given))) {
            $secret = bin2hex(random_bytes(32));
            $stmt = $pdo->prepare("UPDATE hotel_tv_room_displays d
                JOIN hotel_rooms r ON r.id=d.room_id AND r.status='active'
                JOIN hotel_branches b ON b.id=r.branch_id AND b.hotel_id=d.hotel_id AND b.status='active'
                JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
                SET d.pairing_hash=NULL, d.pairing_expires_at=NULL,
                    d.session_hash=?, d.session_expires_at=NOW() + INTERVAL 180 DAY
                WHERE d.pairing_hash=? AND d.pairing_expires_at > NOW()");
            $stmt->execute([hash('sha256', $secret), hash('sha256', strtolower(trim($given)))]);
            if ($stmt->rowCount() === 1) {
                setcookie('htv_room_display', $secret, [
                    'expires' => time() + 180 * 86400,
                    'path' => rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/',
                    'secure' => true, 'httponly' => true, 'samesite' => 'Strict',
                ]);
                header('Location: tv_guest.php?paired=1', true, 303);
                exit;
            }
        }
        $error = 'Kod geçersiz veya süresi dolmuş. Yönetimden yeni kod alın.';
    }
    if ($manager) {
        $stmt = $pdo->query("SELECT r.id, r.room_number, b.name AS branch_name, h.name AS hotel_name,
              d.session_expires_at > NOW() AS paired
            FROM hotel_rooms r JOIN hotel_branches b ON b.id=r.branch_id AND b.status='active'
            JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
            LEFT JOIN hotel_tv_room_displays d ON d.room_id=r.id AND d.hotel_id=h.id
            WHERE r.status='active' AND $roomScope ORDER BY h.name, b.name, r.room_number");
        $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $ex) {
    error_log('[Hotel TV room pairing] ' . $ex->getMessage());
    $error = 'Oda eşleştirme şu anda kullanılamıyor.';
    $code = '';
}
?><!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Oda TV eşleştirme</title><link rel="stylesheet" href="tv_preview.css"></head>
<body><main>
<h1>Oda TV eşleştirme</h1>
<?php if ($error): ?><p role="alert"><?= e($error) ?></p><?php endif; ?>
<?php if ($message): ?><p role="status"><?= e($message) ?></p><?php endif; ?>
<?php if ($manager): ?>
    <p><a href="tv_preview.php">TV önizlemesi</a> · <a href="tv_pair_room.php">TV eşleştirme sayfası</a></p>
    <?php if ($code): ?><p>Kod <strong><code><?= e($code) ?></code></strong></p><?php endif; ?>
    <?php if ($rooms): ?>
    <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <label for="pair-room">Oda</label>
        <select id="pair-room" name="room_id" required>
            <option value="">Oda seçin</option>
            <?php foreach ($rooms as $room): ?>
                <option value="<?= (int) $room['id'] ?>"><?= e($room['hotel_name'].' · '.$room['branch_name'].' · '.$room['room_number'].(!empty($room['paired']) ? ' · Eşleştirilmiş' : '')) ?></option>
            <?php endforeach; ?>
        </select>
        <button name="action" value="issue">Kod oluştur</button>
        <button name="action" value="revoke">Eşleştirmeyi kaldır</button>
    </form>
    <?php endif; ?>
<?php else: ?>
    <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <label for="pair-code">Eşleştirme kodu</label>
        <input id="pair-code" name="code" type="text" maxlength="32" autocomplete="off" required>
        <button type="submit">Eşleştir</button>
    </form>
    <p><a href="tv_guest.php?paired=1">Eşleştirilmiş ekranı aç</a></p>
<?php endif; ?>
</main></body></html>
