<?php
/** DijiScreen Hotel TV PMS v5 - reconciliation and dry-run. Does not modify guests/stays. */
declare(strict_types=1);
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_login();
$actor = user();
if (($actor['role'] ?? '') !== 'superadmin') { http_response_code(403); exit('Erişim reddedildi'); }
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (!isset($_SESSION['pms_v5_csrf'])) $_SESSION['pms_v5_csrf'] = bin2hex(random_bytes(32));
function p5e($x): string { return htmlspecialchars((string)$x, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$errors=[]; $message=''; $rows=[]; $connections=[]; $cid=(int)($_POST['connection_id'] ?? $_GET['connection_id'] ?? 0);
try {
 $connections=$pdo->query('SELECT c.id,c.hotel_id,c.provider_name,h.name hotel_name FROM hotel_pms_connections c JOIN hotel_properties h ON h.id=c.hotel_id ORDER BY c.id DESC')->fetchAll(PDO::FETCH_ASSOC);
 $allowed=[]; foreach($connections as $c) $allowed[(int)$c['id']]=$c;
 if ($cid && !isset($allowed[$cid])) throw new RuntimeException('Bağlantı bulunamadı');
 if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!hash_equals($_SESSION['pms_v5_csrf'], (string)($_POST['csrf']??''))) throw new RuntimeException('Oturum doğrulaması başarısız');
  if (!$cid) throw new RuntimeException('Bağlantı seçin');
  $action=(string)($_POST['action']??'');
  if ($action!=='reconcile') throw new RuntimeException('Geçersiz işlem');
  $pdo->beginTransaction();
  $stmt = $pdo->prepare("SELECT s.id, s.arrival_at, s.departure_at, r.id AS room_id
   FROM hotel_pms_import_staging s
   JOIN hotel_pms_connections c ON c.id=s.connection_id AND c.hotel_id=s.hotel_id
   JOIN hotel_properties h ON h.id=s.hotel_id AND h.status='active'
   LEFT JOIN hotel_pms_room_mappings m ON m.connection_id=s.connection_id AND m.hotel_id=s.hotel_id AND m.external_room_id=s.external_room_id
   LEFT JOIN hotel_branches b ON b.hotel_id=s.hotel_id AND b.status='active'
       AND b.id=(SELECT branch_id FROM hotel_rooms WHERE id=m.room_id)
   LEFT JOIN hotel_rooms r ON r.id=m.room_id AND r.branch_id=b.id AND r.status='active'
   WHERE s.connection_id=? AND s.status IN ('ready','needs_mapping')
   ORDER BY s.id DESC LIMIT 500 FOR UPDATE");
  $stmt->execute([$cid]); $data=$stmt->fetchAll(PDO::FETCH_ASSOC);
  $update=$pdo->prepare('UPDATE hotel_pms_import_staging SET status=?,validation_note=? WHERE id=? AND connection_id=?');
  $counts=['ready'=>0,'needs_mapping'=>0,'rejected'=>0];
  foreach($data as $r) {
   $status='ready'; $note='Oda eşleştirildi; canlı kayıt değişmedi';
   if (empty($r['room_id'])) { $status='needs_mapping'; $note='Oda eşleştirmesi eksik veya farklı otele ait'; }
   if ($r['arrival_at'] && $r['departure_at'] && $r['arrival_at'] >= $r['departure_at']) { $status='rejected'; $note='Ayrılış tarihi girişten sonra olmalı'; }
   $update->execute([$status,$note,(int)$r['id'],$cid]); $counts[$status]++;
  }
  $pdo->commit();
  $message='Kontrol tamamlandı (en yeni 500 uygun kayıt): hazır '.$counts['ready'].', eşleşme bekliyor '.$counts['needs_mapping'].', reddedildi '.$counts['rejected'].'. Canlı misafir kayıtları değiştirilmedi.';
 }
 if ($cid) {
  $stmt=$pdo->prepare('SELECT s.id,s.external_event_id,s.external_room_id,s.external_guest_id,s.event_type,s.guest_name,s.arrival_at,s.departure_at,s.status,s.validation_note,r.room_number FROM hotel_pms_import_staging s LEFT JOIN hotel_pms_room_mappings m ON m.connection_id=s.connection_id AND m.hotel_id=s.hotel_id AND m.external_room_id=s.external_room_id LEFT JOIN hotel_rooms r ON r.id=m.room_id AND r.branch_id IN (SELECT id FROM hotel_branches WHERE hotel_id=s.hotel_id) WHERE s.connection_id=? AND s.hotel_id=(SELECT hotel_id FROM hotel_pms_connections WHERE id=s.connection_id) ORDER BY s.id DESC LIMIT 200');
  $stmt->execute([$cid]); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
 }
} catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); error_log('[PMS v5] '.$e->getMessage()); $errors[]=$e instanceof PDOException?'Veritabanı sorgusu başarısız. Önce v1 ve v4 SQL kurulumlarını kontrol edin.':$e->getMessage(); }
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DijiScreen PMS v5</title><style>body{font:15px system-ui;background:#f2f5f9;color:#14263c;margin:0}.wrap{max-width:1180px;margin:32px auto;padding:0 18px}.panel{background:white;border:1px solid #dbe2ed;border-radius:14px;padding:22px;margin:18px 0}select,button{padding:11px;border-radius:8px}select{min-width:270px;border:1px solid #bfc9d6}button{background:#193f74;color:white;border:0;cursor:pointer}table{width:100%;border-collapse:collapse}td,th{padding:10px;text-align:left;border-bottom:1px solid #e6ebf0} .scroll{overflow:auto}.muted{color:#637083}.error{color:#a12020}.success{color:#166438}a{color:#193f74}</style></head><body><main class="wrap"><a href="pms_import_preview.php">← PMS v4</a><h1>PMS v5 · Eşleştirme ve Aktarım Kontrolü</h1><p class="muted">Hazırlık kayıtlarını yeniden doğrular, oda eşleşmelerini kontrol eder. Misafir ve konaklama tablolarına yazmaz.</p><?php foreach($errors as $e):?><p class="error"><?=p5e($e)?></p><?php endforeach;?><?php if($message):?><p class="success"><?=p5e($message)?></p><?php endif;?><section class="panel"><form method="post"><input type="hidden" name="csrf" value="<?=p5e($_SESSION['pms_v5_csrf'])?>"><input type="hidden" name="action" value="reconcile"><label>Bağlantı <select name="connection_id" required><option value="">Seçin</option><?php foreach($connections as $c):?><option value="<?=(int)$c['id']?>" <?=$cid===(int)$c['id']?'selected':''?>><?=p5e($c['hotel_name'].' · '.$c['provider_name'].' #'.$c['id'])?></option><?php endforeach;?></select></label> <button type="submit">Kayıtları yeniden kontrol et</button></form></section><section class="panel scroll"><h2>Son 200 hazırlık kaydı</h2><table><thead><tr><th>Olay</th><th>Harici oda</th><th>Yerel oda</th><th>Tür</th><th>Misafir</th><th>Durum</th><th>Açıklama</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=p5e($r['external_event_id'])?></td><td><?=p5e($r['external_room_id'])?></td><td><?=p5e($r['room_number']??'—')?></td><td><?=p5e($r['event_type'])?></td><td><?=p5e($r['guest_name'])?></td><td><?=p5e($r['status'])?></td><td><?=p5e($r['validation_note'])?></td></tr><?php endforeach;?></tbody></table><?php if(!$rows):?><p class="muted">Bağlantı seçin veya önce v4 üzerinden test kaydı oluşturun.</p><?php endif;?></section></main></body></html>
