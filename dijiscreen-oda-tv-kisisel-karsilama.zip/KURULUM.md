# DijiScreen oda TV karşılama paketi

Paket önceki oda TV tasarımını içerir. ZIP içindeki hotel-tv klasörünün içeriğini test sunucusundaki server/public/hotel-tv/ klasörüne birlikte yükleyin. SQL, cron veya APK güncellemesi gerekmez.

1. Örnek misafiri doğru odaya bağlayın ve konaklama kaydını giriş yapılmış durumuna alın.
2. **Hotel TV → TV Önizlemesi** ekranında oteli seçip gösterin. Odayı seçin ve **Oda bağlantısı oluştur** düğmesine basın.
3. **Kişisel oda ekranını aç** bağlantısını ilgili test TV’sinde açın. Ad ve soyad birkaç saniye içinde görünür. Genel ekran ve örnek ekran için mevcut iki bağlantı kullanılabilir.
4. Test konaklamasını çıkış yapılmış durumuna alın. TV sayfasını yenilemeden bekleyin. Sonraki sorguda isim silinir ve karşılama metni **Hoş geldiniz** olur.

Bağlantı 24 saat geçerlidir ve seçilen otel, oda, konaklama ve misafir kaydına bağlanır. Yeni misafir için yeni bağlantı gerekir. Kişisel bağlantıyı yalnızca ilgili TV’ye aktarın. Aynı odada birden fazla aktif konaklama bulunursa kişisel karşılama oluşturulmaz. Ekran normalde 15 saniyede bir yeniden kontrol eder, bağlantı kurulamadığında en fazla yedi saniyelik istek beklemesinin ardından adı gizler.

Otel logosunu aynı klasöre tv-logo-OTEL_ID.png adıyla yükleyin. Örneğin otel kimliği 1 için tv-logo-1.png. Logo eklenene kadar otel adı görünür. Varsayılan oda fotoğrafının kaynağı [Unsplash oda fotoğrafı](https://images.unsplash.com/photo-1611892440504-42a792e24d32) ve [Unsplash License](https://unsplash.com/license).

Kod, mevcut yerel konaklama ve misafir kayıtlarını kullanır. PMS’ten gerçek veri eşitlemesi mevcut entegrasyonun durumuna bağlıdır. Fiziksel TV kumandası ayrıca test edilmelidir.
