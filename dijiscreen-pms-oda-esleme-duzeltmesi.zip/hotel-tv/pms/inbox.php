<?php
declare(strict_types=1);
require_once __DIR__ . '/adapters.php';

function htv_pms_connection(PDO $pdo, int $connectionId, int $hotelId = 0): ?array
{
    $query = $pdo->prepare("SELECT c.id, c.hotel_id, c.status, p.provider_code, p.ingress, h.timezone
        FROM hotel_pms_connections c
        JOIN hotel_pms_adapter_profiles p ON p.connection_id=c.id
        JOIN hotel_properties h ON h.id=c.hotel_id AND h.status='active'
        WHERE c.id=? AND (?=0 OR c.hotel_id=?)");
    $query->execute([$connectionId, $hotelId, $hotelId]);
    return $query->fetch(PDO::FETCH_ASSOC) ?: null;
}

function htv_pms_can_receive(?array $connection, string $ingress): bool
{
    return $connection && $connection['ingress'] === $ingress
        && in_array($connection['status'], ['testing','active'], true);
}

function htv_pms_queue(PDO $pdo, array $connection, array $events): array
{
    $id = (int) $connection['id'];
    $received = $pdo->prepare("INSERT INTO hotel_pms_event_inbox
        (connection_id, external_event_id, event_type, external_reservation_id, occurred_at_utc, payload_json, payload_sha256)
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $existing = $pdo->prepare('SELECT payload_sha256 FROM hotel_pms_event_inbox WHERE connection_id=? AND external_event_id=? FOR UPDATE');
    $queued = 0;
    $duplicates = 0;
    $pdo->beginTransaction();
    try {
        $lock = $pdo->prepare("SELECT c.id FROM hotel_pms_connections c JOIN hotel_pms_adapter_profiles p ON p.connection_id=c.id
            JOIN hotel_properties h ON h.id=c.hotel_id AND h.status='active'
            WHERE c.id=? AND c.hotel_id=? AND c.status IN ('testing','active')
              AND p.ingress=? AND p.provider_code=? FOR UPDATE");
        $lock->execute([$id, $connection['hotel_id'], $connection['ingress'], $connection['provider_code']]);
        if (!$lock->fetchColumn()) throw new DomainException('Bağlantı artık bu işlem için açık değil.');
        foreach ($events as $event) {
            $json = json_encode($event, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
            $hash = hash('sha256', $json);
            try {
                $received->execute([$id, $event['event_id'], $event['type'], $event['reservation_id'],
                    str_replace('T', ' ', substr($event['occurred_at'], 0, 19)), $json, $hash]);
                $queued++;
            } catch (PDOException $ex) {
                if ((int) ($ex->errorInfo[1] ?? 0) !== 1062) throw $ex;
                $existing->execute([$id, $event['event_id']]);
                if ($existing->fetchColumn() !== $hash) {
                    throw new DomainException('Olay kimliği farklı içerikle zaten kayıtlı. Yeni kayıt eklenmedi.');
                }
                $duplicates++;
            }
        }
        if ($queued) {
            $touch = $pdo->prepare('UPDATE hotel_pms_adapter_profiles SET last_received_at=NOW() WHERE connection_id=?');
            $touch->execute([$id]);
        }
        $pdo->commit();
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
    return ['queued'=>$queued, 'duplicates'=>$duplicates];
}

function htv_pms_attempt(PDO $pdo, int $id, string $status, ?string $code): void
{
    $log = $pdo->prepare('INSERT INTO hotel_pms_event_attempts (event_id, outcome, error_code) VALUES (?, ?, ?)');
    $log->execute([$id, $status, $code]);
}

function htv_pms_run_next(PDO $pdo): ?string
{
    $job = null;
    $pdo->beginTransaction();
    try {
        $job = $pdo->query("SELECT i.id, i.connection_id, i.attempts, i.payload_json, i.payload_sha256, c.hotel_id, h.timezone
            FROM hotel_pms_event_inbox i
            JOIN hotel_pms_connections c ON c.id=i.connection_id AND c.status IN ('testing','active')
            JOIN hotel_properties h ON h.id=c.hotel_id AND h.status='active'
            WHERE i.status IN ('queued','retry') AND i.available_at <= NOW()
            ORDER BY i.available_at, i.id LIMIT 1 FOR UPDATE SKIP LOCKED")->fetch(PDO::FETCH_ASSOC);
        if (!$job) {
            $pdo->commit();
            return null;
        }
        $event = json_decode($job['payload_json'], true, 32, JSON_THROW_ON_ERROR);
        $findRoom = $pdo->prepare("SELECT m.hotel_id AS mapping_hotel, r.id, r.status AS room_status,
                b.hotel_id AS room_hotel, b.status AS branch_status
            FROM hotel_pms_room_mappings m
            LEFT JOIN hotel_rooms r ON r.id=m.room_id
            LEFT JOIN hotel_branches b ON b.id=r.branch_id
            WHERE m.connection_id=? AND m.external_room_id=?");
        $findRoom->execute([$job['connection_id'], $event['room_id']]);
        $mapping = $findRoom->fetch(PDO::FETCH_ASSOC);
        $code = match (true) {
            !$mapping => 'room_mapping_missing',
            (int)$mapping['mapping_hotel'] !== (int)$job['hotel_id']
                || (int)$mapping['room_hotel'] !== (int)$job['hotel_id'] => 'room_mapping_wrong_hotel',
            $mapping['branch_status'] !== 'active' => 'room_branch_inactive',
            $mapping['room_status'] !== 'active' => 'room_inactive',
            default => null,
        };
        $room = $code === null ? $mapping['id'] : null;
        $status = $room ? 'staged' : 'needs_mapping';

        if ($room) {
            $tz = new DateTimeZone($job['timezone']);
            $dates = array_map(static fn ($date) => $date
                ? (new DateTimeImmutable($date))->setTimezone($tz)->format('Y-m-d H:i:s') : null,
                [$event['arrival_at'], $event['departure_at']]);
            $stage = $pdo->prepare("INSERT INTO hotel_pms_import_staging (connection_id, hotel_id, external_event_id,
                external_room_id, external_guest_id, event_type, guest_name, arrival_at, departure_at, status,
                validation_note, payload_sha256)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ready', 'Standart olay: inceleme bekliyor', ?)");
            $stage->execute([$job['connection_id'], $job['hotel_id'], 'universal:' . $job['id'],
                $event['room_id'], $event['guest_id'], $event['type'], $event['guest_name'], $dates[0], $dates[1],
                $job['payload_sha256']]);
            $touch = $pdo->prepare('UPDATE hotel_pms_adapter_profiles SET last_staged_at=NOW() WHERE connection_id=?');
            $touch->execute([$job['connection_id']]);
        }
        $save = $pdo->prepare('UPDATE hotel_pms_event_inbox SET status=?, last_error_code=?, attempts=attempts+1, processed_at=NOW() WHERE id=?');
        $save->execute([$status, $code, $job['id']]);
        htv_pms_attempt($pdo, (int) $job['id'], $status, $code);
        $pdo->commit();
        return $status;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        if (!$job) throw $ex;
        $dbCode = $ex instanceof PDOException ? (int) ($ex->errorInfo[1] ?? 0) : 0;
        $transient = $ex instanceof PDOException && in_array($dbCode, [1205, 1213], true);
        $attempt = (int) $job['attempts'] + 1;
        $status = $transient && $attempt < 5 ? 'retry' : 'failed';
        $code = $transient ? 'database_lock' : ($dbCode === 1062 ? 'staging_identity_conflict' : 'processing_failed');
        $pdo->beginTransaction();
        try {
            // If another worker obtained the row after rollback, its result wins.
            $save = $pdo->prepare("UPDATE hotel_pms_event_inbox SET status=?, last_error_code=?, attempts=attempts+1,
                available_at=TIMESTAMPADD(SECOND, ?, NOW()), processed_at=NOW()
                WHERE id=? AND attempts=? AND status IN ('queued','retry')");
            $save->execute([$status, $code, min(900, 30 * (2 ** min($attempt - 1, 5))), $job['id'], $job['attempts']]);
            if ($save->rowCount()) htv_pms_attempt($pdo, (int) $job['id'], $status, $code);
            $pdo->commit();
        } catch (Throwable $retryError) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $retryError;
        }
        error_log('[Hotel TV PMS worker] event=' . (int) $job['id'] . ' code=' . $code);
        return $status;
    }
}

function htv_pms_requeue(PDO $pdo, int $connectionId, int $hotelId, int $eventId): bool
{
    $pdo->beginTransaction();
    try {
        $update = $pdo->prepare("UPDATE hotel_pms_event_inbox i JOIN hotel_pms_connections c ON c.id=i.connection_id
            SET i.status='queued', i.available_at=NOW(), i.last_error_code=NULL, i.processed_at=NULL, i.attempts=0
            WHERE i.id=? AND c.id=? AND c.hotel_id=? AND i.status IN ('needs_mapping','failed')");
        $update->execute([$eventId, $connectionId, $hotelId]);
        $changed = $update->rowCount() === 1;
        if ($changed) htv_pms_attempt($pdo, $eventId, 'requeued', null);
        $pdo->commit();
        return $changed;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
}
