<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_login();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
function esc($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$me = user();
if (($me['role'] ?? '') !== 'superadmin') { http_response_code(403); exit('Bu yapılandırma ekranı yalnızca sistem yöneticisine açıktır.'); }
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
if (empty($_SESSION['hotel_pms_csrf'])) { $_SESSION['hotel_pms_csrf'] = bin2hex(random_bytes(32)); }
$csrf = $_SESSION['hotel_pms_csrf'];
$hotels = $pdo->query('SELECT id,name FROM hotel_properties ORDER BY name')->fetchAll(PDO::FETCH_ASSOC);
$hotelId = (int)($_POST['hotel_id'] ?? $_GET['hotel_id'] ?? ($hotels[0]['id'] ?? 0));
if (!in_array($hotelId, array_map(static fn($h)=>(int)$h['id'], $hotels), true)) { $hotelId=(int)($hotels[0]['id'] ?? 0); }
$error=''; $message='';
$selectedConnection = (int) ($_POST['connection_id'] ?? $_GET['connection_id'] ?? 0);
if ($_SERVER['REQUEST_METHOD']==='POST') {
 try {
  if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) { throw new RuntimeException('Oturum doğrulaması başarısız. Sayfayı yenileyin.'); }
  if (!$hotelId) { throw new RuntimeException('Önce otel oluşturun.'); }
  $action=(string)($_POST['action'] ?? '');
  if ($action==='add_connection') {
   $provider=trim((string)($_POST['provider_name'] ?? ''));
   if (mb_strlen($provider)<2 || mb_strlen($provider)>190) { throw new RuntimeException('Sağlayıcı adı 2-190 karakter olmalı.'); }
   $stmt=$pdo->prepare("INSERT INTO hotel_pms_connections (hotel_id,provider_name,connection_type,status) VALUES (?,?,'manual','not_configured')");
   $stmt->execute([$hotelId,$provider]);
   $message='Sağlayıcı taslağı oluşturuldu. Henüz harici sisteme bağlantı yapılmaz.';
  } elseif ($action==='map_room') {
   $connectionId=(int)($_POST['connection_id'] ?? 0); $roomId=(int)($_POST['room_id'] ?? 0);
   $external=trim((string)($_POST['external_room_id'] ?? ''));
   if ($external==='' || mb_strlen($external)>190) { throw new RuntimeException('Harici oda kodu 1-190 karakter olmalı.'); }
   $pdo->beginTransaction();
   $stmt = $pdo->prepare('SELECT id FROM hotel_pms_connections WHERE id=? AND hotel_id=? FOR UPDATE');
   $stmt->execute([$connectionId, $hotelId]);
   if (!$stmt->fetchColumn()) throw new RuntimeException('Bağlantı bu otele ait değil.');
   $stmt = $pdo->prepare("SELECT r.id FROM hotel_rooms r
       JOIN hotel_branches b ON b.id=r.branch_id AND b.status='active'
       JOIN hotel_properties h ON h.id=b.hotel_id AND h.status='active'
       WHERE r.id=? AND b.hotel_id=? AND r.status='active'");
   $stmt->execute([$roomId, $hotelId]);
   if (!$stmt->fetchColumn()) throw new RuntimeException('Etkin bir şubeye bağlı, aktif bir oda seçin.');
   $stmt = $pdo->prepare('SELECT room_id FROM hotel_pms_room_mappings WHERE connection_id=? AND external_room_id=?');
   $stmt->execute([$connectionId, $external]);
   $oldRoom = $stmt->fetchColumn();
   if ($oldRoom !== false && (int) $oldRoom !== $roomId) {
       throw new RuntimeException('Harici kod bu bağlantıda başka bir odaya bağlı. Önce mevcut eşlemeyi kontrol edin.');
   }
   $stmt = $pdo->prepare('INSERT INTO hotel_pms_room_mappings (connection_id,hotel_id,room_id,external_room_id)
       VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE hotel_id=VALUES(hotel_id), external_room_id=VALUES(external_room_id), updated_at=CURRENT_TIMESTAMP');
   $stmt->execute([$connectionId, $hotelId, $roomId, $external]);
   $pdo->commit();
   $message='Oda eşleştirmesi Bağlantı #' . $connectionId . ' için kaydedildi.';
  } elseif ($action==='remove_mapping') {
   $id=(int)($_POST['mapping_id'] ?? 0);
   $stmt=$pdo->prepare('DELETE FROM hotel_pms_room_mappings WHERE id=? AND hotel_id=?'); $stmt->execute([$id,$hotelId]);
   $message='Eşleştirme kaldırıldı.';
  } else { throw new RuntimeException('Bilinmeyen işlem.'); }
 } catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); $error=$e instanceof PDOException ? 'Veritabanı işlemi tamamlanamadı. Aynı oda veya harici kod zaten eşleştirilmiş olabilir.' : $e->getMessage(); error_log('PMS setup: '.$e->getMessage()); }
}
$connections=[]; $rooms=[]; $mappings=[];
if ($hotelId) {
 $stmt=$pdo->prepare('SELECT id,provider_name,status FROM hotel_pms_connections WHERE hotel_id=? ORDER BY id DESC'); $stmt->execute([$hotelId]); $connections=$stmt->fetchAll(PDO::FETCH_ASSOC);
 $stmt=$pdo->prepare('SELECT r.id, r.room_number,b.name branch_name,r.status AS room_status,b.status AS branch_status FROM hotel_rooms r JOIN hotel_branches b ON b.id=r.branch_id WHERE b.hotel_id=? ORDER BY b.name,r.room_number'); $stmt->execute([$hotelId]); $rooms=$stmt->fetchAll(PDO::FETCH_ASSOC);
 try { $stmt=$pdo->prepare('SELECT m.id,m.connection_id,m.external_room_id,c.provider_name,r.room_number,b.name branch_name,r.status room_status,b.status branch_status,b.hotel_id room_hotel_id FROM hotel_pms_room_mappings m JOIN hotel_pms_connections c ON c.id=m.connection_id JOIN hotel_rooms r ON r.id=m.room_id JOIN hotel_branches b ON b.id=r.branch_id WHERE m.hotel_id=? AND c.hotel_id=m.hotel_id ORDER BY m.connection_id,m.id DESC'); $stmt->execute([$hotelId]); $mappings=$stmt->fetchAll(PDO::FETCH_ASSOC); }
 catch (PDOException $e) { $error='PMS v1 SQL tabloları bulunamadı veya okunamadı.'; }
}
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DijiScreen PMS Kurulum</title><style>body{font:15px system-ui,Arial;background:#f2f5fa;color:#18263a;margin:0}.wrap{max-width:1000px;margin:30px auto;padding:0 18px}.panel{background:white;border:1px solid #dfe5ed;border-radius:14px;padding:22px;margin:18px 0}input,select,button{padding:11px;border:1px solid #c8d2e0;border-radius:8px;max-width:100%;box-sizing:border-box}button{background:#153d72;color:white;cursor:pointer;border:0}label{display:block;margin:12px 0 5px;font-weight:600}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #e5e9ef;text-align:left}.scroll{overflow:auto}.msg{padding:12px;background:#e6f5eb;border-radius:8px}.err{padding:12px;background:#ffe9e7;border-radius:8px}.muted{color:#607086}form.inline{display:inline}h1{margin-bottom:5px}</style></head><body><main class="wrap"><a href="pms.php">← PMS Durumu</a><h1>PMS Bağlantı ve Oda Eşleştirme</h1><p class="muted">Yönetici kurulumu · Harici PMS ile otomatik veri alışverişi henüz etkin değildir.</p>
<?php if($error):?><p class="err"><?=esc($error)?></p><?php endif;?><?php if($message):?><p class="msg"><?=esc($message)?></p><?php endif;?>
<section class="panel"><form method="get"><label>Otel</label><select name="hotel_id" onchange="this.form.submit()"><?php foreach($hotels as $h):?><option value="<?=(int)$h['id']?>" <?=((int)$h['id']===$hotelId?'selected':'')?>><?=esc($h['name'])?></option><?php endforeach;?></select> <button>Seç</button></form></section>
<section class="panel"><h2>1. PMS Sağlayıcı Taslağı</h2><form method="post"><input type="hidden" name="csrf" value="<?=esc($csrf)?>"><input type="hidden" name="hotel_id" value="<?=$hotelId?>"><input type="hidden" name="action" value="add_connection"><label>Sağlayıcı adı</label><input name="provider_name" maxlength="190" required placeholder="Örn. Otel PMS sağlayıcısı" style="width:360px"> <button>Sağlayıcı ekle</button></form><p class="muted">API anahtarı, şifre veya canlı bağlantı burada alınmaz.</p><div class="scroll"><table><tr><th>Sağlayıcı</th><th>Durum</th></tr><?php foreach($connections as $c):?><tr><td><?=esc($c['provider_name'].' · #'.$c['id'])?></td><td><?=esc($c['status'])?></td></tr><?php endforeach;?></table></div></section>
<section class="panel"><h2>2. Oda Eşleştirme</h2><form method="post"><input type="hidden" name="csrf" value="<?=esc($csrf)?>"><input type="hidden" name="hotel_id" value="<?=$hotelId?>"><input type="hidden" name="action" value="map_room"><label>PMS bağlantısı</label><select name="connection_id" required><?php foreach($connections as $c):?><option value="<?=(int)$c['id']?>" <?= (int)$c['id']===$selectedConnection ? 'selected' : '' ?>><?=esc($c['provider_name'].' · #'.$c['id'])?></option><?php endforeach;?></select><label>DijiScreen odası</label><select name="room_id" required><?php foreach($rooms as $r):?><option value="<?=(int)$r['id']?>" <?= ($r['room_status']!=='active'||$r['branch_status']!=='active')?'disabled':'' ?>><?=esc($r['branch_name'].' / '.$r['room_number'].(($r['room_status']!=='active'||$r['branch_status']!=='active')?' · Kullanılamıyor':''))?></option><?php endforeach;?></select><label>PMS tarafındaki oda ID/kodu</label><input name="external_room_id" maxlength="190" required placeholder="Örn. ROOM-101"> <button <?=(!$connections||!$rooms?'disabled':'')?>>Eşleştir</button></form><p class="muted">Bir bağlantıdaki oda yalnızca bir harici oda koduyla eşleştirilebilir.</p><div class="scroll"><table><tr><th>Sağlayıcı</th><th>Oda</th><th>Harici kod</th><th>Eşleme durumu</th><th>İşlem</th></tr><?php foreach($mappings as $m):?><tr><td><?=esc($m['provider_name'].' · #'.$m['connection_id'])?></td><td><?=esc($m['branch_name'].' / '.$m['room_number'])?></td><td><?=esc($m['external_room_id'])?></td><td><?=esc(
    (int)$m['room_hotel_id'] !== $hotelId ? 'Oda farklı otele bağlı' :
    ($m['branch_status']!=='active' ? 'Şube pasif' : ($m['room_status']!=='active' ? 'Oda aktif değil' : 'Kullanılabilir'))
)?></td><td><form class="inline" method="post" onsubmit="return confirm('Eşleştirme kaldırılsın mı?')"><input type="hidden" name="csrf" value="<?=esc($csrf)?>"><input type="hidden" name="hotel_id" value="<?=$hotelId?>"><input type="hidden" name="action" value="remove_mapping"><input type="hidden" name="mapping_id" value="<?=(int)$m['id']?>"><button>Kaldır</button></form></td></tr><?php endforeach;?></table></div></section></main></body></html>
