# PMS oda eşleme düzeltmesi

Bu üç dosyayı mevcut evrensel PMS paketi üzerine, test sunucusundaki server/public/hotel-tv/ konumuna klasör yapısını koruyarak yükleyin. SQL veya cron değişikliği gerekmez.

Bağlantı #1 sayfasından Oda eşlemeleri bağlantısını açın. Bağlantı numarası formda seçili ve tablodaki her satırda görünür. Harici oda kodu 101 için yerel odanın eşleme durumunu kontrol edin. Etkin olmayan oda veya şube ile başka otele bağlı oda kuyrukta işlenmez. Var olan bir harici oda kodunu ikinci bir odaya sessizce kaydetmek yerine form hata gösterir. Eşleme kullanıma hazırsa olay satırında bir kez Yeniden dene seçilir. İşleyicinin yeni sonucu panelde açıklama olarak görünür.

Yerel MariaDB ile genel PMS akışı, bağlantı seçimi, aktif oda kaydetme ve bakım durumundaki odanın reddi doğrulandı.
