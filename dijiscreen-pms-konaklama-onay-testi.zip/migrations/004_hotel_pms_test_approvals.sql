CREATE TABLE IF NOT EXISTS hotel_pms_test_approvals (
    event_id BIGINT UNSIGNED NOT NULL,
    actor_user_id INT UNSIGNED NOT NULL,
    stay_id BIGINT UNSIGNED NOT NULL,
    approved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (event_id),
    KEY idx_pms_test_approvals_stay (stay_id),
    CONSTRAINT fk_pms_approval_event FOREIGN KEY (event_id) REFERENCES hotel_pms_event_inbox(id) ON DELETE CASCADE
) ENGINE=InnoDB;
