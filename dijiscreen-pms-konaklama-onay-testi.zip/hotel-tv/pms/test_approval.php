<?php
declare(strict_types=1);

function htv_pms_test_approval_enabled(): bool
{
    return getenv('HTV_PMS_APPROVAL_TEST') === '1';
}

function htv_pms_approval_room(PDO $pdo, int $connection, int $hotel, string $external, bool $active = true): array
{
    $status = $active ? "AND r.status='active' AND b.status='active'" : '';
    $query = $pdo->prepare("SELECT r.id, r.branch_id, r.room_number
        FROM hotel_pms_room_mappings m JOIN hotel_rooms r ON r.id=m.room_id
        JOIN hotel_branches b ON b.id=r.branch_id AND b.hotel_id=m.hotel_id
        WHERE m.connection_id=? AND m.hotel_id=? AND m.external_room_id=? $status FOR UPDATE");
    $query->execute([$connection, $hotel, $external]);
    $room = $query->fetch(PDO::FETCH_ASSOC);
    if (!$room) throw new DomainException('Oda eşlemesi artık geçerli değil. Önce oda eşlemesini kontrol edin.');
    return $room;
}

function htv_pms_approval_link(PDO $pdo, int $connection, int $hotel, string $kind, string $id): ?array
{
    $query = $pdo->prepare('SELECT hotel_id, local_id, external_updated_at, external_id FROM hotel_pms_record_links
        WHERE connection_id=? AND record_type=? AND external_id=? FOR UPDATE');
    $query->execute([$connection, $kind, $id]);
    $link = $query->fetch(PDO::FETCH_ASSOC);
    if ($link && ((int)$link['hotel_id'] !== $hotel || $link['external_id'] !== $id)) {
        throw new DomainException('Harici kayıt kimliği doğrulanamadı.');
    }
    return $link ?: null;
}

function htv_pms_name_columns(string $name): array
{
    if (mb_strlen($name) <= 100) return [$name, null];
    $limit = mb_substr($name, 0, 101);
    $split = mb_strrpos($limit, ' ');
    if ($split === false || $split < mb_strlen($name) - 101) {
        throw new DomainException('Misafir adı mevcut kayıt alanlarına sığmıyor.');
    }
    return [mb_substr($name, 0, $split), mb_substr($name, $split + 1)];
}

function htv_pms_test_apply(PDO $pdo, int $hotel, int $connection, int $eventId, int $actor, int $reviewedRoom): int
{
    if (!htv_pms_test_approval_enabled()) throw new DomainException('Test uygulaması kapalı.');
    $pdo->beginTransaction();
    try {
        $query = $pdo->prepare("SELECT i.payload_json, i.occurred_at_utc, h.timezone, NOW() server_now, UTC_TIMESTAMP() utc_now
            FROM hotel_pms_event_inbox i JOIN hotel_pms_connections c ON c.id=i.connection_id AND c.status='testing'
            JOIN hotel_properties h ON h.id=c.hotel_id AND h.status='active'
            WHERE i.id=? AND i.connection_id=? AND c.hotel_id=? AND i.status='staged' FOR UPDATE");
        $query->execute([$eventId, $connection, $hotel]);
        $row = $query->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new DomainException('İncelemeye hazır ve bu otele ait bir test olayı seçin.');
        $query = $pdo->prepare('SELECT stay_id FROM hotel_pms_test_approvals WHERE event_id=?');
        $query->execute([$eventId]);
        $approvedStay = $query->fetchColumn();
        if ($approvedStay) {
            $pdo->commit();
            return (int)$approvedStay;
        }

        $event = json_decode($row['payload_json'], true, 32, JSON_THROW_ON_ERROR);
        $type = $event['type'];
        if (!in_array($type, ['reservation.created','reservation.updated','guest.checked_in','guest.checked_out',
            'room.changed','guest.updated'], true)) throw new DomainException('Olay uygulamaya uygun değil.');
        $when = $row['occurred_at_utc'];
        if ($when > $row['utc_now']) throw new DomainException('Gelecekteki olay zamanı uygulanamaz.');
        $tz = new DateTimeZone($row['timezone']);
        $local = static fn (?string $value): ?string => $value
            ? (new DateTimeImmutable($value, new DateTimeZone('UTC')))->setTimezone($tz)->format('Y-m-d H:i:s') : null;
        $arrival = $local($event['arrival_at']);
        $departure = $local($event['departure_at']);
        $occurred = $local($when);
        $now = $row['server_now'];
        if ($local($row['utc_now']) !== $now) {
            throw new DomainException('Test işlemi için otel ve veritabanı saat dilimleri eşleşmeli.');
        }
        $stayLink = htv_pms_approval_link($pdo, $connection, $hotel, 'stay', $event['reservation_id']);
        $guestLink = htv_pms_approval_link($pdo, $connection, $hotel, 'guest', $event['guest_id']);
        if ($stayLink && $stayLink['external_updated_at'] && $stayLink['external_updated_at'] >= $when) {
            throw new DomainException('Daha yeni veya aynı zamanlı bir olay uygulanmış.');
        }

        $stay = null;
        $stayId = (int)($stayLink['local_id'] ?? 0);
        $guestId = (int)($guestLink['local_id'] ?? 0);
        if ($stayId) {
            $query = $pdo->prepare("SELECT s.* FROM hotel_stays s
                WHERE s.id=? AND s.hotel_id=? AND s.source='pms'
                  AND EXISTS (SELECT 1 FROM hotel_pms_test_approvals a JOIN hotel_pms_event_inbox i ON i.id=a.event_id
                    WHERE a.stay_id=s.id AND i.connection_id=? AND i.event_type='reservation.created')
                FOR UPDATE");
            $query->execute([$stayId, $hotel, $connection]);
            $stay = $query->fetch(PDO::FETCH_ASSOC);
            if (!$stay || !$guestId || (int)$stay['guest_id'] !== $guestId) {
                throw new DomainException('Konaklama veya misafir bağlantısı doğrulanamadı.');
            }
        }
        if ($guestId) {
            $query = $pdo->prepare("SELECT g.id FROM hotel_guests g WHERE g.id=? AND g.hotel_id=?
                AND EXISTS (SELECT 1 FROM hotel_stays s JOIN hotel_pms_test_approvals a ON a.stay_id=s.id
                    JOIN hotel_pms_event_inbox i ON i.id=a.event_id
                    WHERE s.guest_id=g.id AND s.hotel_id=g.hotel_id AND s.source='pms'
                      AND i.connection_id=? AND i.event_type='reservation.created')
                FOR UPDATE");
            $query->execute([$guestId, $hotel, $connection]);
            if (!$query->fetchColumn()) throw new DomainException('Misafir bağlantısı artık geçerli değil.');
        }
        if (!$stay && $type !== 'reservation.created') {
            throw new DomainException('Önce bu rezervasyonun oluşturma olayını uygulayın.');
        }
        if ($stay && in_array($stay['status'], ['checked_out','cancelled'], true)) {
            throw new DomainException('Kapalı konaklama değiştirilemez.');
        }
        if ($stay && $type === 'reservation.created') throw new DomainException('Bu rezervasyon daha önce oluşturulmuş.');

        $room = htv_pms_approval_room($pdo, $connection, $hotel, $event['room_id'], $type !== 'guest.checked_out');
        if ((int)$room['id'] !== $reviewedRoom) {
            throw new DomainException('Oda eşlemesi incelemeden sonra değişmiş. Olayı tekrar inceleyin.');
        }
        if ($stay && $type === 'room.changed') {
            $previous = htv_pms_approval_room($pdo, $connection, $hotel, $event['previous_room_id'], false);
            if ((int)$previous['id'] !== (int)$stay['room_id'] || (int)$room['id'] === (int)$stay['room_id']) {
                throw new DomainException('Önceki oda mevcut konaklamayla eşleşmiyor.');
            }
        } elseif ($stay && (int)$room['id'] !== (int)$stay['room_id']) {
            throw new DomainException('Odayı değiştirmek için ayrı oda değişikliği olayı gerekli.');
        }

        $status = $stay['status'] ?? 'reserved';
        $start = $stay['check_in_at'] ?? $arrival;
        $end = $stay['check_out_at'] ?? $departure;
        if ($type === 'reservation.updated') {
            if ($status !== 'reserved') throw new DomainException('Rezervasyon tarih güncellemesi girişten önce uygulanır.');
            $start = $arrival ?? $start;
            $end = $departure ?? $end;
        } elseif ($type === 'guest.checked_in') {
            if ($status !== 'reserved' || $occurred > $now) throw new DomainException('Giriş durumu veya saati geçersiz.');
            $status = 'checked_in';
            $start = $occurred;
        } elseif ($type === 'guest.checked_out') {
            if ($status !== 'checked_in' || $occurred > $now) throw new DomainException('Çıkış durumu veya saati geçersiz.');
            $status = 'checked_out';
            $end = $occurred;
        }
        if (!$start || !$end || $end <= $start) throw new DomainException('Geçerli bir giriş ve çıkış aralığı gerekli.');
        if (in_array($type, ['reservation.created','reservation.updated','guest.checked_in','room.changed'], true)) {
            $query = $pdo->prepare("SELECT id FROM hotel_stays WHERE hotel_id=? AND room_id=? AND id<>?
                AND status IN ('reserved','checked_in') AND check_in_at < ?
                AND (check_out_at IS NULL OR check_out_at > ?) LIMIT 1 FOR UPDATE");
            $query->execute([$hotel, $room['id'], $stayId, $end, $start]);
            if ($query->fetchColumn()) throw new DomainException('Hedef odada çakışan bir konaklama var.');
        }

        if (!$guestId || $type === 'guest.updated') {
            if ($guestLink && $guestLink['external_updated_at'] && $guestLink['external_updated_at'] >= $when) {
                throw new DomainException('Misafir için daha yeni veya aynı zamanlı bir olay uygulanmış.');
            }
            [$first, $last] = htv_pms_name_columns($event['guest_name']);
            if (!$guestId) {
                $query = $pdo->prepare('INSERT INTO hotel_guests(hotel_id, first_name, last_name) VALUES (?,?,?)');
                $query->execute([$hotel, $first, $last]);
                $guestId = (int)$pdo->lastInsertId();
                $query = $pdo->prepare("INSERT INTO hotel_pms_record_links
                    (connection_id, hotel_id, record_type, external_id, local_id, external_updated_at, synced_at)
                    VALUES (?,?,'guest',?,?,?,NOW())");
                $query->execute([$connection, $hotel, $event['guest_id'], $guestId, $when]);
            } else {
                $query = $pdo->prepare('UPDATE hotel_guests SET first_name=?, last_name=? WHERE id=? AND hotel_id=?');
                $query->execute([$first, $last, $guestId, $hotel]);
                $query = $pdo->prepare("UPDATE hotel_pms_record_links SET external_updated_at=?, synced_at=NOW()
                    WHERE connection_id=? AND hotel_id=? AND record_type='guest' AND external_id=?");
                $query->execute([$when, $connection, $hotel, $event['guest_id']]);
            }
        }

        if (!$stayId) {
            $query = $pdo->prepare("INSERT INTO hotel_stays
                (hotel_id, branch_id, room_id, guest_id, reservation_ref, check_in_at, check_out_at, status, source)
                VALUES (?,?,?,?,?,?,?,?,'pms')");
            $reference = mb_strlen($event['reservation_id']) <= 100 ? $event['reservation_id'] : null;
            $query->execute([$hotel, $room['branch_id'], $room['id'], $guestId, $reference, $start, $end, $status]);
            $stayId = (int)$pdo->lastInsertId();
            $query = $pdo->prepare("INSERT INTO hotel_pms_record_links
                (connection_id, hotel_id, record_type, external_id, local_id, external_updated_at, synced_at)
                VALUES (?,?,'stay',?,?,?,NOW())");
            $query->execute([$connection, $hotel, $event['reservation_id'], $stayId, $when]);
        } else {
            if ($type !== 'guest.updated') {
                $query = $pdo->prepare("UPDATE hotel_stays SET branch_id=?, room_id=?, check_in_at=?, check_out_at=?, status=?
                    WHERE id=? AND hotel_id=? AND source='pms'");
                $query->execute([$room['branch_id'], $room['id'], $start, $end, $status, $stayId, $hotel]);
            }
            $query = $pdo->prepare("UPDATE hotel_pms_record_links SET external_updated_at=?, synced_at=NOW()
                WHERE connection_id=? AND hotel_id=? AND record_type='stay' AND external_id=?");
            $query->execute([$when, $connection, $hotel, $event['reservation_id']]);
        }
        $query = $pdo->prepare('INSERT INTO hotel_pms_test_approvals(event_id, actor_user_id, stay_id) VALUES (?,?,?)');
        $query->execute([$eventId, $actor, $stayId]);
        $pdo->commit();
        return $stayId;
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $ex;
    }
}
