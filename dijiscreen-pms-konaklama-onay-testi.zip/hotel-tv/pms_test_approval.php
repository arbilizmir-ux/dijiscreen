<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
require_once __DIR__ . '/pms/test_approval.php';
require_admin();
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');

$source = $_SERVER['REQUEST_METHOD'] === 'POST' ? INPUT_POST : INPUT_GET;
$positive = ['options'=>['min_range'=>1]];
$hotel = filter_input($source, 'hotel_id', FILTER_VALIDATE_INT, $positive) ?: 0;
$connection = filter_input($source, 'connection_id', FILTER_VALIDATE_INT, $positive) ?: 0;
$eventId = filter_input($source, 'event_id', FILTER_VALIDATE_INT, $positive) ?: 0;
if (!$hotel || !$connection || !$eventId) {
    http_response_code(400);
    exit('Otel, bağlantı ve olay seçin.');
}

$enabled = htv_pms_test_approval_enabled();
$message = $error = '';
$record = $event = $targetRoom = null;
try {
    if ($enabled && $_SERVER['REQUEST_METHOD'] === 'POST') {
        htv_check_csrf();
        if (($_POST['action'] ?? '') !== 'apply') throw new DomainException('İşlem geçersiz.');
        $reviewedRoom = filter_input(INPUT_POST, 'reviewed_room', FILTER_VALIDATE_INT, $positive) ?: 0;
        if (!$reviewedRoom) throw new DomainException('Önce hedef odayı inceleyin.');
        $local = htv_pms_test_apply($pdo, $hotel, $connection, $eventId, (int)user()['id'], $reviewedRoom);
        $message = 'Konaklama kaydı #' . $local . ' için uygulama kaydedildi.';
    }
} catch (DomainException $ex) {
    $error = $ex->getMessage();
} catch (Throwable $ex) {
    error_log('[Hotel TV PMS approval] event=' . $eventId . ' error=' . get_class($ex));
    $error = 'Aktarım tamamlanamadı. Test geçişini ve sunucu kayıtlarını kontrol edin.';
}

try {
    $sql = 'SELECT i.payload_json, i.status, c.status AS connection_status, h.name AS hotel_name, c.provider_name'
        . ($enabled ? ', a.stay_id, a.approved_at' : '')
        . ' FROM hotel_pms_event_inbox i JOIN hotel_pms_connections c ON c.id=i.connection_id
            JOIN hotel_properties h ON h.id=c.hotel_id'
        . ($enabled ? ' LEFT JOIN hotel_pms_test_approvals a ON a.event_id=i.id' : '')
        . ' WHERE i.id=? AND i.connection_id=? AND c.hotel_id=?';
    $query = $pdo->prepare($sql);
    $query->execute([$eventId, $connection, $hotel]);
    $record = $query->fetch(PDO::FETCH_ASSOC);
    if (!$record) htv_access_denied();
    $event = json_decode($record['payload_json'], true, 32, JSON_THROW_ON_ERROR);
    $query = $pdo->prepare("SELECT r.id, r.room_number, b.name AS branch_name
        FROM hotel_pms_room_mappings m JOIN hotel_rooms r ON r.id=m.room_id
        JOIN hotel_branches b ON b.id=r.branch_id AND b.hotel_id=m.hotel_id
        WHERE m.connection_id=? AND m.hotel_id=? AND m.external_room_id=?");
    $query->execute([$connection, $hotel, $event['room_id']]);
    $targetRoom = $query->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $ex) {
    error_log('[Hotel TV PMS approval review] event=' . $eventId . ' error=' . get_class($ex));
    $error = 'Olay ayrıntısı okunamadı. Test SQL geçişini kontrol edin.';
}
layout_start('PMS olay incelemesi');
?>
<h1>PMS olay incelemesi</h1>
<p><a href="pms_integrations.php?hotel_id=<?= $hotel ?>&amp;connection_id=<?= $connection ?>">Olay kuyruğuna dön</a></p>
<?php if ($message): ?><p role="status"><?= e($message) ?></p><?php endif; ?>
<?php if ($error): ?><p role="alert"><?= e($error) ?></p><?php endif; ?>
<?php if ($event): ?>
    <dl>
        <dt>Otel ve bağlantı</dt><dd><?= e($record['hotel_name'].' · '.$record['provider_name'].' #'.$connection) ?></dd>
        <dt>Olay</dt><dd><?= e($event['event_id'].' · '.$event['type']) ?></dd>
        <dt>Rezervasyon</dt><dd><?= e($event['reservation_id']) ?></dd>
        <dt>Misafir</dt><dd><?= e($event['guest_name']) ?></dd>
        <dt>PMS oda kodu</dt><dd><?= e($event['room_id']) ?></dd>
        <?php if ($event['previous_room_id']): ?><dt>Önceki oda</dt><dd><?= e($event['previous_room_id']) ?></dd><?php endif; ?>
        <dt>Hedef oda</dt><dd><?= $targetRoom ? e($targetRoom['branch_name'].' / '.$targetRoom['room_number']) : 'Eşleme bulunamadı' ?></dd>
        <dt>Olay zamanı</dt><dd><?= e($event['occurred_at']) ?></dd>
        <dt>Planlanan aralık</dt><dd><?= e(($event['arrival_at'] ?? '—').' / '.($event['departure_at'] ?? '—')) ?></dd>
    </dl>
    <?php if (!empty($record['stay_id'])): ?>
        <p><?= e($record['approved_at']) ?> tarihinde konaklama #<?= (int)$record['stay_id'] ?> için uygulandı.</p>
    <?php elseif ($enabled && $record['status'] === 'staged' && $record['connection_status'] === 'testing' && $targetRoom): ?>
        <form method="post">
            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
            <input type="hidden" name="hotel_id" value="<?= $hotel ?>">
            <input type="hidden" name="connection_id" value="<?= $connection ?>">
            <input type="hidden" name="event_id" value="<?= $eventId ?>">
            <input type="hidden" name="reviewed_room" value="<?= (int)$targetRoom['id'] ?>">
            <button name="action" value="apply">Test konaklamasına uygula</button>
        </form>
    <?php elseif (!$enabled): ?>
        <p>Konaklamaya uygulama bu ortamda kapalı.</p>
    <?php endif; ?>
<?php endif; ?>
<?php layout_end(); ?>
