<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
require_once __DIR__ . '/pms/inbox.php';

htv_require_manager();
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');

$providers = htv_pms_providers();
$ingresses = ['api'=>'İmzalı API', 'webhook'=>'İmzalı webhook', 'manual'=>'Kontrollü JSON içe aktarma'];
$hotelScope = htv_hotel_scope('id');
$hotels = $pdo->query("SELECT id, name FROM hotel_properties WHERE status='active' AND $hotelScope ORDER BY name")->fetchAll();
$hotelId = filter_input($_SERVER['REQUEST_METHOD']==='POST' ? INPUT_POST : INPUT_GET, 'hotel_id', FILTER_VALIDATE_INT)
    ?: (int) ($hotels[0]['id'] ?? 0);
if ($hotelId && !in_array($hotelId, array_map('intval', array_column($hotels, 'id')), true)) htv_access_denied();
$connectionId = filter_input($_SERVER['REQUEST_METHOD']==='POST' ? INPUT_POST : INPUT_GET, 'connection_id', FILTER_VALIDATE_INT) ?: 0;
$connections = $rows = $totals = $preview = $activity = [];
$json = $error = $message = '';
$selected = null;
try {
    if ($hotelId && $connectionId) {
        $selected = htv_pms_connection($pdo, $connectionId, $hotelId);
        if (!$selected) htv_access_denied();
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        htv_check_csrf();
        if (!$hotelId) throw new InvalidArgumentException('Önce bir otel seçin.');
        $action = $_POST['action'] ?? '';
        if ($action === 'create') {
            $provider = $_POST['provider'] ?? '';
            $ingress = $_POST['ingress'] ?? '';
            if (!is_string($provider) || !isset($providers[$provider]) || !is_string($ingress) || !isset($ingresses[$ingress])) {
                throw new InvalidArgumentException('Sağlayıcı ve veri alma yöntemi seçin.');
            }
            $pdo->beginTransaction();
            $create = $pdo->prepare("INSERT INTO hotel_pms_connections (hotel_id, provider_name, connection_type, status)
                VALUES (?, ?, ?, 'testing')");
            $create->execute([$hotelId, $providers[$provider], $ingress]);
            $connectionId = (int) $pdo->lastInsertId();
            $profile = $pdo->prepare('INSERT INTO hotel_pms_adapter_profiles (connection_id, provider_code, ingress) VALUES (?, ?, ?)');
            $profile->execute([$connectionId, $provider, $ingress]);
            $pdo->commit();
            header('Location: ?hotel_id=' . $hotelId . '&connection_id=' . $connectionId, true, 303);
            exit;
        }
        if (!$selected) throw new InvalidArgumentException('Önce bir bağlantı seçin.');

        if (in_array($action, ['disable','enable'], true)) {
            $update = $pdo->prepare('UPDATE hotel_pms_connections SET status=? WHERE id=? AND hotel_id=?');
            $update->execute([$action === 'disable' ? 'disabled' : 'testing', $connectionId, $hotelId]);
            header('Location: ?hotel_id=' . $hotelId . '&connection_id=' . $connectionId, true, 303);
            exit;
        }
        if ($action === 'retry') {
            $eventId = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT) ?: 0;
            if (!htv_pms_requeue($pdo, $connectionId, $hotelId, $eventId)) throw new DomainException('Kayıt yeniden denenemiyor.');
            $message = 'Kayıt tekrar kuyruğa alındı.';
        } elseif (in_array($action, ['preview','import'], true) && htv_pms_can_receive($selected, 'manual')) {
            $json = $_POST['events'] ?? '';
            if (!is_string($json) || strlen($json) > 65536) {
                $json = '';
                throw new InvalidArgumentException('JSON boyutu sınırı 64 KiB.');
            }
            $data = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($data) || !array_is_list($data) || count($data) < 1 || count($data) > 50) {
                throw new InvalidArgumentException('JSON dizisi 1–50 olay içermeli.');
            }
            $adapter = htv_pms_adapter($selected['provider_code']);
            foreach ($data as $event) {
                if (!is_array($event)) throw new InvalidArgumentException('Olay nesnesi gerekli.');
                $preview[] = htv_pms_event($adapter, $event);
            }
            $digest = hash('sha256', str_replace("\r\n", "\n", $json));
            if ($action === 'import') {
                $approval = $_SESSION['pms_import_preview'] ?? [];
                if (($approval['connection'] ?? null) !== $connectionId
                    || ($approval['digest'] ?? null) !== $digest || ($approval['expires'] ?? 0) < time()) {
                    throw new DomainException('Kaydetmeden önce bu veriyi yeniden önizleyin.');
                }
                $result = htv_pms_queue($pdo, $selected, $preview);
                unset($_SESSION['pms_import_preview']);
                $message = (int)$result['queued'] . ' yeni olay sıraya alındı, ' .
                    (int)$result['duplicates'] . ' tekrar atlandı.';
                $preview = [];
                $json = '';
            } else {
                $_SESSION['pms_import_preview'] = ['connection'=>$connectionId, 'digest'=>$digest, 'expires'=>time()+900];
            }
        } else {
            throw new InvalidArgumentException('İşlem bu bağlantıda kullanılamıyor.');
        }
    }
    if ($hotelId) {
        $query = $pdo->prepare('SELECT c.id, c.status, p.provider_code, p.ingress, p.last_received_at, p.last_staged_at
            FROM hotel_pms_connections c JOIN hotel_pms_adapter_profiles p ON p.connection_id=c.id
            WHERE c.hotel_id=? ORDER BY c.id DESC');
        $query->execute([$hotelId]);
        $connections = $query->fetchAll();
    }
    if ($selected) {
        $query = $pdo->prepare("SELECT i.id, i.event_type, i.external_event_id, i.status, i.attempts,
            i.last_error_code, JSON_UNQUOTE(JSON_EXTRACT(i.payload_json, '$.room_id')) AS external_room_id, i.available_at, i.created_at FROM hotel_pms_event_inbox i
            JOIN hotel_pms_connections c ON c.id=i.connection_id
            WHERE i.connection_id=? AND c.hotel_id=? ORDER BY i.id DESC LIMIT 80");
        $query->execute([$connectionId, $hotelId]);
        $rows = $query->fetchAll();
        $query = $pdo->prepare('SELECT i.status, COUNT(*) AS total FROM hotel_pms_event_inbox i
            JOIN hotel_pms_connections c ON c.id=i.connection_id
            WHERE i.connection_id=? AND c.hotel_id=? GROUP BY i.status');
        $query->execute([$connectionId, $hotelId]);
        $totals = $query->fetchAll();
        $query = $pdo->prepare("SELECT i.external_event_id, a.outcome, a.error_code, a.created_at
            FROM hotel_pms_event_attempts a JOIN hotel_pms_event_inbox i ON i.id=a.event_id
            JOIN hotel_pms_connections c ON c.id=i.connection_id
            WHERE i.connection_id=? AND c.hotel_id=? ORDER BY a.id DESC LIMIT 30");
        $query->execute([$connectionId, $hotelId]);
        $activity = $query->fetchAll();
    }
} catch (InvalidArgumentException | JsonException | DomainException $ex) {
    $error = $ex->getMessage();
    $preview = [];
} catch (Throwable $ex) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[Hotel TV PMS panel] error=' . get_class($ex));
    $error = 'PMS işlemi tamamlanamadı. Veritabanını ve SQL geçişini kontrol edin.';
}

$statuses = ['requeued'=>'Yeniden kuyruğa alındı','queued'=>'Kuyrukta','retry'=>'Yeniden denenecek','needs_mapping'=>'Oda eşlemesi gerekli',
    'staged'=>'İncelemeye hazır','failed'=>'Başarısız'];
layout_start('PMS entegrasyonları');
?>
<h1>PMS entegrasyonları</h1>
<p><a href="pms.php?hotel_id=<?= $hotelId ?>">Bağlantı merkezi</a>
<?php if (htv_is_superadmin()): ?> · <a href="pms_setup.php?hotel_id=<?= $hotelId ?>&amp;connection_id=<?= $connectionId ?>">Oda eşlemeleri</a><?php endif; ?></p>
<p>Standart veri akışı test modundadır. Sağlayıcıların kendi API bağlantıları doğrulama bekliyor.</p>
<?php if ($error): ?><p role="alert"><?= e($error) ?></p><?php endif; ?>
<?php if ($message): ?><p role="status"><?= e($message) ?></p><?php endif; ?>
<?php if ($hotels): ?>
<form method="get">
    <label for="pms-hotel">Otel</label>
    <select id="pms-hotel" name="hotel_id">
        <?php foreach ($hotels as $hotel): ?>
            <option value="<?= (int)$hotel['id'] ?>" <?= (int)$hotel['id']===$hotelId?'selected':'' ?>><?= e($hotel['name']) ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Göster</button>
</form>
<h2>Yeni bağlantı</h2>
<form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <input type="hidden" name="hotel_id" value="<?= $hotelId ?>">
    <label for="provider">Sağlayıcı</label>
    <select id="provider" name="provider"><?php foreach ($providers as $key=>$name): ?><option value="<?=e($key)?>"><?=e($name)?></option><?php endforeach; ?></select>
    <label for="ingress">Veri alma yöntemi</label>
    <select id="ingress" name="ingress"><?php foreach ($ingresses as $key=>$name): ?><option value="<?=e($key)?>"><?=e($name)?></option><?php endforeach; ?></select>
    <button name="action" value="create">Test bağlantısı oluştur</button>
</form>
<h2>Bağlantılar</h2>
<ul>
<?php foreach ($connections as $connection): ?>
    <li><a href="?hotel_id=<?= $hotelId ?>&amp;connection_id=<?= (int)$connection['id'] ?>">
        <?= e($providers[$connection['provider_code']] . ' · ' . $ingresses[$connection['ingress']]) ?></a>
        · <?= e(['disabled'=>'Kapalı','testing'=>'Test profili','active'=>'Etkin','error'=>'Hata','not_configured'=>'Yapılandırılmadı'][$connection['status']] ?? $connection['status']) ?>
        · Son alım <?= e($connection['last_received_at'] ?? '—') ?>
        · Son hazırlık <?= e($connection['last_staged_at'] ?? '—') ?></li>
<?php endforeach; ?>
</ul>
<?php if ($selected): ?>
<h2>Bağlantı #<?= $connectionId ?></h2>
<form method="post">
    <input type="hidden" name="csrf" value="<?=e(csrf())?>">
    <input type="hidden" name="hotel_id" value="<?=$hotelId?>">
    <input type="hidden" name="connection_id" value="<?=$connectionId?>">
    <?php if ($selected['status']==='disabled'): ?>
        <button name="action" value="enable">Test bağlantısını aç</button>
    <?php else: ?>
        <button name="action" value="disable">Bağlantıyı kapat</button>
    <?php endif; ?>
</form>
<?php if (htv_pms_can_receive($selected, 'manual')): ?>
<h3>JSON içe aktarma</h3>
<form method="post">
    <input type="hidden" name="csrf" value="<?=e(csrf())?>">
    <input type="hidden" name="hotel_id" value="<?=$hotelId?>">
    <input type="hidden" name="connection_id" value="<?=$connectionId?>">
    <label for="pms-events">Olay dizisi</label>
    <textarea id="pms-events" name="events" rows="7" cols="70" required><?=e($json)?></textarea>
    <button name="action" value="preview">Doğrula ve önizle</button>
    <?php if ($preview): ?>
        <p><?= count($preview) ?> olay doğrulandı. Onayladığında olaylar kuyruğa alınır.</p>
        <ul><?php foreach ($preview as $event): ?><li><?=e($event['type'].' · '.$event['reservation_id'].' · '.$event['occurred_at'])?></li><?php endforeach;?></ul>
        <button name="action" value="import">Hazırlık için kuyruğa al</button>
    <?php endif; ?>
</form>
<?php endif; ?>
<h3>Olay durumu</h3>
<ul><?php foreach ($totals as $total): ?><li><?=e($statuses[$total['status']])?> · <?= (int)$total['total'] ?></li><?php endforeach; ?></ul>
<table>
    <thead><tr><th>Olay</th><th>Harici oda</th><th>Alındı</th><th>Durum</th><th>Deneme</th><th>Son hata</th><th>İşlem</th></tr></thead>
    <tbody><?php foreach ($rows as $row): ?>
    <tr><td><?= e($row['external_event_id'].' · '.$row['event_type']) ?></td><td><?=e($row['external_room_id'] ?? '—')?></td><td><?=e($row['created_at'])?></td>
    <td><?=e($statuses[$row['status']])?><?= $row['status']==='retry'?' · '.e($row['available_at']):'' ?></td><td><?= (int)$row['attempts'] ?></td><td><?=e([
        'room_mapping_missing'=>'Bu bağlantıda harici oda kodu eşlenmemiş.',
        'room_mapping_wrong_hotel'=>'Eşleme başka bir otele ait.',
        'room_branch_inactive'=>'Eşlenen odanın şubesi pasif.',
        'room_inactive'=>'Eşlenen oda aktif değil.',
    ][$row['last_error_code'] ?? ''] ?? $row['last_error_code'] ?? '—')?></td><td>
        <?php if (in_array($row['status'], ['needs_mapping','failed'], true)): ?>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
                <input type="hidden" name="hotel_id" value="<?= $hotelId ?>">
                <input type="hidden" name="connection_id" value="<?= $connectionId ?>">
                <input type="hidden" name="event_id" value="<?= (int)$row['id'] ?>">
                <button name="action" value="retry">Yeniden dene</button>
            </form>
        <?php endif; ?>
        <?php if (htv_is_superadmin() && $row['status'] === 'staged'): ?>
            <a href="pms_test_approval.php?hotel_id=<?= $hotelId ?>&amp;connection_id=<?= $connectionId ?>&amp;event_id=<?= (int)$row['id'] ?>">İncele</a>
        <?php endif; ?>
    </td></tr>
    <?php endforeach; ?></tbody>
</table>
<h3>Son işlem denemeleri</h3>
<ul>
    <?php foreach ($activity as $attempt): ?>
        <li><?= e($attempt['created_at'].' · '.$attempt['external_event_id'].' · '.$statuses[$attempt['outcome']]) ?>
            <?php if ($attempt['error_code']): ?> · <?= e($attempt['error_code']) ?><?php endif; ?></li>
    <?php endforeach; ?>
    <?php if (!$activity): ?><li>Henüz işleme denemesi yok.</li><?php endif; ?>
</ul>
<?php endif; ?>
<?php endif; ?>
<?php layout_end(); ?>
