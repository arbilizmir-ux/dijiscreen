# PMS olay onayı · izole test paketi

Bu güncelleme evrensel PMS ve oda eşleme düzeltmesinin üzerine uygulanır. Önce ayrı test veritabanına 004_hotel_pms_test_approvals.sql geçişini uygulayın. Ardından hotel-tv içeriğini klasör yapısını koruyarak test sunucusuna yükleyin. Sadece izole test sunucusunun web PHP ortamında HTV_PMS_APPROVAL_TEST=1 tanımlanınca konaklamaya uygulama açılır. PHP CLI worker'ın ayarını değiştirmek gerekmez.

**Hotel TV → PMS → Sağlayıcı seçimi ve olay kuyruğu → İncele** yoluyla olay, harici oda kodu ve eşlenen yerel oda görülebilir. Bu aşamada yalnızca superadmin, bir test bağlantısının hazırlık tamamlanmış olayını **Test konaklamasına uygula** düğmesiyle işleyebilir. Onay veritabanında olay, kullanıcı, konaklama ve zamanla kayıt altına alınır. Tekrar onay aynı etkiyi yeniden uygulamaz.

- Bir rezervasyon önce oluşturma olayıyla başlar. Giriş, oda değişimi ve çıkış mevcut PMS test kaydını kullanır. Eski, aynı zamanlı, gelecekteki ve geçersiz durum geçişleri reddedilir.
- Hedef oda incelemeden sonra değişmişse yeniden inceleme gerekir. Çakışan konaklama ve başka otele ait oda eşlemesi reddedilir. Daha önceki manuel veya bu test akışı dışında oluşturulmuş konaklamalar otomatik sahiplenilmez.
- Planlanan aralık başlangıç ve bitiş gerektirir. Mevcut Hotel TV yerel tarih yazımı nedeniyle testte otel saat dilimi ile veritabanı oturum saati eşleşmelidir.
- Test senaryoları için sentetik rezervasyon kullanın. Bu özellik üretim ve otomatik PMS uygulaması için açılmamalıdır.

Yerel MariaDB ve PHP HTTP ile imzalı alım, kuyruk, yönetici onayı, rezervasyon oluşturma ve güncelleme, check-in, ad düzeltme, oda değişimi ve check-out doğrulandı. İki eşleştirilmiş oda ekranının karşılama uç noktasında adın doğru odaya geçtiği ve çıkışta temizlendiği görüldü. Çift onay, eski olay, oda çakışması, otel kapsamı ve varsayılan kapalı durum ayrıca doğrulandı. Gerçek PMS sağlayıcısıyla yerinde otomatik senkronizasyon veya fiziksel TV bu pakette denenmedi.
