<?php
declare(strict_types=1);
require_once __DIR__ . '/adapters.php';

final class HtvPmsMewsSnapshotAdapter implements HtvPmsAdapter
{
    public function normalize(array $input): array
    {
        $reservation = $input['Reservation'] ?? null;
        $customer = $input['Customer'] ?? null;
        $enterprise = $input['EnterpriseId'] ?? '';
        if (!is_array($reservation) || !is_array($customer) || !is_string($enterprise) || $enterprise === '') {
            throw new InvalidArgumentException('Mews rezervasyonu, müşteri kaydı ve tesis kimliği gerekli.');
        }
        $account = $reservation['AccountId'] ?? '';
        if (($reservation['AccountType'] ?? null) !== 'Customer' || !$account
            || $account !== ($customer['Id'] ?? null)
            || (isset($reservation['EnterpriseId']) && $reservation['EnterpriseId'] !== $enterprise)) {
            throw new InvalidArgumentException('Mews tesis veya misafir eşleşmesi geçersiz.');
        }
        $id = htv_pms_text($reservation, 'Id', 190);
        $version = htv_pms_text($reservation, 'UpdatedUtc', 40);
        $room = htv_pms_text($reservation, 'AssignedResourceId', 190);
        $name = trim(implode(' ', array_filter([
            $this->part($customer, 'FirstName'),
            $this->part($customer, 'LastName'),
            $this->part($customer, 'SecondLastName'),
        ], static fn ($value) => $value !== null)));
        $type = match ($reservation['State'] ?? '') {
            'Confirmed' => ($reservation['CreatedUtc'] ?? null) === $version
                ? 'reservation.created' : 'reservation.updated',
            'Started' => 'guest.checked_in',
            'Processed' => 'guest.checked_out',
            default => throw new InvalidArgumentException('Bu Mews rezervasyon durumu hazırlık akışında desteklenmiyor.'),
        };
        $occurredAt = match ($type) {
            'guest.checked_in' => $reservation['ActualStartUtc'] ?? $version,
            'guest.checked_out' => $reservation['ActualEndUtc'] ?? $version,
            default => $version,
        };
        return (new HtvPmsCanonicalAdapter())->normalize([
            'event_id' => 'mews:' . hash('sha256', json_encode([$enterprise, $id, $version, $type], JSON_THROW_ON_ERROR)),
            'type' => $type, 'reservation_id' => $id, 'occurred_at' => $this->timestamp($occurredAt),
            'room_id' => $room, 'guest_id' => $account, 'guest_name' => $name,
            'arrival_at' => $this->timestamp($reservation['ActualStartUtc'] ?? $reservation['ScheduledStartUtc'] ?? null),
            'departure_at' => $this->timestamp($reservation['ActualEndUtc'] ?? $reservation['ScheduledEndUtc'] ?? null),
        ]);
    }

    private function part(array $customer, string $field): ?string
    {
        return htv_pms_text($customer, $field, 190, false);
    }

    private function timestamp($value): ?string
    {
        if ($value === null) return null;
        if (!is_string($value)) throw new InvalidArgumentException('Mews tarih alanı geçersiz.');
        return preg_replace('/\.\d{1,9}(?=Z$)/', '', $value);
    }
}

function htv_pms_mews_snapshot(string $enterprise, array $reservations, array $customers): array
{
    if (!$enterprise || !array_is_list($reservations) || !array_is_list($customers)
        || count($reservations) > 50 || count($customers) > 50) {
        throw new InvalidArgumentException('Bir Mews tesisi ve en fazla 50 rezervasyon ile misafir gerekli.');
    }
    $byId = [];
    foreach ($customers as $customer) {
        if (is_array($customer) && is_string($customer['Id'] ?? null)) $byId[$customer['Id']] = $customer;
    }
    $events = [];
    $skipped = 0;
    $adapter = new HtvPmsMewsSnapshotAdapter();
    foreach ($reservations as $reservation) {
        if (!is_array($reservation)
            || !in_array($reservation['State'] ?? null, ['Confirmed','Started','Processed'], true)
            || ($reservation['AccountType'] ?? null) !== 'Customer' || empty($reservation['AssignedResourceId']) || !is_string($reservation['AccountId'] ?? null)
            || !isset($byId[$reservation['AccountId']])) {
            $skipped++;
            continue;
        }
        $events[] = htv_pms_event($adapter, [
            'EnterpriseId'=>$enterprise, 'Reservation'=>$reservation, 'Customer'=>$byId[$reservation['AccountId']],
        ]);
    }
    return ['events'=>$events, 'skipped'=>$skipped];
}
