"""Read bounded pages of Mews demo data and emit the DijiScreen snapshot input."""

import argparse
import json
import os
import sys
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, Request, build_opener

BASE_URL = "https://api.mews-demo.com/api/connector/v1/"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        return None


def reservation_pages(read, enterprise, pages):
    rows = []
    cursor = None
    seen = set()
    for _ in range(pages):
        limit = {"Count": 10}
        if cursor is not None:
            limit["Cursor"] = cursor
        response = read("reservations/getAll/2023-06-06", {
            "EnterpriseIds": [enterprise],
            "States": ["Confirmed", "Started", "Processed"],
            "Limitation": limit,
        })
        batch = response["Reservations"]
        if not isinstance(batch, list) or len(batch) > 10:
            raise ValueError("Invalid reservation page")
        rows.extend(batch)
        cursor = response.get("Cursor")
        if not batch or cursor is None:
            break
        if not isinstance(cursor, str) or not cursor or cursor in seen:
            raise ValueError("Invalid or repeated Mews cursor")
        seen.add(cursor)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pages", type=int, choices=range(1, 6), default=1)
    args = parser.parse_args()
    auth = {
        "ClientToken": os.environ["HTV_MEWS_DEMO_CLIENT_TOKEN"],
        "AccessToken": os.environ["HTV_MEWS_DEMO_ACCESS_TOKEN"],
        "Client": "DijiScreen Hotel TV demo",
    }
    opener = build_opener(NoRedirect())

    def read(operation, fields):
        request = Request(
            BASE_URL + operation,
            data=json.dumps({**auth, **fields}).encode(),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        with opener.open(request, timeout=15) as response:
            data = response.read(2 * 1024 * 1024 + 1)
        if len(data) > 2 * 1024 * 1024:
            raise ValueError("Mews response limit")
        return json.loads(data)

    enterprise = read("configuration/get", {})["Enterprise"]["Id"]
    expected = os.environ.get("HTV_MEWS_DEMO_ENTERPRISE_ID")
    if expected and expected != enterprise:
        raise ValueError("Mews demo property mismatch")
    fields = {
        "Id", "EnterpriseId", "AccountId", "AccountType", "AssignedResourceId", "State", "UpdatedUtc", "CreatedUtc",
        "ActualStartUtc", "ActualEndUtc", "ScheduledStartUtc", "ScheduledEndUtc",
    }
    rows = reservation_pages(read, enterprise, args.pages)
    reservations = [{key: value for key, value in entry.items() if key in fields} for entry in rows]
    customer_ids = sorted({
        reservation["AccountId"] for reservation in reservations
        if reservation.get("AccountType") == "Customer" and reservation.get("AccountId")
    })
    customers = []
    if customer_ids:
        customer_data = read("customers/getAll", {
            "CustomerIds": customer_ids, "Extent": {"Customers": True}, "Limitation": {"Count": len(customer_ids)},
        })
        customers = [
            {key: value for key, value in customer.items() if key in {"Id", "FirstName", "LastName", "SecondLastName"}}
            for customer in customer_data["Customers"] if customer.get("Id") in customer_ids
        ]
    print(json.dumps({"EnterpriseId": enterprise, "Reservations": reservations, "Customers": customers}))


if __name__ == "__main__":
    try:
        main()
    except HTTPError as error:
        suffix = " · Retry-After " + error.headers["Retry-After"] if "Retry-After" in error.headers else ""
        print(f"Mews demo HTTP {error.code}{suffix}", file=sys.stderr)
        sys.exit(1)
    except (OSError, KeyError, TypeError, ValueError):
        print("Mews demo yanıtı okunamadı. Demo ayarlarını ve erişimi kontrol edin.", file=sys.stderr)
        sys.exit(1)
