# Mews demo adaptörü

Geliştirme paketi, evrensel PMS ve 003 migration kurulu izole test ortamı içindir. Üretim bağlantısı ve otomatik konaklama yazımı içermez.

tools/mews_demo_pull.py Python standart kütüphanesini kullanır. Yalnızca resmi Mews demo sunucusunda tesis yapılandırmasını ve varsayılan olarak bir, --pages seçeneğiyle en fazla beş sayfa rezervasyonu okur. Müşteriler için sadece ilgili rezervasyonların kimliklerini sorgular ve çıktı alanlarını ad, soyad ve kimlikle sınırlar. Token'lar HTV_MEWS_DEMO_CLIENT_TOKEN ve HTV_MEWS_DEMO_ACCESS_TOKEN ortam değişkenlerinden alınır. HTTP 429 yanıtında araç durur ve servis varsa Retry-After bilgisini bildirir.

pms_mews_demo_snapshot.php, özet sayıları göstermek için bu JSON çıktısını standart girdiden alır. HTV_MEWS_DEMO_ENTERPRISE_ID değişkeni beklenen demo tesisini belirler. Kuyruğa yazmak için izole test ortamında HTV_MEWS_DEMO_ALLOW_QUEUE=1 ve --hotel=ID --connection=ID seçenekleri gerekir. Bu işlem yalnızca ilgili oteldeki Mews API test profiline izin verir. Ardından mevcut pms_event_worker.php kuyruğu işleyebilir. Harici oda kodu Mews AssignedResourceId değeridir.

Resmi ortak demo API'sinden 10 rezervasyon okundu. Dokuz iptal edilmiş kayıt atlandı. Bir çıkış kaydı gerçek demo cevabından çevrilip yerel MariaDB hazırlık tablosuna ulaştı. Aynı kayıt tekrar verildiğinde çift kayıt oluşmadı. Farklı otel için yazma reddedildi. Rezervasyon oluşturma, güncelleme ve giriş eşlemeleri sentetik örneklerle geçti. Sayfalama için kursörün sonraki isteğe geçirilmesi, boş/biten sayfada durma ve yinelenen kursörde işlemin kesilmesi örnek yanıtlarla doğrulandı. Gerçek iki sayfalı deneme ortak demo ortamının HTTP 429 sınırına takıldı. Önceden alınan demo verisi yeni izole veritabanında tekrar işlendi ve çift kayıt oluşmadı. Oda değişikliği, iptal yönetimi, webhook ve üretim Mews erişimi doğrulanmadı.

Resmi belgeler: https://docs.mews.com/connector-api/guidelines/environments
https://docs.mews.com/connector-api/operations/reservations
