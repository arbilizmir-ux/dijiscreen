<?php
declare(strict_types=1);

const HTVF_AIRLABS_ENDPOINT = 'https://airlabs.co/api/v9/schedules';

function htvf_airlabs_rows(array $document, string $airport, string $direction): array
{
    $response = $document['response'] ?? null;
    if (isset($document['error']) || !is_array($response) || !array_is_list($response)) {
        throw new RuntimeException('AirLabs uçuş listesi alınamadı.');
    }

    $arrival = $direction === 'arrivals';
    $local = $arrival ? 'arr' : 'dep';
    $other = $arrival ? 'dep' : 'arr';
    $rows = [];
    foreach (array_slice($response, 0, 2000) as $flight) {
        if (!is_array($flight) || ($flight[$local . '_iata'] ?? null) !== $airport) {
            continue;
        }

        $number = $flight['flight_iata'] ?? $flight['flight_icao'] ?? '';
        $scheduled = htvf_airlabs_time($flight[$local . '_time_utc'] ?? null);
        if (!is_string($number) || trim($number) === '' || $scheduled === null) {
            continue;
        }

        $rows[] = [
            'flight_number' => $number,
            'destination' => $flight[$other . '_iata'] ?? $flight[$other . '_icao'] ?? '',
            'scheduled_at' => $scheduled,
            'estimated_at' => htvf_airlabs_time($flight[$local . '_estimated_utc'] ?? null),
            'status' => $flight['status'] ?? '',
        ];
    }
    if ($response !== [] && $rows === []) {
        throw new RuntimeException('AirLabs yanıtında kullanılabilir uçuş bulunamadı.');
    }
    return $rows;
}

function htvf_airlabs_time($value): ?string
{
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/D', $value)) {
        return null;
    }
    $format = strlen($value) === 16 ? 'Y-m-d H:i' : 'Y-m-d H:i:s';
    $time = DateTimeImmutable::createFromFormat('!' . $format, $value, new DateTimeZone('UTC'));
    if (!$time || $time->format($format) !== $value) {
        return null;
    }
    return $time->format('Y-m-d\TH:i:s\Z');
}
