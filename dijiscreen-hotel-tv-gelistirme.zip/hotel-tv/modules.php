<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('id');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['htv_module_csrf'])) $_SESSION['htv_module_csrf'] = bin2hex(random_bytes(32));
function htv_length(string $s): int { return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s); }
function htv_module_url(string $url): bool {
 return filter_var($url,FILTER_VALIDATE_URL) !== false
    && strtolower((string)parse_url($url,PHP_URL_SCHEME)) === 'https'
    && parse_url($url,PHP_URL_USER) === null && parse_url($url,PHP_URL_PASS) === null;
}
function htv_cut(string $s, int $limit): string { return function_exists('mb_substr') ? mb_substr($s,0,$limit) : substr($s,0,$limit); }
// e() zaten app/bootstrap.php içerisinde tanımlıdır. Burada tekrar tanımlanmaz.
$types = ['restaurant'=>'Restoran / Menü','services'=>'Otel Hizmetleri','tv'=>'Canlı TV','radio'=>'Radyo','flights'=>'Uçuş Bilgileri'];
$hotelId = filter_input(INPUT_GET,'hotel_id',FILTER_VALIDATE_INT) ?: (int)($_POST['hotel_id'] ?? 0);
$type = (string)($_GET['type'] ?? $_POST['type'] ?? 'restaurant');
if (!isset($types[$type])) $type='restaurant';
try { $hotels = $pdo->query("SELECT id,name FROM hotel_properties WHERE status='active' AND $hotelScope ORDER BY name")->fetchAll(PDO::FETCH_ASSOC); } catch (Throwable $ex) { error_log('[HTV modules hotels] '.$ex->getMessage()); $hotels=[]; $startupError='Otel listesi okunamadı. Veritabanı tablolarını kontrol edin.'; }
if (!$hotelId && $hotels) $hotelId=(int)$hotels[0]['id'];
$allowedHotels=array_map(static fn($x)=>(int)$x['id'],$hotels);
if ($hotelId && !in_array($hotelId,$allowedHotels,true)) { http_response_code(403); exit('Geçersiz otel.'); }
$error=$startupError ?? ''; $message='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 try {
  if (!hash_equals((string)$_SESSION['htv_module_csrf'],(string)($_POST['csrf']??''))) throw new RuntimeException('Güvenlik doğrulaması başarısız.');
  if (!$hotelId) throw new RuntimeException('Otel seçilmedi.');
  $action=(string)($_POST['action']??'');
  if ($action==='save') {
   $title=trim((string)($_POST['title']??''));
   if ($title==='' || htv_length($title)>190) throw new RuntimeException('Başlık 1–190 karakter olmalı.');
   $url=trim((string)($_POST['resource_url']??''));
   if ($url!=='' && !htv_module_url($url)) throw new RuntimeException('Bağlantı HTTPS adresi olmalı.');
   $price=trim((string)($_POST['price']??''));
   if ($price!=='' && !preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D',$price)) throw new RuntimeException('Fiyat geçersiz.');
   $currency=strtoupper(trim((string)($_POST['currency']??'TRY')));
   if (!preg_match('/^[A-Z]{3}$/D',$currency)) throw new RuntimeException('Para birimi üç harfli olmalı.');
   $stmt=$pdo->prepare('INSERT INTO hotel_tv_module_items (hotel_id,module_type,title,subtitle,description,resource_url,price,currency,sort_order) VALUES (?,?,?,?,?,?,?,?,?)');
   $stmt->execute([$hotelId,$type,$title,htv_cut(trim((string)($_POST['subtitle']??'')),255),htv_cut(trim((string)($_POST['description']??'')),5000),$url?:null,$price===''?null:$price,$currency,(int)($_POST['sort_order']??0)]);
   $message='Kayıt eklendi.';
  } elseif ($action==='toggle') {
   $id=(int)($_POST['id']??0);
   $stmt=$pdo->prepare("UPDATE hotel_tv_module_items SET status=IF(status='active','inactive','active') WHERE id=? AND hotel_id=? AND module_type=?");
   $stmt->execute([$id,$hotelId,$type]); $message='Durum güncellendi.';
  } else throw new RuntimeException('Geçersiz işlem.');
 } catch (Throwable $ex) { error_log('[HTV modules] '.$ex->getMessage()); $error=$ex instanceof PDOException ? 'Veritabanı işlemi başarısız. SQL kurulumunu kontrol edin.' : $ex->getMessage(); }
}
$items=[];
try { if ($hotelId) { $stmt=$pdo->prepare('SELECT id,title,subtitle,description,resource_url,price,currency,status,sort_order FROM hotel_tv_module_items WHERE hotel_id=? AND module_type=? ORDER BY sort_order,id DESC'); $stmt->execute([$hotelId,$type]); $items=$stmt->fetchAll(PDO::FETCH_ASSOC); } }
catch (Throwable $ex) { error_log('[HTV modules] '.$ex->getMessage()); $error='Modül tablosu bulunamadı veya okunamadı. Önce SQL dosyasını çalıştırın.'; }
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DijiScreen Hotel TV Modülleri</title><style>
:root{font-family:system-ui,Arial;color:#f4f6fc;background:#0b1525}body{margin:0}main{max-width:1080px;margin:auto;padding:28px 18px}a{color:#c9b176}header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap}h1{font-size:26px}h2{font-size:20px}.panel{background:#142238;border:1px solid #293c57;border-radius:16px;padding:20px;margin:16px 0}.nav{display:flex;gap:8px;flex-wrap:wrap}.nav a{border:1px solid #41536c;border-radius:9px;padding:9px 12px;text-decoration:none}.nav a.on{background:#c9b176;color:#101927}label{display:block;font-size:13px;margin:10px 0 5px;color:#cbd5e1}input,textarea,select{box-sizing:border-box;width:100%;padding:11px;border:1px solid #45556e;border-radius:8px;background:#0c1728;color:white}textarea{min-height:80px}button{padding:11px 16px;border:0;border-radius:9px;background:#c9b176;color:#101927;font-weight:bold;cursor:pointer}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.muted{color:#aebbd0}.item{border-bottom:1px solid #34445a;padding:13px 0}.alert{padding:12px;border-radius:8px;background:#4b2430}.ok{background:#1d493d}@media(max-width:650px){.grid{grid-template-columns:1fr}}
</style></head><body><main><header><div><h1>DijiScreen · Hotel TV Modülleri</h1><p class="muted">İçerik yönetimi · Android uygulaması değiştirilmez</p></div><div><a href="index.php">← Hotel TV</a> · <a href="tv_preview.php?hotel_id=<?= $hotelId ?>">TV önizlemesi</a></div></header>
<form method="get" class="panel"><label>Otel</label><select name="hotel_id" onchange="this.form.submit()"><option value="0">Otel seç</option><?php foreach($hotels as $h): ?><option value="<?= (int)$h['id'] ?>" <?= $hotelId===(int)$h['id']?'selected':'' ?>><?= e($h['name']) ?></option><?php endforeach; ?></select><input type="hidden" name="type" value="<?= e($type) ?>"></form>
<nav class="nav"><?php foreach($types as $key=>$name): ?><a class="<?= $key===$type?'on':'' ?>" href="?hotel_id=<?= $hotelId ?>&amp;type=<?= e($key) ?>"><?= e($name) ?></a><?php endforeach; ?></nav>
<?php if($error): ?><p class="alert"><?= e($error) ?></p><?php endif; ?><?php if($message): ?><p class="alert ok"><?= e($message) ?></p><?php endif; ?>
<section class="panel"><h2><?= e($types[$type]) ?> · Yeni kayıt</h2><form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['htv_module_csrf']) ?>"><input type="hidden" name="hotel_id" value="<?= $hotelId ?>"><input type="hidden" name="type" value="<?= e($type) ?>"><input type="hidden" name="action" value="save"><div class="grid"><div><label>Başlık *</label><input name="title" maxlength="190" required></div><div><label>Alt başlık / kategori</label><input name="subtitle" maxlength="255"></div></div><label>Açıklama</label><textarea name="description" maxlength="5000"></textarea><div class="grid"><div><label>HTTPS kaynak bağlantısı (varsa)</label><input name="resource_url" placeholder="https://..."></div><div><label>Fiyat (yalnızca menü/hizmet için)</label><input name="price" type="number" min="0" step="0.01"></div></div><label>Para birimi</label><input name="currency" value="TRY" maxlength="3" pattern="[A-Za-z]{3}"><label>Sıra</label><input name="sort_order" type="number" value="0"><p><button type="submit" <?= !$hotelId?'disabled':'' ?>>Kaydet</button></p></form></section>
<section class="panel"><h2>Kayıtlar (<?= count($items) ?>)</h2><?php if(!$items): ?><p class="muted">Henüz kayıt yok.</p><?php endif; ?><?php foreach($items as $it): ?><div class="item"><strong><?= e($it['title']) ?></strong> · <?= e($it['status']) ?><?php if($it['subtitle']): ?><p><?= e($it['subtitle']) ?></p><?php endif; ?><?php if($it['description']): ?><p class="muted"><?= nl2br(e($it['description'])) ?></p><?php endif; ?><?php if($it['price']!==null): ?><p><?= e($it['price']) ?> <?= e($it['currency']) ?></p><?php endif; ?><?php if(htv_module_url((string)$it['resource_url'])): ?><p><a href="<?= e($it['resource_url']) ?>" target="_blank" rel="noopener noreferrer">Kaynağı aç</a></p><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= e($_SESSION['htv_module_csrf']) ?>"><input type="hidden" name="hotel_id" value="<?= $hotelId ?>"><input type="hidden" name="type" value="<?= e($type) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$it['id'] ?>"><button type="submit"><?= $it['status']==='active'?'Pasife al':'Aktifleştir' ?></button></form></div><?php endforeach; ?></section>
<p class="muted">Otomatik uçuşlar uçuş ayarlarından yönetilir. Bu sayfadaki uçuş kayıtları önizlemedeki manuel duyurulardır.</p></main></body></html>
