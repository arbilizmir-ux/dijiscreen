<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$propertyScope = htv_hotel_scope('id');
$branchScope = htv_hotel_scope('b.hotel_id');
$recordScope = htv_hotel_scope('hotel_id');
$listScope = htv_hotel_scope('g.hotel_id');

if (!function_exists('hotel_guest_e')) {
    function hotel_guest_e($value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

$errors = [];
$success = '';
$editGuest = null;

$languages = [
    'tr' => 'Türkçe',
    'en' => 'English',
    'de' => 'Deutsch',
    'fr' => 'Français',
    'ru' => 'Русский',
    'ar' => 'العربية'
];

$stayStatuses = [
    'reserved' => 'Rezervasyon',
    'checked_in' => 'Giriş Yapıldı'
];

$selectedHotel = (int)($_GET['hotel_id'] ?? $_POST['hotel_id'] ?? 0);
$editId = (int)($_GET['edit'] ?? 0);

try {
    $hotels = $pdo->query("
        SELECT id, name
        FROM hotel_properties
        WHERE status = 'active' AND $propertyScope
        ORDER BY name
    ")->fetchAll(PDO::FETCH_ASSOC);

    $branches = $pdo->query("
        SELECT b.id, b.hotel_id, b.name
        FROM hotel_branches b
        INNER JOIN hotel_properties p ON p.id = b.hotel_id
        WHERE b.status = 'active' AND $branchScope
          AND p.status = 'active'
        ORDER BY b.name
    ")->fetchAll(PDO::FETCH_ASSOC);

    $rooms = $pdo->query("
        SELECT
            r.id,
            r.branch_id,
            r.room_number,
            r.room_name,
            r.status,
            b.hotel_id
        FROM hotel_rooms r
        INNER JOIN hotel_branches b ON b.id = r.branch_id
        WHERE b.status = 'active' AND $branchScope
        ORDER BY r.room_number
    ")->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {
    $hotels = [];
    $branches = [];
    $rooms = [];
    $errors[] = 'Otel, şube veya oda bilgileri alınamadı.';
}

$hotelIds = array_map('intval', array_column($hotels, 'id'));

if ($selectedHotel && !in_array($selectedHotel, $hotelIds, true)) {
    $selectedHotel = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $action = $_POST['action'] ?? '';

    $guestId = (int)($_POST['guest_id'] ?? 0);
    $hotelId = (int)($_POST['hotel_id'] ?? 0);

    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $language = $_POST['preferred_language'] ?? 'tr';
    $notes = trim($_POST['notes'] ?? '');

    $createStay = isset($_POST['create_stay']);
    $branchId = (int)($_POST['branch_id'] ?? 0);
    $roomId = (int)($_POST['room_id'] ?? 0);

    $reservationRef = trim($_POST['reservation_ref'] ?? '');
    $checkIn = trim($_POST['check_in_at'] ?? '');
    $checkOut = trim($_POST['check_out_at'] ?? '');
    $welcomeMessage = trim($_POST['welcome_message'] ?? '');
    $stayStatus = $_POST['stay_status'] ?? 'checked_in';

    htv_require_hotel($pdo, $hotelId);
    try {
        if ($action === 'save') {
            if (!in_array($hotelId, $hotelIds, true)) {
                throw new RuntimeException('Lütfen geçerli bir otel seçin.');
            }

            if ($firstName === '') {
                throw new RuntimeException('Misafir adı zorunludur.');
            }

            if (mb_strlen($firstName) > 100 || mb_strlen($lastName) > 100) {
                throw new RuntimeException('Ad ve soyad en fazla 100 karakter olabilir.');
            }

            if (!isset($languages[$language])) {
                throw new RuntimeException('Geçersiz dil seçimi.');
            }

            if (mb_strlen($reservationRef) > 100) {
                throw new RuntimeException('Rezervasyon numarası en fazla 100 karakter olabilir.');
            }

            if (mb_strlen($welcomeMessage) > 500) {
                throw new RuntimeException('Karşılama mesajı en fazla 500 karakter olabilir.');
            }

            if ($createStay) {
                if ($branchId < 1 || $roomId < 1) {
                    throw new RuntimeException('Konaklama için şube ve oda seçmelisiniz.');
                }

                if (!isset($stayStatuses[$stayStatus])) {
                    throw new RuntimeException('Geçersiz konaklama durumu.');
                }

                $branchCheck = $pdo->prepare("
                    SELECT id
                    FROM hotel_branches
                    WHERE id = ?
                      AND hotel_id = ?
                      AND status = 'active'
                    LIMIT 1
                ");
                $branchCheck->execute([$branchId, $hotelId]);

                if (!$branchCheck->fetchColumn()) {
                    throw new RuntimeException('Seçilen şube bu otele ait değil.');
                }

                $roomCheck = $pdo->prepare("
                    SELECT id
                    FROM hotel_rooms
                    WHERE id = ?
                      AND branch_id = ?
                      AND status = 'active'
                    LIMIT 1
                ");
                $roomCheck->execute([$roomId, $branchId]);

                if (!$roomCheck->fetchColumn()) {
                    throw new RuntimeException('Seçilen oda bu şubede aktif değil.');
                }

                if ($checkIn === '') {
                    throw new RuntimeException('Giriş tarihi zorunludur.');
                }

                $checkInDate = DateTime::createFromFormat('Y-m-d\TH:i', $checkIn);
                $checkOutDate = null;

                if (!$checkInDate || $checkInDate->format('Y-m-d\TH:i') !== $checkIn) {
                    throw new RuntimeException('Geçerli bir giriş tarihi girin.');
                }

                if ($checkOut !== '') {
                    $checkOutDate = DateTime::createFromFormat('Y-m-d\TH:i', $checkOut);

                    if (!$checkOutDate || $checkOutDate->format('Y-m-d\TH:i') !== $checkOut) {
                        throw new RuntimeException('Geçerli bir çıkış tarihi girin.');
                    }

                    if ($checkOutDate <= $checkInDate) {
                        throw new RuntimeException('Çıkış tarihi giriş tarihinden sonra olmalıdır.');
                    }
                }

                $checkInSql = $checkInDate->format('Y-m-d H:i:s');
                $checkOutSql = $checkOutDate
                    ? $checkOutDate->format('Y-m-d H:i:s')
                    : null;

                // Aynı odada tarihleri çakışan aktif rezervasyon veya konaklama olmasın.
                if ($stayStatus === 'reserved' || $stayStatus === 'checked_in') {
                    $conflict = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM hotel_stays
                        WHERE room_id = ?
                          AND status IN ('reserved', 'checked_in')
                          AND check_in_at < COALESCE(?, '9999-12-31 23:59:59')
                          AND COALESCE(check_out_at, '9999-12-31 23:59:59') > ?
                    ");

                    $conflict->execute([
                        $roomId,
                        $checkOutSql,
                        $checkInSql
                    ]);

                    if ((int)$conflict->fetchColumn() > 0) {
                        throw new RuntimeException(
                            'Bu odada seçtiğiniz tarihlerle çakışan başka bir rezervasyon veya konaklama bulunuyor.'
                        );
                    }
                }
            }

            $pdo->beginTransaction();

            try {
                if ($guestId > 0) {
                    $check = $pdo->prepare("
                        SELECT id
                        FROM hotel_guests
                        WHERE id = ? AND hotel_id = ? AND $recordScope
                        LIMIT 1
                    ");
                    $check->execute([$guestId, $hotelId]);

                    if (!$check->fetchColumn()) {
                        throw new RuntimeException('Misafir kaydı bulunamadı.');
                    }

                    $stmt = $pdo->prepare("
                        UPDATE hotel_guests
                        SET first_name = ?,
                            last_name = ?,
                            preferred_language = ?,
                            notes = ?
                        WHERE id = ? AND hotel_id = ? AND $recordScope
                    ");

                    $stmt->execute([
                        $firstName,
                        $lastName !== '' ? $lastName : null,
                        $language,
                        $notes !== '' ? $notes : null,
                        $guestId,
                        $hotelId
                    ]);

                    $savedGuestId = $guestId;
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO hotel_guests
                            (hotel_id, first_name, last_name, preferred_language, notes)
                        VALUES (?, ?, ?, ?, ?)
                    ");

                    $stmt->execute([
                        $hotelId,
                        $firstName,
                        $lastName !== '' ? $lastName : null,
                        $language,
                        $notes !== '' ? $notes : null
                    ]);

                    $savedGuestId = (int)$pdo->lastInsertId();
                }

                if ($createStay) {
                    $stmt = $pdo->prepare("
                        INSERT INTO hotel_stays (
                            hotel_id,
                            branch_id,
                            room_id,
                            guest_id,
                            reservation_ref,
                            check_in_at,
                            check_out_at,
                            welcome_message,
                            status,
                            source
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual')
                    ");

                    $stmt->execute([
                        $hotelId,
                        $branchId,
                        $roomId,
                        $savedGuestId,
                        $reservationRef !== '' ? $reservationRef : null,
                        $checkInSql,
                        $checkOutSql,
                        $welcomeMessage !== '' ? $welcomeMessage : null,
                        $stayStatus
                    ]);
                }

                $pdo->commit();

                $selectedHotel = $hotelId;
                $editId = 0;

                $success = $createStay
                    ? 'Misafir ve konaklama kaydı başarıyla oluşturuldu.'
                    : 'Misafir bilgileri başarıyla kaydedildi.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }

        } elseif ($action === 'delete') {
            $check = $pdo->prepare("
                SELECT id
                FROM hotel_guests
                WHERE id = ? AND hotel_id = ? AND $recordScope
                LIMIT 1
            ");
            $check->execute([$guestId, $hotelId]);

            if (!$check->fetchColumn()) {
                throw new RuntimeException('Silinecek misafir bulunamadı.');
            }

            $stayCheck = $pdo->prepare("
                SELECT COUNT(*)
                FROM hotel_stays
                WHERE guest_id = ?
            ");
            $stayCheck->execute([$guestId]);

            if ((int)$stayCheck->fetchColumn() > 0) {
                throw new RuntimeException(
                    'Bu misafire bağlı konaklama kayıtları var. Geçmiş kayıtları korumak için misafir silinmedi.'
                );
            }

            $stmt = $pdo->prepare("
                DELETE FROM hotel_guests
                WHERE id = ? AND hotel_id = ? AND $recordScope
            ");
            $stmt->execute([$guestId, $hotelId]);

            $selectedHotel = $hotelId;
            $success = 'Misafir kaydı silindi.';

        } else {
            throw new RuntimeException('Geçersiz işlem.');
        }

    } catch (PDOException $e) {
        $errors[] = 'Veritabanı işlemi sırasında hata oluştu. Lütfen bilgileri kontrol edin.';
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

// Düzenlenecek misafir
if ($editId > 0) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM hotel_guests
        WHERE id = ? AND $recordScope
        LIMIT 1
    ");
    $stmt->execute([$editId]);
    $editGuest = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($editGuest) {
        $selectedHotel = (int)$editGuest['hotel_id'];
    } else {
        $errors[] = 'Düzenlenecek misafir bulunamadı.';
        $editId = 0;
    }
}

// Misafir listesi ve konaklama sayısı
$params = [];

$sql = "
    SELECT
        g.*,
        p.name AS hotel_name,
        (
            SELECT COUNT(*)
            FROM hotel_stays s
            WHERE s.guest_id = g.id AND s.hotel_id = g.hotel_id
        ) AS stay_count,
        (
            SELECT s.status
            FROM hotel_stays s
            WHERE s.guest_id = g.id AND s.hotel_id = g.hotel_id
            ORDER BY s.created_at DESC
            LIMIT 1
        ) AS last_stay_status
    FROM hotel_guests g
    INNER JOIN hotel_properties p ON p.id = g.hotel_id
    WHERE $listScope
";

if ($selectedHotel > 0) {
    $sql .= " AND g.hotel_id = ?";
    $params[] = $selectedHotel;
}

$sql .= " ORDER BY g.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$guests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$defaultCheckIn = date('Y-m-d\TH:i');
?>
<?php layout_start('Hotel TV - Misafir Yönetimi'); ?>
<style>
*{box-sizing:border-box}
.container{max-width:1200px;margin:auto}
h1{margin:0 0 8px;font-size:26px}
h2{font-size:19px;margin:0 0 18px}
.subtitle{color:#697586;margin-bottom:24px}
.panel{background:#fff;border:1px solid #e4e8ef;border-radius:12px;padding:22px;margin-bottom:22px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.field label{display:block;font-size:13px;font-weight:bold;margin-bottom:7px}
input,select,textarea{width:100%;padding:11px;border:1px solid #d5dbe5;border-radius:7px;background:#fff;font-size:14px}
textarea{min-height:90px;resize:vertical}
button,.btn{display:inline-block;border:0;border-radius:7px;padding:11px 16px;background:#2457d6;color:#fff;font-weight:bold;text-decoration:none;cursor:pointer;font-size:14px}
.btn-secondary{background:#687386}
.btn-danger{background:#b83232}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}
.notice{padding:12px 15px;border-radius:8px;margin-bottom:16px;background:#e8f6ed;color:#176534}
.error{padding:12px 15px;border-radius:8px;margin-bottom:16px;background:#fdecec;color:#9b2525}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:800px}
th,td{text-align:left;padding:12px;border-bottom:1px solid #edf0f4;font-size:13px;vertical-align:middle}
th{background:#f8f9fb;color:#596579}
.small{color:#778195;font-size:12px}
.stay-box{margin-top:20px;padding:18px;border:1px solid #dce3ef;border-radius:10px;background:#f9fbff}
.stay-box h3{margin:0 0 15px;font-size:16px}
.checkline{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.checkline input{width:auto}
.hidden{display:none}
.grid{grid-template-columns:1fr}.panel{padding:16px}}
</style>
<div class="container">

<h1>Misafir Yönetimi</h1>
<div class="subtitle">DijiScreen Hotel TV · Misafir ve konaklama kayıtları</div>

<?php if ($success): ?>
<div class="notice"><?= hotel_guest_e($success) ?></div>
<?php endif; ?>

<?php foreach ($errors as $error): ?>
<div class="error"><?= hotel_guest_e($error) ?></div>
<?php endforeach; ?>

<div class="panel">
<h2><?= $editGuest ? 'Misafir Bilgilerini Düzenle' : 'Yeni Misafir Ekle' ?></h2>

<?php if (!$hotels): ?>
<div class="error">Önce aktif bir otel kaydı oluşturmalısınız.</div>
<?php else: ?>

<form method="post" id="guestForm">
<input type="hidden" name="csrf" value="<?= hotel_guest_e(csrf()) ?>">
<input type="hidden" name="action" value="save">
<input type="hidden" name="guest_id" value="<?= (int)($editGuest['id'] ?? 0) ?>">

<div class="grid">

<div class="field">
<label>Otel</label>
<select name="hotel_id" id="hotel_id" required>
<option value="">Otel seçin</option>
<?php foreach ($hotels as $hotel): ?>
<option value="<?= (int)$hotel['id'] ?>"
<?= $selectedHotel === (int)$hotel['id'] ? 'selected' : '' ?>>
<?= hotel_guest_e($hotel['name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="field">
<label>Ad</label>
<input type="text" name="first_name" maxlength="100" required
placeholder="Misafir adı"
value="<?= hotel_guest_e($editGuest['first_name'] ?? '') ?>">
</div>

<div class="field">
<label>Soyad</label>
<input type="text" name="last_name" maxlength="100"
placeholder="Misafir soyadı"
value="<?= hotel_guest_e($editGuest['last_name'] ?? '') ?>">
</div>

<div class="field">
<label>Tercih Ettiği Dil</label>
<select name="preferred_language">
<?php foreach ($languages as $key => $label): ?>
<option value="<?= hotel_guest_e($key) ?>"
<?= ($editGuest['preferred_language'] ?? 'tr') === $key ? 'selected' : '' ?>>
<?= hotel_guest_e($label) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="field" style="grid-column:1/-1">
<label>Misafir Notları</label>
<textarea name="notes" placeholder="Misafir hakkında notlar..."><?= hotel_guest_e($editGuest['notes'] ?? '') ?></textarea>
</div>

</div>

<div class="stay-box">
<h3>Konaklama Bilgileri</h3>

<label class="checkline">
<input type="checkbox" name="create_stay" id="create_stay" value="1">
<strong>Bu misafir için konaklama kaydı da oluştur</strong>
</label>

<div id="stayFields" class="hidden">
<div class="grid">

<div class="field">
<label>Şube</label>
<select name="branch_id" id="branch_id">
<option value="">Şube seçin</option>
<?php foreach ($branches as $branch): ?>
<option value="<?= (int)$branch['id'] ?>"
data-hotel="<?= (int)$branch['hotel_id'] ?>">
<?= hotel_guest_e($branch['name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="field">
<label>Oda</label>
<select name="room_id" id="room_id">
<option value="">Önce şube seçin</option>
<?php foreach ($rooms as $room): ?>
<option value="<?= (int)$room['id'] ?>"
data-branch="<?= (int)$room['branch_id'] ?>"
data-hotel="<?= (int)$room['hotel_id'] ?>">
<?= hotel_guest_e(
    $room['room_number'] .
    ($room['room_name'] ? ' - ' . $room['room_name'] : '')
) ?></option>
<?php endforeach; ?>
</select>
</div>

<div class="field">
<label>Giriş Tarihi</label>
<input type="datetime-local" name="check_in_at"
value="<?= hotel_guest_e($defaultCheckIn) ?>">
</div>

<div class="field">
<label>Çıkış Tarihi</label>
<input type="datetime-local" name="check_out_at">
</div>

<div class="field">
<label>Rezervasyon Numarası</label>
<input type="text" name="reservation_ref" maxlength="100"
placeholder="İsteğe bağlı">
</div>

<div class="field">
<label>Konaklama Durumu</label>
<select name="stay_status">
<option value="checked_in">Giriş Yapıldı</option>
<option value="reserved">Rezervasyon</option>
</select>
</div>

<div class="field" style="grid-column:1/-1">
<label>TV Karşılama Mesajı</label>
<textarea name="welcome_message" maxlength="500"
placeholder="Sayın misafirimiz, otelimize hoş geldiniz."></textarea>
</div>

</div>
</div>
</div>

<div class="actions">
<button type="submit"><?= $editGuest ? 'Misafir Bilgilerini Kaydet' : 'Misafir Kaydet' ?></button>

<?php if ($editGuest): ?>
<a class="btn btn-secondary" href="guests.php?hotel_id=<?= $selectedHotel ?>">Vazgeç</a>
<?php endif; ?>
</div>
</form>

<?php endif; ?>
</div>

<div class="panel">
<h2>Kayıtlı Misafirler</h2>

<form method="get" style="max-width:420px;margin-bottom:18px">
<div class="field">
<label>Otele Göre Filtrele</label>
<select name="hotel_id" onchange="this.form.submit()">
<option value="0">Tüm oteller</option>
<?php foreach ($hotels as $hotel): ?>
<option value="<?= (int)$hotel['id'] ?>"
<?= $selectedHotel === (int)$hotel['id'] ? 'selected' : '' ?>>
<?= hotel_guest_e($hotel['name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>
</form>

<div class="table-wrap">
<table>
<thead>
<tr>
<th>Misafir</th>
<th>Otel</th>
<th>Dil</th>
<th>Konaklama</th>
<th>Kayıt Tarihi</th>
<th>İşlem</th>
</tr>
</thead>
<tbody>

<?php if (!$guests): ?>
<tr><td colspan="6">Henüz misafir kaydı bulunmuyor.</td></tr>
<?php endif; ?>

<?php foreach ($guests as $guest): ?>
<tr>
<td>
<strong><?= hotel_guest_e(
    $guest['first_name'] . ' ' . ($guest['last_name'] ?? '')
) ?></strong>
<?php if (!empty($guest['notes'])): ?>
<br><span class="small"><?= hotel_guest_e($guest['notes']) ?></span>
<?php endif; ?>
</td>

<td><?= hotel_guest_e($guest['hotel_name']) ?></td>

<td><?= hotel_guest_e(
    $languages[$guest['preferred_language']] ?? $guest['preferred_language']
) ?></td>

<td><?= (int)$guest['stay_count'] ?> kayıt</td>

<td><?= hotel_guest_e(date('d.m.Y H:i', strtotime($guest['created_at']))) ?></td>

<td>
<div class="actions" style="margin:0">
<a class="btn btn-secondary"
href="guests.php?edit=<?= (int)$guest['id'] ?>">Düzenle</a>

<?php if ((int)$guest['stay_count'] === 0): ?>
<form method="post" onsubmit="return confirm('Bu misafir silinsin mi?')">
<input type="hidden" name="csrf" value="<?= hotel_guest_e(csrf()) ?>">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="guest_id" value="<?= (int)$guest['id'] ?>">
<input type="hidden" name="hotel_id" value="<?= (int)$guest['hotel_id'] ?>">
<button type="submit" class="btn btn-danger">Sil</button>
</form>
<?php endif; ?>
</div>
</td>
</tr>
<?php endforeach; ?>

</tbody>
</table>
</div>
</div>

</div>

<script>
const hotelSelect = document.getElementById('hotel_id');
const branchSelect = document.getElementById('branch_id');
const roomSelect = document.getElementById('room_id');
const stayCheckbox = document.getElementById('create_stay');
const stayFields = document.getElementById('stayFields');

function filterBranches() {
    if (!hotelSelect || !branchSelect) return;

    const hotelId = hotelSelect.value;

    Array.from(branchSelect.options).forEach(option => {
        if (!option.value) {
            option.hidden = false;
            return;
        }

        option.hidden = option.dataset.hotel !== hotelId;
    });

    if (
        branchSelect.selectedOptions.length &&
        branchSelect.selectedOptions[0].hidden
    ) {
        branchSelect.value = '';
    }

    filterRooms();
}

function filterRooms() {
    if (!branchSelect || !roomSelect) return;

    const branchId = branchSelect.value;

    Array.from(roomSelect.options).forEach(option => {
        if (!option.value) {
            option.hidden = false;
            return;
        }

        option.hidden = option.dataset.branch !== branchId;
    });

    if (
        roomSelect.selectedOptions.length &&
        roomSelect.selectedOptions[0].hidden
    ) {
        roomSelect.value = '';
    }
}

function toggleStayFields() {
    if (!stayCheckbox || !stayFields) return;

    stayFields.classList.toggle('hidden', !stayCheckbox.checked);

    if (stayCheckbox.checked) {
        filterBranches();
    }
}

if (hotelSelect) {
    hotelSelect.addEventListener('change', filterBranches);
}

if (branchSelect) {
    branchSelect.addEventListener('change', filterRooms);
}

if (stayCheckbox) {
    stayCheckbox.addEventListener('change', toggleStayFields);
}

toggleStayFields();
</script>
<?php layout_end(); ?>
