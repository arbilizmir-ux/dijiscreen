<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('b.hotel_id');
$floorScope = htv_branch_scope('branch_id');

if (!isset($pdo) || !($pdo instanceof PDO)) {
    exit('Veritabanı bağlantısı bulunamadı.');
}

function floor_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$message = '';
$error = '';

$branches = $pdo->query("
    SELECT b.id, b.name, b.code, b.status, h.name AS hotel_name
    FROM hotel_branches b
    INNER JOIN hotel_properties h ON h.id = b.hotel_id
    WHERE b.status = 'active'
      AND h.status = 'active' AND $hotelScope
    ORDER BY h.name, b.name
")->fetchAll(PDO::FETCH_ASSOC);

$selectedBranchId = (int)($_GET['branch_id'] ?? 0);
$editId = (int)($_GET['edit'] ?? 0);

/* POST işlemleri */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    htv_check_csrf();

    $action = (string)($_POST['action'] ?? '');
    $branchId = (int)($_POST['branch_id'] ?? 0);
    $floorId = (int)($_POST['floor_id'] ?? 0);

    $branchCheck = $pdo->prepare("
        SELECT b.id
        FROM hotel_branches b
        INNER JOIN hotel_properties h ON h.id = b.hotel_id
        WHERE b.id = ?
          AND b.status = 'active'
          AND h.status = 'active' AND $hotelScope
        LIMIT 1
    ");
    $branchCheck->execute([$branchId]);
    $validBranch = (bool)$branchCheck->fetchColumn();

    if ($action === 'save') {

        $name = trim((string)($_POST['name'] ?? ''));
        $sortOrder = (int)($_POST['sort_order'] ?? 0);

        if (!$validBranch) {
            $error = 'Lütfen aktif bir şube seçin.';

        } elseif ($name === '' || mb_strlen($name, 'UTF-8') > 100) {
            $error = 'Kat adı boş olamaz ve 100 karakteri geçemez.';

        } elseif ($floorId > 0) {

            $check = $pdo->prepare("
                SELECT id FROM hotel_floors
                WHERE id = ? AND branch_id = ? AND $floorScope
            ");
            $check->execute([$floorId, $branchId]);

            if (!$check->fetchColumn()) {
                $error = 'Düzenlenecek kat bulunamadı.';
            } else {
                $stmt = $pdo->prepare("
                    UPDATE hotel_floors
                    SET name = ?, sort_order = ?
                    WHERE id = ? AND branch_id = ? AND $floorScope
                ");
                $stmt->execute([$name, $sortOrder, $floorId, $branchId]);

                header('Location: floors.php?branch_id=' . $branchId . '&saved=1');
                exit;
            }

        } else {

            $stmt = $pdo->prepare("
                INSERT INTO hotel_floors
                    (branch_id, name, sort_order)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$branchId, $name, $sortOrder]);

            header('Location: floors.php?branch_id=' . $branchId . '&saved=1');
            exit;
        }

        $selectedBranchId = $branchId;
    }

    if ($action === 'delete') {

        $check = $pdo->prepare("
            SELECT COUNT(*)
            FROM hotel_rooms
            WHERE floor_id = ? AND branch_id = ? AND $floorScope
        ");
        $check->execute([$floorId, $branchId]);

        if (!$validBranch || $floorId < 1) {
            $error = 'Geçersiz kat veya şube.';

        } elseif ((int)$check->fetchColumn() > 0) {
            $error = 'Bu kata bağlı odalar bulunuyor. Önce odaları taşıyın.';

        } else {
            $stmt = $pdo->prepare("
                DELETE FROM hotel_floors
                WHERE id = ? AND branch_id = ? AND $floorScope
            ");
            $stmt->execute([$floorId, $branchId]);

            header('Location: floors.php?branch_id=' . $branchId . '&deleted=1');
            exit;
        }

        $selectedBranchId = $branchId;
    }
}

if (isset($_GET['saved'])) {
    $message = 'Kat kaydı başarıyla kaydedildi.';
}

if (isset($_GET['deleted'])) {
    $message = 'Kat kaydı silindi.';
}

/* Düzenlenecek kat */
$editFloor = null;

if ($editId > 0) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM hotel_floors
        WHERE id = ? AND $floorScope
        LIMIT 1
    ");
    $stmt->execute([$editId]);
    $editFloor = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    if ($editFloor) {
        $selectedBranchId = (int)$editFloor['branch_id'];
    }
}

/* Seçilen şube */
$selectedBranch = null;

foreach ($branches as $branch) {
    if ((int)$branch['id'] === $selectedBranchId) {
        $selectedBranch = $branch;
        break;
    }
}

/* Kat listesi */
$floors = [];

if ($selectedBranch) {
    $stmt = $pdo->prepare("
        SELECT
            f.*,
            (
                SELECT COUNT(*)
                FROM hotel_rooms r
                WHERE r.floor_id = f.id
            ) AS room_count
        FROM hotel_floors f
        WHERE f.branch_id = ?
        ORDER BY f.sort_order ASC, f.id ASC
    ");
    $stmt->execute([$selectedBranchId]);
    $floors = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>
<?php layout_start('Hotel TV - Kat Yönetimi'); ?>
<style>
.container {
    max-width:1100px;
    margin:auto;
}
.card {
    background:#fff;
    border:1px solid #e5e9f0;
    border-radius:12px;
    padding:22px;
    margin-bottom:20px;
}
h1 { margin-top:0; font-size:27px; }
h2 { font-size:19px; margin-top:0; }
label {
    display:block;
    font-weight:bold;
    margin-bottom:7px;
}
input,select {
    width:100%;
    padding:11px;
    border:1px solid #ccd3df;
    border-radius:7px;
    box-sizing:border-box;
    font-size:15px;
}
.grid {
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:15px;
}
.btn {
    display:inline-block;
    padding:10px 15px;
    border:0;
    border-radius:7px;
    background:#2457d6;
    color:white;
    text-decoration:none;
    cursor:pointer;
    font-size:14px;
}
.btn.gray { background:#64748b; }
.btn.red { background:#b42318; }
.btn.green { background:#087443; }
.actions { margin-top:15px; display:flex; gap:8px; flex-wrap:wrap; }
.notice {
    padding:12px;
    background:#e8f7ee;
    color:#087443;
    border-radius:7px;
    margin-bottom:15px;
}
.error {
    background:#fff0ee;
    color:#b42318;
}
table {
    width:100%;
    border-collapse:collapse;
}
th,td {
    padding:12px;
    border-bottom:1px solid #e5e9f0;
    text-align:left;
}
th { color:#667085; }
.inline { display:inline-block; }
@media(max-width:650px) {
.grid { grid-template-columns:1fr; }
    .card { padding:15px; }
    table { font-size:13px; }
}
</style>
<div class="container">

    <h1>Kat Yönetimi</h1>
    <p>Hotel TV şubelerine kat ekleyin ve kat sıralamasını düzenleyin.</p>

    <div class="actions" style="margin-bottom:20px">
        <a href="branches.php" class="btn gray">Şube Yönetimine Dön</a>
    </div>

    <?php if ($message): ?>
        <div class="notice"><?= floor_e($message) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="notice error"><?= floor_e($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <h2>Şube Seçimi</h2>

        <?php if (!$branches): ?>

            <p>Henüz aktif şube bulunmuyor.</p>
            <a href="branches.php" class="btn">Şube Ekle</a>

        <?php else: ?>

            <form method="get">
                <div class="grid">
                    <div>
                        <label>Otel / Şube</label>
                        <select name="branch_id" required>
                            <option value="">Şube seçin</option>

                            <?php foreach ($branches as $branch): ?>
                                <option
                                    value="<?= (int)$branch['id'] ?>"
                                    <?= $selectedBranchId === (int)$branch['id'] ? 'selected' : '' ?>
                                >
                                    <?= floor_e(
                                        $branch['hotel_name'] . ' - ' .
                                        $branch['name'] . ' (' .
                                        $branch['code'] . ')'
                                    ) ?>
                                </option>
                            <?php endforeach; ?>

                        </select>
                    </div>

                    <div style="align-self:end">
                        <button class="btn" type="submit">
                            Katları Göster
                        </button>
                    </div>
                </div>
            </form>

        <?php endif; ?>
    </div>

    <?php if ($selectedBranch): ?>

    <div class="card">

        <h2><?= $editFloor ? 'Kat Düzenle' : 'Yeni Kat Ekle' ?></h2>

        <p>
            <strong>Otel:</strong>
            <?= floor_e($selectedBranch['hotel_name']) ?>
            <br>
            <strong>Şube:</strong>
            <?= floor_e($selectedBranch['name']) ?>
        </p>

        <form method="post">

            <input type="hidden" name="csrf" value="<?= floor_e(csrf()) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="branch_id" value="<?= (int)$selectedBranchId ?>">
            <input type="hidden" name="floor_id" value="<?= (int)($editFloor['id'] ?? 0) ?>">

            <div class="grid">

                <div>
                    <label>Kat Adı</label>
                    <input
                        type="text"
                        name="name"
                        maxlength="100"
                        required
                        placeholder="Örn. Zemin Kat veya 1. Kat"
                        value="<?= floor_e($editFloor['name'] ?? '') ?>"
                    >
                </div>

                <div>
                    <label>Sıralama</label>
                    <input
                        type="number"
                        name="sort_order"
                        value="<?= (int)($editFloor['sort_order'] ?? 0) ?>"
                    >
                </div>

            </div>

            <div class="actions">
                <button type="submit" class="btn green">
                    <?= $editFloor ? 'Değişiklikleri Kaydet' : 'Kat Ekle' ?>
                </button>

                <?php if ($editFloor): ?>
                    <a href="floors.php?branch_id=<?= (int)$selectedBranchId ?>" class="btn gray">
                        Vazgeç
                    </a>
                <?php endif; ?>
            </div>

        </form>
    </div>

    <div class="card">

        <h2>Kayıtlı Katlar</h2>

        <?php if (!$floors): ?>

            <p>Bu şubeye henüz kat eklenmemiş.</p>

        <?php else: ?>

            <table>
                <thead>
                    <tr>
                        <th>Kat</th>
                        <th>Sıralama</th>
                        <th>Oda Sayısı</th>
                        <th>İşlem</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($floors as $floor): ?>

                    <tr>
                        <td><strong><?= floor_e($floor['name']) ?></strong></td>
                        <td><?= (int)$floor['sort_order'] ?></td>
                        <td><?= (int)$floor['room_count'] ?></td>

                        <td>
                            <a
                                class="btn gray"
                                href="floors.php?branch_id=<?= (int)$selectedBranchId ?>&edit=<?= (int)$floor['id'] ?>"
                            >Düzenle</a>

                            <?php if ((int)$floor['room_count'] === 0): ?>

                                <form method="post" class="inline"
                                      onsubmit="return confirm('Bu kat silinsin mi?');">

                                    <input type="hidden" name="csrf" value="<?= floor_e(csrf()) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="branch_id" value="<?= (int)$selectedBranchId ?>">
                                    <input type="hidden" name="floor_id" value="<?= (int)$floor['id'] ?>">

                                    <button type="submit" class="btn red">Sil</button>
                                </form>

                            <?php else: ?>
                                <small>Oda bağlı</small>
                            <?php endif; ?>

                        </td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>

        <?php endif; ?>

    </div>

    <?php endif; ?>

</div>
<?php layout_end(); ?>
