<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_admin();
require_once __DIR__ . '/hotel_access.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $hotelId = filter_input(INPUT_POST, 'hotel_id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $action = $_POST['action'] ?? '';
    if (!$userId || !$hotelId || !in_array($action, ['grant', 'revoke'], true)) {
        http_response_code(400);
        exit('Geçerli bir kullanıcı ve otel seçin.');
    }

    if ($action === 'grant') {
        $query = $pdo->prepare("
            INSERT INTO hotel_user_access (user_id, hotel_id)
            SELECT u.id, h.id FROM users u
            CROSS JOIN hotel_properties h
            WHERE u.id = ? AND h.id = ? AND u.status = 'active'
              AND u.role IN ('admin', 'customer')
            ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)
        ");
    } else {
        $query = $pdo->prepare('DELETE FROM hotel_user_access WHERE user_id = ? AND hotel_id = ?');
    }
    $query->execute([$userId, $hotelId]);
    header('Location: hotel_assignments.php', true, 303);
    exit;
}

$users = $pdo->query("SELECT id, name, email, role FROM users
    WHERE status = 'active' AND role IN ('admin', 'customer') ORDER BY name, id")->fetchAll();
$hotels = $pdo->query('SELECT id, name FROM hotel_properties ORDER BY name, id')->fetchAll();
$assignments = $pdo->query('SELECT a.user_id, a.hotel_id, u.name, u.email, h.name AS hotel
    FROM hotel_user_access a JOIN users u ON u.id = a.user_id
    JOIN hotel_properties h ON h.id = a.hotel_id ORDER BY h.name, u.name')->fetchAll();

layout_start('Hotel TV · Otel Yetkileri');
?>
<h1>Otel yetkileri</h1>
<p><a href="index.php">Hotel TV yönetimi</a></p>
<?php if ($users && $hotels): ?>
<form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <input type="hidden" name="action" value="grant">
    <label>Kullanıcı
        <select name="user_id" required>
            <?php foreach ($users as $account): ?>
                <option value="<?= (int)$account['id'] ?>"><?= e($account['name'].' · '.$account['email'].' · '.$account['role']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Otel
        <select name="hotel_id" required>
            <?php foreach ($hotels as $hotel): ?>
                <option value="<?= (int)$hotel['id'] ?>"><?= e($hotel['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <button type="submit">Yetki ver</button>
</form>
<?php endif; ?>
<h2>Verilen yetkiler</h2>
<?php if (!$assignments): ?><p>Henüz otel ataması yok.</p><?php endif; ?>
<ul>
    <?php foreach ($assignments as $assignment): ?>
        <li>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
                <input type="hidden" name="action" value="revoke">
                <input type="hidden" name="user_id" value="<?= (int)$assignment['user_id'] ?>">
                <input type="hidden" name="hotel_id" value="<?= (int)$assignment['hotel_id'] ?>">
                <?= e($assignment['hotel'].' · '.$assignment['name'].' · '.$assignment['email']) ?>
                <button type="submit">Yetkiyi kaldır</button>
            </form>
        </li>
    <?php endforeach; ?>
</ul>
<?php layout_end(); ?>
