<?php
declare(strict_types=1);
require dirname(__DIR__,2).'/app/bootstrap.php';
require_once __DIR__.'/hotel_access.php';
require_once __DIR__.'/flights_common.php';
htv_require_manager();
$canManageProvider=htv_is_superadmin();
$hotelScope=htv_hotel_scope('id');
if(session_status()!==PHP_SESSION_ACTIVE)session_start();
if(empty($_SESSION['htvf_csrf']))$_SESSION['htvf_csrf']=bin2hex(random_bytes(32));
$hotels=$pdo->query("SELECT id,name FROM hotel_properties WHERE $hotelScope ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$ids=array_map('intval',array_column($hotels,'id'));
$hotelId=(int)($_POST['hotel_id']??$_GET['hotel_id']??($ids[0]??0));
if($hotelId && !in_array($hotelId,$ids,true)){http_response_code(403);exit('Geçersiz otel.');}
$error='';$success=''; $cities=htvf_airports();
if($_SERVER['REQUEST_METHOD']==='POST')try{
 if(!hash_equals($_SESSION['htvf_csrf'],(string)($_POST['csrf']??'')))throw new RuntimeException('CSRF hatası.');
 if(!$hotelId)throw new RuntimeException('Otel seçiniz.');
 $city=(string)($_POST['city']??''); if(!isset($cities[$city]))throw new RuntimeException('Listeden il seçiniz.');
 $codes=implode(',',htvf_codes((string)($_POST['airport_codes']??'')));
 if($codes==='')throw new RuntimeException('En az bir IATA havalimanı kodu giriniz.');
 $direction=(string)($_POST['direction']??'departures');if(!in_array($direction,['departures','arrivals','both'],true))throw new RuntimeException('Yön geçersiz.');
 if($canManageProvider){
  $url=trim((string)($_POST['provider_url']??''));
  if($url!==''&&(!filter_var($url,FILTER_VALIDATE_URL)||parse_url($url,PHP_URL_SCHEME)!=='https'))throw new RuntimeException('Sağlayıcı URL HTTPS olmalı.');
  $old=htvf_settings($pdo,$hotelId);
  $key=trim((string)($_POST['api_key']??''));
  if($key==='')$key=(string)($old['api_key']??'');
  $enabled=isset($_POST['enabled'])?1:0;
  if($enabled && $url==='')throw new RuntimeException('Otomatik güncelleme için sağlayıcı URL gereklidir.');
  $q=$pdo->prepare('INSERT INTO hotel_flight_settings(hotel_id,city,airport_codes,direction,provider_url,api_key,enabled) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE city=VALUES(city),airport_codes=VALUES(airport_codes),direction=VALUES(direction),provider_url=VALUES(provider_url),api_key=VALUES(api_key),enabled=VALUES(enabled)');
  $q->execute([$hotelId,$city,$codes,$direction,$url?:null,$key?:null,$enabled]);
 }else{
  htv_require_hotel($pdo,$hotelId);
  $q=$pdo->prepare('INSERT INTO hotel_flight_settings(hotel_id,city,airport_codes,direction) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE city=VALUES(city),airport_codes=VALUES(airport_codes),direction=VALUES(direction)');
  $q->execute([$hotelId,$city,$codes,$direction]);
 }
 $success='Ayarlar kaydedildi.';
}catch(Throwable $ex){error_log('[HTV flights admin] '.$ex->getMessage());$error=$ex instanceof PDOException?'Veritabanı hatası. SQL kurulumunu kontrol edin.':$ex->getMessage();}
try{$settings=$hotelId?htvf_settings($pdo,$hotelId):null;}catch(Throwable $ex){$settings=null;$error='Tablo bulunamadı. SQL dosyasını çalıştırın.';}
$city=(string)($settings['city']??'İzmir');$codes=(string)($settings['airport_codes']??($cities[$city]??''));
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hotel TV · Otomatik Uçuşlar</title><style>body{font:16px system-ui;background:#0b1525;color:#f4f6fc;margin:0}main{max-width:850px;margin:32px auto;padding:0 18px}section{background:#142238;border:1px solid #293c57;border-radius:14px;padding:22px}label{display:block;margin-top:16px;color:#cbd5e1}input,select{box-sizing:border-box;width:100%;padding:12px;border-radius:8px;border:1px solid #45556e;background:#0c1728;color:white}button{margin-top:20px;background:#c9b176;color:#101927;padding:12px 18px;border:0;border-radius:9px;font-weight:bold}a{color:#c9b176}.note{color:#aebbd0}.error{color:#ffb4b4}</style></head><body><main><a href="index.php">← Hotel TV</a><h1>Otomatik Uçuş Bilgileri</h1><p class="note">İl seçimi havalimanı önerir. Gerçek uçuş verileri için lisanslı JSON API sağlayıcısı gereklidir.</p><?php if($error):?><p class="error"><?=htvf_e($error)?></p><?php endif;?><?php if($success):?><p><?=htvf_e($success)?></p><?php endif;?><section><form method="get"><label>Otel</label><select name="hotel_id" onchange="this.form.submit()"><?php foreach($hotels as $h):?><option value="<?=(int)$h['id']?>" <?=$hotelId===(int)$h['id']?'selected':''?>><?=htvf_e($h['name'])?></option><?php endforeach;?></select></form><form method="post"><input type="hidden" name="csrf" value="<?=htvf_e($_SESSION['htvf_csrf'])?>"><input type="hidden" name="hotel_id" value="<?=$hotelId?>"><label>İl</label><select id="city" name="city"><?php foreach($cities as $name=>$airport):?><option value="<?=htvf_e($name)?>" <?=$name===$city?'selected':''?> data-codes="<?=htvf_e($airport)?>"><?=htvf_e($name)?></option><?php endforeach;?></select><label>Havalimanı IATA kodları (virgülle)</label><input id="codes" name="airport_codes" value="<?=htvf_e($codes)?>" required maxlength="255"><label>Gösterilecek uçuşlar</label><select name="direction"><option value="departures" <?=($settings['direction']??'')==='departures'?'selected':''?>>Giden</option><option value="arrivals" <?=($settings['direction']??'')==='arrivals'?'selected':''?>>Gelen</option><option value="both" <?=($settings['direction']??'')==='both'?'selected':''?>>Giden + Gelen</option></select><?php if($canManageProvider):?><label>Sağlayıcı HTTPS URL şablonu</label><input name="provider_url" value="<?=htvf_e($settings['provider_url']??'')?>" placeholder="https://api.saglayici.com/flights?airport={airport}&direction={direction}"><p class="note">URL şablonunda {airport} ve {direction} kullanın. Sağlayıcının JSON çıktısı README'deki alanları karşılamalıdır.</p><label>API anahtarı (boşsa mevcut korunur)</label><input name="api_key" type="password" autocomplete="new-password" placeholder="Mevcut anahtar gösterilmez"><label><input type="checkbox" name="enabled" value="1" style="width:auto" <?=!empty($settings['enabled'])?'checked':''?>> Otomatik güncellemeyi etkinleştir</label><?php endif;?><button type="submit">Ayarları kaydet</button></form></section><p><a href="flights_board.php?hotel_id=<?=$hotelId?>">Uçuş panosunu görüntüle</a></p><script>document.getElementById('city').addEventListener('change',function(){document.getElementById('codes').value=this.selectedOptions[0].dataset.codes||'';});</script></main></body></html>
