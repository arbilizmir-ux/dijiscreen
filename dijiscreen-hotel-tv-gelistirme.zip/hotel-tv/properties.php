<?php
// DijiScreen Hotel TV - Otel Yönetimi
// Bu dosya mevcut DijiScreen tablolarına veya Android Player API'sine dokunmaz.
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('id');
$listScope = htv_hotel_scope('p.id');

$notice = '';
$error = '';
$editId = max(0, (int)($_GET['edit'] ?? 0));

$form = [
    'name' => '', 'code' => '', 'status' => 'active',
    'timezone' => 'Europe/Istanbul', 'country_code' => 'TR',
    'contact_name' => '', 'contact_email' => '',
    'contact_phone' => '', 'address' => ''
];

if ($editId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM hotel_properties WHERE id = ? AND $hotelScope LIMIT 1");
    $stmt->execute([$editId]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$existing) {
        http_response_code(404);
        exit('Otel kaydı bulunamadı.');
    }
    foreach ($form as $key => $value) {
        if (array_key_exists($key, $existing)) $form[$key] = (string)($existing[$key] ?? $value);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $id = max(0, (int)($_POST['id'] ?? 0));
    if ($id > 0) {
        htv_require_hotel($pdo, $id);
    } elseif (!htv_is_superadmin()) {
        htv_access_denied();
    }
    $name = trim((string)($_POST['name'] ?? ''));
    $code = strtolower(trim((string)($_POST['code'] ?? '')));
    $status = (string)($_POST['status'] ?? 'active');
    $timezone = trim((string)($_POST['timezone'] ?? 'Europe/Istanbul'));
    $country = strtoupper(trim((string)($_POST['country_code'] ?? 'TR')));
    $contactName = trim((string)($_POST['contact_name'] ?? ''));
    $email = trim((string)($_POST['contact_email'] ?? ''));
    $phone = trim((string)($_POST['contact_phone'] ?? ''));
    $address = trim((string)($_POST['address'] ?? ''));

    $form = [
        'name' => $name, 'code' => $code, 'status' => $status,
        'timezone' => $timezone, 'country_code' => $country,
        'contact_name' => $contactName, 'contact_email' => $email,
        'contact_phone' => $phone, 'address' => $address
    ];

    if ($name === '') {
        $error = 'Otel adı zorunludur.';
    } elseif (!preg_match('/^[a-z0-9][a-z0-9_-]{1,63}$/', $code)) {
        $error = 'Otel kodu 2-64 karakter olmalı; küçük harf, rakam, tire ve alt çizgi kullanılabilir.';
    } elseif (!in_array($status, ['active', 'suspended', 'archived'], true)) {
        $error = 'Geçersiz otel durumu.';
    } elseif (!preg_match('/^[A-Z]{2}$/', $country)) {
        $error = 'Ülke kodu iki harfli olmalıdır (ör. TR).';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'E-posta adresini kontrol edin.';
    } elseif (!in_array($timezone, timezone_identifiers_list(), true)) {
        $error = 'Geçerli bir saat dilimi seçin.';
    } else {
        try {
            if ($id > 0) {
                $q = $pdo->prepare("UPDATE hotel_properties SET name=?, code=?, status=?, timezone=?, country_code=?, contact_name=?, contact_email=?, contact_phone=?, address=? WHERE id=? AND $hotelScope");
                $q->execute([$name, $code, $status, $timezone, $country, $contactName ?: null, $email ?: null, $phone ?: null, $address ?: null, $id]);
                $notice = 'Otel bilgileri güncellendi.';
                $editId = $id;
            } else {
                $q = $pdo->prepare('INSERT INTO hotel_properties (name, code, status, timezone, country_code, contact_name, contact_email, contact_phone, address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
                $q->execute([$name, $code, $status, $timezone, $country, $contactName ?: null, $email ?: null, $phone ?: null, $address ?: null]);
                $newId = (int)$pdo->lastInsertId();
                $notice = 'Otel kaydı oluşturuldu.';
                $editId = 0;
                $form = ['name'=>'','code'=>'','status'=>'active','timezone'=>'Europe/Istanbul','country_code'=>'TR','contact_name'=>'','contact_email'=>'','contact_phone'=>'','address'=>''];
            }
        } catch (PDOException $e) {
            error_log('[DijiScreen Hotel TV properties] ' . $e->getMessage());
            $error = $e->getCode() === '23000' ? 'Bu otel kodu daha önce kullanılmış. Farklı bir kod girin.' : 'Kayıt sırasında veritabanı hatası oluştu. Sunucu kayıtlarını kontrol edin.';
        }
    }
}

$list = $pdo->query("SELECT p.id, p.name, p.code, p.status, p.country_code, p.created_at,
    (SELECT COUNT(*) FROM hotel_branches b WHERE b.hotel_id = p.id) AS branch_count,
    (SELECT COUNT(*) FROM hotel_rooms r INNER JOIN hotel_branches b2 ON b2.id = r.branch_id WHERE b2.hotel_id = p.id) AS room_count,
    (SELECT COUNT(*) FROM hotel_devices d INNER JOIN hotel_branches b3 ON b3.id = d.branch_id WHERE b3.hotel_id = p.id) AS device_count
    FROM hotel_properties p WHERE $listScope ORDER BY p.created_at DESC, p.id DESC")->fetchAll(PDO::FETCH_ASSOC);

layout_start('Otel Yönetimi');
?>
<style>
.ht-wrap{display:grid;grid-template-columns:minmax(280px,380px) minmax(0,1fr);gap:18px;align-items:start}
.ht-card{background:#fff;border:1px solid #e7e9ed;border-radius:12px;padding:20px;margin:14px 0;box-shadow:0 2px 10px #00000008}
.ht-card h2{font-size:19px;margin:0 0 16px;color:#202633}
.ht-field{margin:12px 0}.ht-field label{display:block;font-weight:600;font-size:13px;margin-bottom:6px}
.ht-field input,.ht-field select,.ht-field textarea{width:100%;box-sizing:border-box;padding:10px 11px;border:1px solid #d9dde4;border-radius:7px;background:#fff;font:inherit}
.ht-field textarea{min-height:75px;resize:vertical}.ht-help{font-size:12px;color:#737b88;margin-top:5px}
.ht-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}.ht-btn{display:inline-block;border:0;border-radius:7px;padding:10px 14px;background:#d71920;color:#fff;text-decoration:none;font-weight:600;cursor:pointer}.ht-btn.secondary{background:#eef0f3;color:#293241}
.ht-alert{padding:12px 14px;border-radius:8px;margin:12px 0}.ht-ok{background:#eaf7ee;color:#176b36}.ht-error{background:#fff0f0;color:#a51d24}
.ht-table-wrap{overflow:auto}.ht-table{width:100%;border-collapse:collapse;min-width:650px}.ht-table th,.ht-table td{padding:11px 10px;border-bottom:1px solid #edf0f3;text-align:left;font-size:13px;vertical-align:middle}.ht-table th{color:#687181;font-weight:700;background:#fafbfc}.ht-status{display:inline-block;padding:4px 8px;border-radius:20px;font-size:11px;font-weight:700}.ht-active{background:#e8f6ed;color:#18743a}.ht-suspended{background:#fff3df;color:#8a5a00}.ht-archived{background:#eef0f3;color:#687181}.ht-muted{color:#77808d;font-size:12px}
@media(max-width:900px){.ht-wrap{grid-template-columns:1fr}}
</style>

<div class="ht-card">
    <h2>DijiScreen Hotel TV · Otel Yönetimi</h2>
    <div class="ht-muted">Otel kayıtları Hotel TV modülünün kendi tablolarında tutulur. Mevcut DijiScreen ekranları ve Android Player etkilenmez.</div>
    <?php if ($notice !== ''): ?><div class="ht-alert ht-ok"><?= e($notice) ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="ht-alert ht-error"><?= e($error) ?></div><?php endif; ?>
</div>

<div class="ht-wrap">
    <section class="ht-card">
        <?php if ($editId || htv_is_superadmin()): ?>
        <h2><?= $editId > 0 ? 'Otel Bilgilerini Düzenle' : 'Yeni Otel Ekle' ?></h2>
        <form method="post" action="properties.php<?= $editId > 0 ? '?edit=' . (int)$editId : '' ?>">
            <?php if (function_exists('csrf')): ?><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><?php endif; ?>
            <input type="hidden" name="id" value="<?= (int)$editId ?>">
            <div class="ht-field"><label for="name">Otel adı *</label><input id="name" name="name" required maxlength="190" value="<?= e($form['name']) ?>" placeholder="Örn. Ege Hotel"></div>
            <div class="ht-field"><label for="code">Otel kodu *</label><input id="code" name="code" required maxlength="64" pattern="[a-z0-9][a-z0-9_-]{1,63}" value="<?= e($form['code']) ?>" placeholder="ege_hotel"><div class="ht-help">Sistemde benzersiz olmalı; küçük harf ve rakam kullanın.</div></div>
            <div class="ht-field"><label for="status">Durum</label><select id="status" name="status"><option value="active" <?= $form['status']==='active'?'selected':'' ?>>Aktif</option><option value="suspended" <?= $form['status']==='suspended'?'selected':'' ?>>Askıya alındı</option><option value="archived" <?= $form['status']==='archived'?'selected':'' ?>>Arşivlendi</option></select></div>
            <div class="ht-field"><label for="country_code">Ülke kodu</label><input id="country_code" name="country_code" maxlength="2" value="<?= e($form['country_code']) ?>"></div>
            <div class="ht-field"><label for="timezone">Saat dilimi</label><select id="timezone" name="timezone"><option value="Europe/Istanbul" <?= $form['timezone']==='Europe/Istanbul'?'selected':'' ?>>Türkiye – Europe/Istanbul</option><option value="Europe/London" <?= $form['timezone']==='Europe/London'?'selected':'' ?>>Europe/London</option><option value="Europe/Berlin" <?= $form['timezone']==='Europe/Berlin'?'selected':'' ?>>Europe/Berlin</option><option value="Asia/Dubai" <?= $form['timezone']==='Asia/Dubai'?'selected':'' ?>>Asia/Dubai</option><option value="America/New_York" <?= $form['timezone']==='America/New_York'?'selected':'' ?>>America/New_York</option></select></div>
            <div class="ht-field"><label for="contact_name">Yetkili kişi</label><input id="contact_name" name="contact_name" maxlength="190" value="<?= e($form['contact_name']) ?>"></div>
            <div class="ht-field"><label for="contact_email">E-posta</label><input id="contact_email" type="email" name="contact_email" maxlength="190" value="<?= e($form['contact_email']) ?>"></div>
            <div class="ht-field"><label for="contact_phone">Telefon</label><input id="contact_phone" name="contact_phone" maxlength="50" value="<?= e($form['contact_phone']) ?>"></div>
            <div class="ht-field"><label for="address">Adres</label><textarea id="address" name="address"><?= e($form['address']) ?></textarea></div>
            <div class="ht-actions"><button class="ht-btn" type="submit"><?= $editId > 0 ? 'Değişiklikleri Kaydet' : 'Oteli Oluştur' ?></button><?php if ($editId > 0): ?><a class="ht-btn secondary" href="properties.php">Vazgeç</a><?php endif; ?></div>
        </form>
        <?php else: ?><p>Düzenlemek için listeden bir otel seçin.</p><?php endif; ?>
    </section>

    <section class="ht-card">
        <h2>Kayıtlı Oteller <span class="ht-muted">(<?= count($list) ?>)</span></h2>
        <?php if (!$list): ?>
            <p class="ht-muted">Görüntülenebilen otel kaydı yok.</p>
        <?php else: ?>
            <div class="ht-table-wrap"><table class="ht-table"><thead><tr><th>Otel</th><th>Kod</th><th>Şube</th><th>Oda</th><th>TV</th><th>Durum</th><th></th></tr></thead><tbody>
            <?php foreach ($list as $hotel): ?>
                <tr>
                    <td><strong><?= e($hotel['name']) ?></strong><div class="ht-muted"><?= e($hotel['country_code']) ?></div></td>
                    <td><?= e($hotel['code']) ?></td><td><?= (int)$hotel['branch_count'] ?></td><td><?= (int)$hotel['room_count'] ?></td><td><?= (int)$hotel['device_count'] ?></td>
                    <td><span class="ht-status ht-<?= e($hotel['status']) ?>"><?= $hotel['status']==='active'?'Aktif':($hotel['status']==='suspended'?'Askıda':'Arşiv') ?></span></td>
                    <td><a class="ht-btn secondary" href="properties.php?edit=<?= (int)$hotel['id'] ?>">Düzenle</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <?php endif; ?>
    </section>
</div>
<?php layout_end(); ?>
