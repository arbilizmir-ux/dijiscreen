<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('b.hotel_id');
$roomScope = htv_branch_scope('branch_id');
$listScope = htv_branch_scope('r.branch_id');

function hotel_room_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$error = '';
$success = '';

$allowedStatuses = ['active', 'inactive', 'maintenance'];

/* Aktif otellerin şubeleri */
$branches = $pdo->query("
    SELECT b.id, b.name, b.code, b.hotel_id, p.name AS hotel_name
    FROM hotel_branches b
    INNER JOIN hotel_properties p ON p.id = b.hotel_id
    WHERE b.status = 'active' AND p.status = 'active' AND $hotelScope
    ORDER BY p.name, b.name
")->fetchAll(PDO::FETCH_ASSOC);

$branchIds = array_map('intval', array_column($branches, 'id'));

$selectedBranch = (int)($_GET['branch_id'] ?? $_POST['branch_id'] ?? 0);
if (!$selectedBranch && count($branches) > 0) {
    $selectedBranch = (int)$branches[0]['id'];
}

$validBranch = in_array($selectedBranch, $branchIds, true);

if (!$validBranch && $selectedBranch !== 0) {
    $selectedBranch = 0;
}

/* Seçilen şubenin katları */
$floors = [];
if ($validBranch) {
    $stmt = $pdo->prepare("
        SELECT id, name
        FROM hotel_floors
        WHERE branch_id = ? AND $roomScope
        ORDER BY sort_order, name
    ");
    $stmt->execute([$selectedBranch]);
    $floors = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/* Düzenlenecek oda */
$editRoom = null;
$editId = (int)($_GET['edit'] ?? 0);

if ($editId > 0 && $validBranch) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM hotel_rooms
        WHERE id = ? AND branch_id = ? AND $roomScope
        LIMIT 1
    ");
    $stmt->execute([$editId, $selectedBranch]);
    $editRoom = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/* Oda kaydetme */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $action = $_POST['action'] ?? '';

    if (!$validBranch) {
        $error = 'Lütfen geçerli bir şube seçin.';
    } elseif ($action === 'save') {
        $roomId = (int)($_POST['room_id'] ?? 0);
        $roomNumber = trim($_POST['room_number'] ?? '');
        $roomName = trim($_POST['room_name'] ?? '');
        $roomType = trim($_POST['room_type'] ?? '');
        $capacity = (int)($_POST['capacity'] ?? 2);
        $floorId = (int)($_POST['floor_id'] ?? 0);
        $status = $_POST['status'] ?? 'active';

        if ($roomNumber === '' || mb_strlen($roomNumber) > 32) {
            $error = 'Oda numarası zorunludur ve en fazla 32 karakter olabilir.';
        } elseif (mb_strlen($roomName) > 100) {
            $error = 'Oda adı en fazla 100 karakter olabilir.';
        } elseif (mb_strlen($roomType) > 80) {
            $error = 'Oda tipi en fazla 80 karakter olabilir.';
        } elseif ($capacity < 1 || $capacity > 65535) {
            $error = 'Kapasite 1 ile 65535 arasında olmalıdır.';
        } elseif (!in_array($status, $allowedStatuses, true)) {
            $error = 'Geçersiz oda durumu.';
        } else {
            /* Katın aynı şubeye ait olduğunu doğrula */
            $validFloor = true;

            if ($floorId > 0) {
                $stmt = $pdo->prepare("
                    SELECT id
                    FROM hotel_floors
                    WHERE id = ? AND branch_id = ? AND $roomScope
                    LIMIT 1
                ");
                $stmt->execute([$floorId, $selectedBranch]);
                $validFloor = (bool)$stmt->fetchColumn();
            }

            if (!$validFloor) {
                $error = 'Seçilen kat bu şubeye ait değil.';
            } else {
                try {
                    if ($roomId > 0) {
                        $stmt = $pdo->prepare("
                            UPDATE hotel_rooms
                            SET floor_id = ?, room_number = ?, room_name = ?,
                                room_type = ?, capacity = ?, status = ?,
                                updated_at = CURRENT_TIMESTAMP
                            WHERE id = ? AND branch_id = ? AND $roomScope
                        ");

                        $stmt->execute([
                            $floorId ?: null,
                            $roomNumber,
                            $roomName ?: null,
                            $roomType ?: null,
                            $capacity,
                            $status,
                            $roomId,
                            $selectedBranch
                        ]);

                        if ($stmt->rowCount() === 0) {
                            $check = $pdo->prepare("
                                SELECT id FROM hotel_rooms
                                WHERE id = ? AND branch_id = ? AND $roomScope
                            ");
                            $check->execute([$roomId, $selectedBranch]);

                            if (!$check->fetchColumn()) {
                                throw new RuntimeException('Düzenlenecek oda bulunamadı.');
                            }
                        }

                        $success = 'Oda bilgileri güncellendi.';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO hotel_rooms
                            (branch_id, floor_id, room_number, room_name,
                             room_type, capacity, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?)
                        ");

                        $stmt->execute([
                            $selectedBranch,
                            $floorId ?: null,
                            $roomNumber,
                            $roomName ?: null,
                            $roomType ?: null,
                            $capacity,
                            $status
                        ]);

                        $success = 'Yeni oda başarıyla eklendi.';
                    }

                    $editRoom = null;
                    $_POST = [];
                } catch (PDOException $e) {
                    if ($e->getCode() === '23000') {
                        $error = 'Bu şubede aynı oda numarası zaten kayıtlı.';
                    } else {
                        $error = 'Veritabanı işlemi sırasında hata oluştu.';
                    }
                } catch (RuntimeException $e) {
                    $error = $e->getMessage();
                }
            }
        }
    }

    /* Oda silme */
    if ($action === 'delete') {
        $roomId = (int)($_POST['room_id'] ?? 0);

        if ($roomId > 0) {
            try {
                $stmt = $pdo->prepare("
                    SELECT id FROM hotel_rooms
                    WHERE id = ? AND branch_id = ? AND $roomScope
                    LIMIT 1
                ");
                $stmt->execute([$roomId, $selectedBranch]);

                if (!$stmt->fetchColumn()) {
                    $error = 'Silinecek oda bulunamadı.';
                } else {
                    /* Odaya bağlı cihaz varsa silmeye izin verme */
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM hotel_devices
                        WHERE room_id = ?
                    ");
                    $stmt->execute([$roomId]);
                    $deviceCount = (int)$stmt->fetchColumn();

                    /* Odaya bağlı konaklama kaydı varsa silmeye izin verme */
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM hotel_stays
                        WHERE room_id = ?
                    ");
                    $stmt->execute([$roomId]);
                    $stayCount = (int)$stmt->fetchColumn();

                    if ($deviceCount > 0 || $stayCount > 0) {
                        $error = 'Bu odaya bağlı cihaz veya konaklama kaydı var. Önce bağlantıları kaldırın.';
                    } else {
                        $stmt = $pdo->prepare("
                            DELETE FROM hotel_rooms
                            WHERE id = ? AND branch_id = ? AND $roomScope
                        ");
                        $stmt->execute([$roomId, $selectedBranch]);

                        $success = 'Oda başarıyla silindi.';
                    }
                }
            } catch (PDOException $e) {
                $error = 'Oda silinemedi. Odaya bağlı kayıtlar bulunuyor olabilir.';
            }
        }
    }

    /* POST sonrası aynı şubeye dön */
    if ($action === 'save' || $action === 'delete') {
        // Sayfa aynı şube seçili kalacak şekilde aşağıda yenilenir.
    }
}

/* Form değerleri */
$form = [
    'id' => $editRoom['id'] ?? '',
    'floor_id' => $editRoom['floor_id'] ?? '',
    'room_number' => $editRoom['room_number'] ?? '',
    'room_name' => $editRoom['room_name'] ?? '',
    'room_type' => $editRoom['room_type'] ?? '',
    'capacity' => $editRoom['capacity'] ?? 2,
    'status' => $editRoom['status'] ?? 'active'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save' && $error !== '') {
    $form = [
        'id' => (int)($_POST['room_id'] ?? 0),
        'floor_id' => $_POST['floor_id'] ?? '',
        'room_number' => $_POST['room_number'] ?? '',
        'room_name' => $_POST['room_name'] ?? '',
        'room_type' => $_POST['room_type'] ?? '',
        'capacity' => $_POST['capacity'] ?? 2,
        'status' => $_POST['status'] ?? 'active'
    ];
}

/* Oda listesi */
$rooms = [];

if ($validBranch) {
    $stmt = $pdo->prepare("
        SELECT r.*, f.name AS floor_name
        FROM hotel_rooms r
        LEFT JOIN hotel_floors f ON f.id = r.floor_id AND f.branch_id = r.branch_id
        WHERE r.branch_id = ? AND $listScope
        ORDER BY
            CASE WHEN r.room_number REGEXP '^[0-9]+$'
                 THEN CAST(r.room_number AS UNSIGNED) END,
            r.room_number
    ");
    $stmt->execute([$selectedBranch]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$statusLabels = [
    'active' => 'Aktif',
    'inactive' => 'Pasif',
    'maintenance' => 'Bakımda'
];
?>
<?php layout_start('Hotel TV - Oda Yönetimi'); ?>
<style>
*{box-sizing:border-box}
.container{max-width:1150px;margin:30px auto;padding:0 18px}
.header{margin-bottom:22px}
.header h1{margin:0 0 8px;font-size:27px}
.muted{color:#697586;font-size:14px}
.panel{background:#fff;border:1px solid #e4e8ef;border-radius:12px;padding:22px;margin-bottom:20px}
.panel h2{font-size:19px;margin:0 0 18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}
.field label{display:block;font-size:13px;font-weight:bold;margin-bottom:7px}
.field input,.field select{width:100%;padding:11px;border:1px solid #d5dbe5;border-radius:7px;font-size:14px;background:#fff}
.actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:18px}
.btn{display:inline-block;padding:10px 15px;border:0;border-radius:7px;background:#2457d6;color:#fff;text-decoration:none;cursor:pointer;font-size:14px}
.btn.gray{background:#687386}
.btn.red{background:#c83c48}
.btn.small{padding:7px 10px;font-size:12px}
.alert{padding:12px 15px;border-radius:8px;margin-bottom:16px;font-size:14px}
.alert.ok{background:#e7f7ed;color:#176b36}
.alert.err{background:#fff0f0;color:#a32828}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:700px}
th,td{text-align:left;padding:12px 10px;border-bottom:1px solid #edf0f4;font-size:14px}
th{color:#687386;background:#f8f9fb}
.status{display:inline-block;padding:5px 9px;border-radius:20px;font-size:12px;background:#e8f5ec;color:#176b36}
.status.inactive{background:#f0f1f3;color:#596273}
.status.maintenance{background:#fff2d9;color:#8a5a00}
.inline{display:inline}
.empty{text-align:center;padding:25px;color:#687386}
@media(max-width:650px){.grid{grid-template-columns:1fr}.panel{padding:16px}.container{margin:20px auto}}
</style>
<div class="container">

    <div class="header">
        <h1>Oda Yönetimi</h1>
        <div class="muted">DijiScreen Hotel TV · Otel odalarını ve oda bilgilerini yönetin.</div>
    </div>

    <?php if ($success): ?>
        <div class="alert ok"><?= hotel_room_e($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert err"><?= hotel_room_e($error) ?></div>
    <?php endif; ?>

    <section class="panel">
        <h2>Şube Seçimi</h2>

        <?php if (!$branches): ?>
            <div class="alert err">Henüz aktif bir otel şubesi bulunamadı. Önce otel ve şube kaydı oluşturun.</div>
        <?php else: ?>
            <form method="get">
                <div class="field">
                    <label>Otel / Şube</label>
                    <select name="branch_id" onchange="this.form.submit()">
                        <?php foreach ($branches as $branch): ?>
                            <option value="<?= (int)$branch['id'] ?>" <?= $selectedBranch === (int)$branch['id'] ? 'selected' : '' ?>>
                                <?= hotel_room_e($branch['hotel_name'] . ' / ' . $branch['name'] . ' (' . $branch['code'] . ')') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        <?php endif; ?>
    </section>

    <?php if ($validBranch): ?>
    <section class="panel">
        <h2><?= $form['id'] ? 'Oda Düzenle' : 'Yeni Oda Ekle' ?></h2>

        <form method="post">
            <input type="hidden" name="csrf" value="<?= hotel_room_e(csrf()) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="branch_id" value="<?= $selectedBranch ?>">
            <input type="hidden" name="room_id" value="<?= hotel_room_e($form['id']) ?>">

            <div class="grid">
                <div class="field">
                    <label>Oda Numarası *</label>
                    <input type="text" name="room_number" maxlength="32" required
                           placeholder="Örn. 101"
                           value="<?= hotel_room_e($form['room_number']) ?>">
                </div>

                <div class="field">
                    <label>Oda Adı</label>
                    <input type="text" name="room_name" maxlength="100"
                           placeholder="Örn. Deniz Manzaralı Oda"
                           value="<?= hotel_room_e($form['room_name']) ?>">
                </div>

                <div class="field">
                    <label>Kat</label>
                    <select name="floor_id">
                        <option value="">Kat seçilmedi</option>
                        <?php foreach ($floors as $floor): ?>
                            <option value="<?= (int)$floor['id'] ?>"
                                <?= (string)$form['floor_id'] === (string)$floor['id'] ? 'selected' : '' ?>>
                                <?= hotel_room_e($floor['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label>Oda Tipi</label>
                    <input type="text" name="room_type" maxlength="80"
                           placeholder="Örn. Standard, Deluxe, Suite"
                           value="<?= hotel_room_e($form['room_type']) ?>">
                </div>

                <div class="field">
                    <label>Kapasite (Kişi)</label>
                    <input type="number" name="capacity" min="1" max="65535" required
                           value="<?= hotel_room_e($form['capacity']) ?>">
                </div>

                <div class="field">
                    <label>Oda Durumu</label>
                    <select name="status">
                        <option value="active" <?= $form['status'] === 'active' ? 'selected' : '' ?>>Aktif</option>
                        <option value="inactive" <?= $form['status'] === 'inactive' ? 'selected' : '' ?>>Pasif</option>
                        <option value="maintenance" <?= $form['status'] === 'maintenance' ? 'selected' : '' ?>>Bakımda</option>
                    </select>
                </div>
            </div>

            <div class="actions">
                <button class="btn" type="submit"><?= $form['id'] ? 'Değişiklikleri Kaydet' : 'Oda Ekle' ?></button>

                <?php if ($form['id']): ?>
                    <a class="btn gray" href="?branch_id=<?= $selectedBranch ?>">Vazgeç</a>
                <?php endif; ?>
            </div>
        </form>
    </section>

    <section class="panel">
        <h2>Kayıtlı Odalar (<?= count($rooms) ?>)</h2>

        <?php if (!$rooms): ?>
            <div class="empty">Bu şubede henüz oda kaydı bulunmuyor.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Oda No</th>
                            <th>Oda Adı</th>
                            <th>Kat</th>
                            <th>Oda Tipi</th>
                            <th>Kapasite</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td><strong><?= hotel_room_e($room['room_number']) ?></strong></td>
                            <td><?= hotel_room_e($room['room_name'] ?: '-') ?></td>
                            <td><?= hotel_room_e($room['floor_name'] ?: 'Belirtilmedi') ?></td>
                            <td><?= hotel_room_e($room['room_type'] ?: '-') ?></td>
                            <td><?= (int)$room['capacity'] ?> kişi</td>
                            <td>
                                <span class="status <?= hotel_room_e($room['status']) ?>">
                                    <?= hotel_room_e($statusLabels[$room['status']] ?? $room['status']) ?>
                                </span>
                            </td>
                            <td>
                                <a class="btn small" href="?branch_id=<?= $selectedBranch ?>&edit=<?= (int)$room['id'] ?>">Düzenle</a>

                                <form method="post" class="inline"
                                      onsubmit="return confirm('Bu odayı silmek istediğinize emin misiniz?')">
                                    <input type="hidden" name="csrf" value="<?= hotel_room_e(csrf()) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="branch_id" value="<?= $selectedBranch ?>">
                                    <input type="hidden" name="room_id" value="<?= (int)$room['id'] ?>">
                                    <button class="btn red small" type="submit">Sil</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <div class="actions">
        <a class="btn gray" href="branches.php">Şube Yönetimi</a>
        <a class="btn gray" href="floors.php?branch_id=<?= $selectedBranch ?>">Kat Yönetimi</a>
    </div>

</div>
<?php layout_end(); ?>
