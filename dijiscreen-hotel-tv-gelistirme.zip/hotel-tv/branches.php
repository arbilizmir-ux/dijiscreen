<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';

require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$propertyScope = htv_hotel_scope('id');
$branchScope = htv_hotel_scope('hotel_id');
$listScope = htv_hotel_scope('b.hotel_id');

$errors = [];
$success = '';
$editing = null;

/* Otelleri getir */
try {
    $hotels = $pdo->query("
        SELECT id, name, code
        FROM hotel_properties
        WHERE status <> 'archived' AND $propertyScope
        ORDER BY name ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $hotels = [];
    $errors[] = 'Otel listesi alınamadı.';
}

/* Form işlemleri */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $action = trim((string)($_POST['action'] ?? ''));

    if ($action === 'save') {
        $branchId = (int)($_POST['branch_id'] ?? 0);
        $hotelId = (int)($_POST['hotel_id'] ?? 0);
        htv_require_hotel($pdo, $hotelId);
        $name = trim((string)($_POST['name'] ?? ''));
        $code = strtoupper(trim((string)($_POST['code'] ?? '')));
        $address = trim((string)($_POST['address'] ?? ''));
        $status = (string)($_POST['status'] ?? 'active');

        if ($hotelId < 1) {
            $errors[] = 'Lütfen otel seçin.';
        }

        if ($name === '') {
            $errors[] = 'Şube adı zorunludur.';
        }

        if (!preg_match('/^[A-Z0-9_-]{2,40}$/', $code)) {
            $errors[] = 'Şube kodu 2-40 karakter olmalı; harf, rakam, tire ve alt çizgi kullanılabilir.';
        }

        if (!in_array($status, ['active', 'inactive'], true)) {
            $status = 'active';
        }

        if (!$errors) {
            try {
                $check = $pdo->prepare("
                    SELECT id
                    FROM hotel_properties
                    WHERE id = ?
                    AND status <> 'archived' AND $propertyScope
                    LIMIT 1
                ");
                $check->execute([$hotelId]);

                if (!$check->fetchColumn()) {
                    $errors[] = 'Seçilen otel bulunamadı.';
                } else {
                    if ($branchId > 0) {
                        if (!htv_is_superadmin()) {
                            $current = $pdo->prepare("SELECT 1 FROM hotel_branches WHERE id = ? AND hotel_id = ? AND $branchScope");
                            $current->execute([$branchId, $hotelId]);
                            if (!$current->fetchColumn()) htv_access_denied();
                        }
                        $targetScope = htv_is_superadmin() ? '1=1' : 'hotel_id = ' . $hotelId;
                        $stmt = $pdo->prepare("
                            UPDATE hotel_branches
                            SET hotel_id = ?,
                                name = ?,
                                code = ?,
                                address = ?,
                                status = ?,
                                updated_at = NOW()
                            WHERE id = ? AND $branchScope AND $targetScope
                        ");

                        $stmt->execute([
                            $hotelId,
                            $name,
                            $code,
                            $address ?: null,
                            $status,
                            $branchId
                        ]);

                        $success = 'Şube bilgileri güncellendi.';
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO hotel_branches
                            (hotel_id, name, code, address, status, created_at, updated_at)
                            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                        ");

                        $stmt->execute([
                            $hotelId,
                            $name,
                            $code,
                            $address ?: null,
                            $status
                        ]);

                        $success = 'Yeni şube eklendi.';
                    }
                }
            } catch (PDOException $e) {
                if (($e->errorInfo[1] ?? null) == 1062) {
                    $errors[] = 'Bu otel için aynı şube kodu zaten kullanılıyor.';
                } else {
                    $errors[] = 'Şube kaydedilemedi. Veritabanı yapısını kontrol edin.';
                }
            }
        }
    }

    /* Aktif / pasif */
    if ($action === 'toggle') {
        $branchId = (int)($_POST['branch_id'] ?? 0);

        if ($branchId > 0) {
            try {
                $stmt = $pdo->prepare("
                    UPDATE hotel_branches
                    SET status = CASE
                        WHEN status = 'active' THEN 'inactive'
                        ELSE 'active'
                    END,
                    updated_at = NOW()
                    WHERE id = ? AND $branchScope
                ");

                $stmt->execute([$branchId]);

                if (!$stmt->rowCount() && !htv_is_superadmin()) htv_access_denied();
                $success = 'Şube durumu güncellendi.';
            } catch (Throwable $e) {
                $errors[] = 'Şube durumu değiştirilemedi.';
            }
        }
    }
}

/* Düzenlenecek şubeyi getir */
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM hotel_branches
        WHERE id = ? AND $branchScope
        LIMIT 1
    ");

    $stmt->execute([(int)$_GET['edit']]);
    $editing = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/* Şubeleri listele */
try {
    $branches = $pdo->query("
        SELECT
            b.*,
            h.name AS hotel_name
        FROM hotel_branches b
        INNER JOIN hotel_properties h
            ON h.id = b.hotel_id
        WHERE $listScope
        ORDER BY h.name ASC, b.name ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $branches = [];
    $errors[] = 'Şube listesi alınamadı.';
}

layout_start('Şube Yönetimi');
?>

<div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;margin-bottom:20px">
    <div>
        <h1 style="margin:0 0 6px">Şube Yönetimi</h1>
        <p style="margin:0;color:var(--muted,#777)">
            Hotel TV otellerine bağlı şubeleri yönetin.
        </p>
    </div>

    <a href="properties.php" class="btn btn-secondary">
        Otel Yönetimine Dön
    </a>
</div>

<?php if ($success): ?>
    <div class="alert alert-success" style="margin-bottom:15px;padding:12px">
        <?= e($success) ?>
    </div>
<?php endif; ?>

<?php foreach ($errors as $error): ?>
    <div class="alert alert-danger" style="margin-bottom:12px;padding:12px">
        <?= e($error) ?>
    </div>
<?php endforeach; ?>

<!-- Şube formu -->
<div class="card" style="padding:20px;margin-bottom:22px">

    <h2 style="margin-top:0">
        <?= $editing ? 'Şubeyi Düzenle' : 'Yeni Şube Ekle' ?>
    </h2>

    <?php if (!$hotels): ?>

        <p>Önce Otel Yönetimi bölümünden bir otel kaydetmelisiniz.</p>

        <a href="properties.php" class="btn btn-primary">
            Otel Ekle
        </a>

    <?php else: ?>

        <form method="post">

            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
            <input type="hidden" name="action" value="save">

            <input type="hidden" name="branch_id"
                   value="<?= (int)($editing['id'] ?? 0) ?>">

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px">

                <div>
                    <label>Otel</label>

                    <select name="hotel_id" required
                            class="form-control"
                            style="width:100%;padding:10px">

                        <option value="">Otel seçin</option>

                        <?php foreach ($hotels as $hotel): ?>

                            <option value="<?= (int)$hotel['id'] ?>"
                                <?= (int)($editing['hotel_id'] ?? 0) === (int)$hotel['id'] ? 'selected' : '' ?>>

                                <?= e($hotel['name']) ?>
                                (<?= e($hotel['code']) ?>)

                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <div>
                    <label>Şube Adı</label>

                    <input type="text"
                           name="name"
                           maxlength="150"
                           required
                           class="form-control"
                           placeholder="Örn. Merkez Otel"
                           value="<?= e((string)($editing['name'] ?? '')) ?>">
                </div>

                <div>
                    <label>Şube Kodu</label>

                    <input type="text"
                           name="code"
                           maxlength="40"
                           required
                           class="form-control"
                           placeholder="Örn. MERKEZ"
                           value="<?= e((string)($editing['code'] ?? '')) ?>">
                </div>

                <div>
                    <label>Durum</label>

                    <select name="status" class="form-control">
                        <option value="active"
                            <?= ($editing['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>
                            Aktif
                        </option>

                        <option value="inactive"
                            <?= ($editing['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                            Pasif
                        </option>
                    </select>
                </div>

                <div style="grid-column:1/-1">
                    <label>Adres</label>

                    <textarea name="address"
                              rows="2"
                              maxlength="500"
                              class="form-control"
                              placeholder="Şubenin açık adresi"><?= e((string)($editing['address'] ?? '')) ?></textarea>
                </div>

            </div>

            <div style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap">

                <button type="submit" class="btn btn-primary">
                    <?= $editing ? 'Değişiklikleri Kaydet' : 'Şube Ekle' ?>
                </button>

                <?php if ($editing): ?>
                    <a href="branches.php" class="btn btn-secondary">
                        Vazgeç
                    </a>
                <?php endif; ?>

            </div>

        </form>

    <?php endif; ?>

</div>

<!-- Şube listesi -->
<div class="card" style="padding:20px">

    <h2 style="margin-top:0">Kayıtlı Şubeler</h2>

    <?php if (!$branches): ?>

        <p>Henüz şube kaydı bulunmuyor.</p>

    <?php else: ?>

        <div style="overflow-x:auto">

            <table class="table" style="width:100%;border-collapse:collapse">

                <thead>
                    <tr>
                        <th style="text-align:left;padding:10px">Otel</th>
                        <th style="text-align:left;padding:10px">Şube</th>
                        <th style="text-align:left;padding:10px">Kod</th>
                        <th style="text-align:left;padding:10px">Adres</th>
                        <th style="text-align:left;padding:10px">Durum</th>
                        <th style="text-align:right;padding:10px">İşlem</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($branches as $branch): ?>

                    <tr>

                        <td style="padding:10px">
                            <?= e($branch['hotel_name']) ?>
                        </td>

                        <td style="padding:10px">
                            <?= e($branch['name']) ?>
                        </td>

                        <td style="padding:10px">
                            <?= e($branch['code']) ?>
                        </td>

                        <td style="padding:10px">
                            <?= e((string)($branch['address'] ?? '—')) ?>
                        </td>

                        <td style="padding:10px">
                            <?= $branch['status'] === 'active' ? 'Aktif' : 'Pasif' ?>
                        </td>

                        <td style="padding:10px;text-align:right;white-space:nowrap">

                            <a class="btn btn-sm btn-secondary"
                               href="branches.php?edit=<?= (int)$branch['id'] ?>">
                                Düzenle
                            </a>

                            <form method="post"
                                  style="display:inline-block"
                                  onsubmit="return confirm('Şube durumu değiştirilsin mi?')">

                                <input type="hidden" name="csrf"
                                       value="<?= e(csrf()) ?>">

                                <input type="hidden" name="action"
                                       value="toggle">

                                <input type="hidden" name="branch_id"
                                       value="<?= (int)$branch['id'] ?>">

                                <button type="submit" class="btn btn-sm btn-secondary">
                                    <?= $branch['status'] === 'active' ? 'Pasife Al' : 'Aktifleştir' ?>
                                </button>

                            </form>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</div>

<?php layout_end(); ?>
