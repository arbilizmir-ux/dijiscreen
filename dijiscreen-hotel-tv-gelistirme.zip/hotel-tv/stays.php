<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$propertyScope = htv_hotel_scope('id');
$branchScope = htv_hotel_scope('b.hotel_id');
$recordScope = htv_hotel_scope('hotel_id');
$listScope = htv_hotel_scope('s.hotel_id');
$guestScope = htv_hotel_scope('g.hotel_id');

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function htv_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function htv_date_value($value): string {
    if (!$value) return '';
    return date('Y-m-d\TH:i', strtotime($value));
}

$errors = [];

$statuses = [
    'reserved' => 'Rezervasyon',
    'checked_in' => 'Konakladı / Giriş yaptı',
    'checked_out' => 'Çıkış yaptı',
    'cancelled' => 'İptal edildi'
];

$successMessages = [
    'checked_in' => 'Misafir girişi başarıyla yapıldı. Televizyon ekranı güncellenecek.',
    'checked_out' => 'Misafir çıkışı başarıyla yapıldı. Televizyon ekranı bekleme moduna dönecek.',
    'saved' => 'Konaklama kaydı başarıyla kaydedildi.'
];

$success = $successMessages[$_GET['result'] ?? ''] ?? '';

$hotels = $pdo->query("
    SELECT id, name
    FROM hotel_properties
    WHERE status = 'active' AND $propertyScope
    ORDER BY name
")->fetchAll(PDO::FETCH_ASSOC);

$branches = $pdo->query("
    SELECT b.id, b.hotel_id, b.name
    FROM hotel_branches b
    INNER JOIN hotel_properties h ON h.id = b.hotel_id
    WHERE b.status = 'active' AND h.status = 'active' AND $branchScope
    ORDER BY b.name
")->fetchAll(PDO::FETCH_ASSOC);

$rooms = $pdo->query("
    SELECT r.id, r.branch_id, r.room_number, r.room_name, r.status
    FROM hotel_rooms r
    INNER JOIN hotel_branches b ON b.id = r.branch_id
    INNER JOIN hotel_properties h ON h.id = b.hotel_id
    WHERE b.status = 'active' AND h.status = 'active' AND $branchScope
    ORDER BY r.room_number
")->fetchAll(PDO::FETCH_ASSOC);

$guests = $pdo->query("
    SELECT g.id, g.hotel_id, g.first_name, g.last_name
    FROM hotel_guests g
    INNER JOIN hotel_properties h ON h.id = g.hotel_id
    WHERE h.status = 'active' AND $guestScope
    ORDER BY g.first_name, g.last_name
")->fetchAll(PDO::FETCH_ASSOC);

$editId = (int)($_GET['edit'] ?? 0);

$form = [
    'id' => 0,
    'hotel_id' => '',
    'branch_id' => '',
    'room_id' => '',
    'guest_id' => '',
    'reservation_ref' => '',
    'check_in_at' => date('Y-m-d\TH:i'),
    'check_out_at' => '',
    'welcome_message' => '',
    'status' => 'reserved'
];

if ($editId > 0) {
    $stmt = $pdo->prepare("
        SELECT s.*
        FROM hotel_stays s
        INNER JOIN hotel_rooms r ON r.id = s.room_id AND r.branch_id = s.branch_id
        WHERE s.id = ? AND $listScope
        LIMIT 1
    ");
    $stmt->execute([$editId]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($record) {
        $form = [
            'id' => (int)$record['id'],
            'hotel_id' => (int)$record['hotel_id'],
            'branch_id' => (int)$record['branch_id'],
            'room_id' => (int)$record['room_id'],
            'guest_id' => $record['guest_id'] ? (int)$record['guest_id'] : '',
            'reservation_ref' => $record['reservation_ref'] ?? '',
            'check_in_at' => htv_date_value($record['check_in_at']),
            'check_out_at' => htv_date_value($record['check_out_at']),
            'welcome_message' => $record['welcome_message'] ?? '',
            'status' => $record['status']
        ];
    } else {
        $errors[] = 'Düzenlenecek konaklama kaydı bulunamadı.';
        $editId = 0;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $action = $_POST['action'] ?? '';

    /*
     * HIZLI CHECK-IN
     */
    if ($action === 'check_in') {
        $id = (int)($_POST['stay_id'] ?? 0);

        if ($id <= 0) {
            $errors[] = 'Geçersiz konaklama kaydı.';
        } else {
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    SELECT *
                    FROM hotel_stays
                    WHERE id = ? AND $recordScope
                    FOR UPDATE
                ");
                $stmt->execute([$id]);
                $stay = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$stay) {
                    throw new RuntimeException('Konaklama kaydı bulunamadı.');
                }

                if ($stay['status'] !== 'reserved') {
                    throw new RuntimeException('Yalnızca rezervasyon durumundaki kayıtlar için giriş yapılabilir.');
                }

                // Başka aktif konaklama veya rezervasyon çakışması
                $stmt = $pdo->prepare("
                    SELECT COUNT(*)
                    FROM hotel_stays
                    WHERE room_id = ?
                      AND id != ?
                      AND status IN ('reserved', 'checked_in')
                      AND check_in_at < COALESCE(?, '9999-12-31 23:59:59')
                      AND COALESCE(check_out_at, '9999-12-31 23:59:59') > CURRENT_TIMESTAMP
                ");

                $stmt->execute([
                    $stay['room_id'],
                    $id,
                    $stay['check_out_at']
                ]);

                if ((int)$stmt->fetchColumn() > 0) {
                    throw new RuntimeException('Bu odada çakışan başka bir rezervasyon veya konaklama bulunduğu için giriş yapılamıyor.');
                }

                $stmt = $pdo->prepare("
                    UPDATE hotel_stays
                    SET status = 'checked_in',
                        check_in_at = CURRENT_TIMESTAMP,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ? AND $recordScope
                      AND status = 'reserved'
                ");
                $stmt->execute([$id]);

                $pdo->commit();

                header('Location: stays.php?result=checked_in');
                exit;

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = $e->getMessage();
            }
        }
    }

    /*
     * HIZLI CHECK-OUT
     */
    elseif ($action === 'check_out') {
        $id = (int)($_POST['stay_id'] ?? 0);

        if ($id <= 0) {
            $errors[] = 'Geçersiz konaklama kaydı.';
        } else {
            try {
                $stmt = $pdo->prepare("
                    UPDATE hotel_stays
                    SET status = 'checked_out',
                        check_out_at = CURRENT_TIMESTAMP,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ? AND $recordScope
                      AND status = 'checked_in'
                ");
                $stmt->execute([$id]);

                if ($stmt->rowCount() > 0) {
                    header('Location: stays.php?result=checked_out');
                    exit;
                }

                $errors[] = 'Çıkış işlemi yapılamadı. Kayıt bulunamadı veya misafir zaten çıkış yapmış.';
            } catch (Throwable $e) {
                $errors[] = 'Çıkış sırasında hata oluştu: ' . $e->getMessage();
            }
        }
    }

    /*
     * NORMAL KAYIT EKLEME / DÜZENLEME
     */
    elseif ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $hotelId = (int)($_POST['hotel_id'] ?? 0);
        htv_require_hotel($pdo, $hotelId);
        $branchId = (int)($_POST['branch_id'] ?? 0);
        $roomId = (int)($_POST['room_id'] ?? 0);
        $guestId = (int)($_POST['guest_id'] ?? 0);

        $reservationRef = trim($_POST['reservation_ref'] ?? '');
        $checkInRaw = trim($_POST['check_in_at'] ?? '');
        $checkOutRaw = trim($_POST['check_out_at'] ?? '');
        $welcomeMessage = trim($_POST['welcome_message'] ?? '');
        $status = $_POST['status'] ?? 'reserved';

        $checkIn = null;
        $checkOut = null;

        $checkInDate = DateTime::createFromFormat('Y-m-d\TH:i', $checkInRaw);

        if ($checkInDate) {
            $checkIn = $checkInDate->format('Y-m-d H:i:s');
        }

        if ($checkOutRaw !== '') {
            $checkOutDate = DateTime::createFromFormat('Y-m-d\TH:i', $checkOutRaw);

            if ($checkOutDate) {
                $checkOut = $checkOutDate->format('Y-m-d H:i:s');
            }
        }

        if ($hotelId <= 0) {
            $errors[] = 'Otel seçmelisiniz.';
        }

        if ($branchId <= 0) {
            $errors[] = 'Şube seçmelisiniz.';
        }

        if ($roomId <= 0) {
            $errors[] = 'Oda seçmelisiniz.';
        }

        if (!$checkIn) {
            $errors[] = 'Geçerli bir giriş tarihi girin.';
        }

        if ($checkOut && $checkIn && $checkOut <= $checkIn) {
            $errors[] = 'Çıkış tarihi giriş tarihinden sonra olmalıdır.';
        }

        if (!array_key_exists($status, $statuses)) {
            $errors[] = 'Geçersiz konaklama durumu.';
        }

        if (mb_strlen($reservationRef) > 100) {
            $errors[] = 'Rezervasyon numarası en fazla 100 karakter olabilir.';
        }

        if (mb_strlen($welcomeMessage) > 500) {
            $errors[] = 'Karşılama mesajı en fazla 500 karakter olabilir.';
        }

        if (!$errors) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM hotel_branches
                WHERE id = ? AND hotel_id = ? AND status = 'active'
            ");
            $stmt->execute([$branchId, $hotelId]);

            if (!(int)$stmt->fetchColumn()) {
                $errors[] = 'Seçilen şube bu otele ait değil veya aktif değil.';
            }
        }

        if (!$errors) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM hotel_rooms
                WHERE id = ? AND branch_id = ?
                AND status = 'active'
            ");
            $stmt->execute([$roomId, $branchId]);

            if (!(int)$stmt->fetchColumn()) {
                $errors[] = 'Seçilen oda bu şubeye ait değil veya aktif değil.';
            }
        }

        if (!$errors && $guestId > 0) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM hotel_guests
                WHERE id = ? AND hotel_id = ?
            ");
            $stmt->execute([$guestId, $hotelId]);

            if (!(int)$stmt->fetchColumn()) {
                $errors[] = 'Seçilen misafir bu otele kayıtlı değil.';
            }
        }

        // Tarih çakışması kontrolü
        if (!$errors && in_array($status, ['reserved', 'checked_in'], true)) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM hotel_stays
                WHERE room_id = ?
                  AND status IN ('reserved', 'checked_in')
                  AND id != ?
                  AND check_in_at < COALESCE(?, '9999-12-31 23:59:59')
                  AND COALESCE(check_out_at, '9999-12-31 23:59:59') > ?
            ");

            $stmt->execute([
                $roomId,
                $id,
                $checkOut,
                $checkIn
            ]);

            if ((int)$stmt->fetchColumn() > 0) {
                $errors[] = 'Bu odada seçtiğiniz tarihlerle çakışan başka bir rezervasyon veya konaklama var.';
            }
        }

        if (!$errors) {
            try {
                if ($id > 0) {
                    $stmt = $pdo->prepare("
                        UPDATE hotel_stays
                        SET hotel_id = ?,
                            branch_id = ?,
                            room_id = ?,
                            guest_id = ?,
                            reservation_ref = ?,
                            check_in_at = ?,
                            check_out_at = ?,
                            welcome_message = ?,
                            status = ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ? AND $recordScope
                    ");

                    $stmt->execute([
                        $hotelId,
                        $branchId,
                        $roomId,
                        $guestId ?: null,
                        $reservationRef ?: null,
                        $checkIn,
                        $checkOut,
                        $welcomeMessage ?: null,
                        $status,
                        $id
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO hotel_stays
                        (
                            hotel_id,
                            branch_id,
                            room_id,
                            guest_id,
                            reservation_ref,
                            check_in_at,
                            check_out_at,
                            welcome_message,
                            status,
                            source
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'manual')
                    ");

                    $stmt->execute([
                        $hotelId,
                        $branchId,
                        $roomId,
                        $guestId ?: null,
                        $reservationRef ?: null,
                        $checkIn,
                        $checkOut,
                        $welcomeMessage ?: null,
                        $status
                    ]);
                }

                header('Location: stays.php?result=saved');
                exit;

            } catch (Throwable $e) {
                $errors[] = 'Kayıt sırasında hata oluştu: ' . $e->getMessage();
            }
        }

        if ($errors) {
            $form = [
                'id' => $id,
                'hotel_id' => $hotelId,
                'branch_id' => $branchId,
                'room_id' => $roomId,
                'guest_id' => $guestId,
                'reservation_ref' => $reservationRef,
                'check_in_at' => $checkInRaw,
                'check_out_at' => $checkOutRaw,
                'welcome_message' => $welcomeMessage,
                'status' => $status
            ];
        }
    }
}

// Filtreler
$filterHotel = (int)($_GET['hotel_id'] ?? 0);
$filterStatus = $_GET['status'] ?? '';

$sql = "
    SELECT
        s.*,
        h.name AS hotel_name,
        b.name AS branch_name,
        r.room_number,
        r.room_name,
        g.first_name,
        g.last_name
    FROM hotel_stays s
    INNER JOIN hotel_properties h ON h.id = s.hotel_id
    INNER JOIN hotel_branches b ON b.id = s.branch_id AND b.hotel_id = s.hotel_id
    INNER JOIN hotel_rooms r ON r.id = s.room_id AND r.branch_id = s.branch_id
    LEFT JOIN hotel_guests g ON g.id = s.guest_id AND g.hotel_id = s.hotel_id
    WHERE $listScope
";

$params = [];

if ($filterHotel > 0) {
    $sql .= " AND s.hotel_id = ?";
    $params[] = $filterHotel;
}

if (array_key_exists($filterStatus, $statuses)) {
    $sql .= " AND s.status = ?";
    $params[] = $filterStatus;
}

$sql .= " ORDER BY s.check_in_at DESC, s.id DESC LIMIT 300";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$stays = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php layout_start('Hotel TV - Konaklama Yönetimi'); ?>

<style>
*{box-sizing:border-box}
.container{max-width:1250px;margin:30px auto;padding:0 18px}
.header{display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;margin-bottom:22px}
h1{font-size:25px;margin:0 0 7px}
.subtitle{color:#697586;font-size:14px}
.panel{background:#fff;border:1px solid #e4e8ef;border-radius:12px;padding:22px;margin-bottom:20px}
.panel h2{font-size:19px;margin:0 0 18px}
.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}
.field{display:flex;flex-direction:column;gap:7px}
.field.full{grid-column:1/-1}
label{font-size:13px;font-weight:600;color:#394456}
input,select,textarea{width:100%;padding:11px 12px;border:1px solid #d6dce5;border-radius:7px;font-size:14px;background:#fff;color:#202938}
textarea{min-height:85px;resize:vertical}
.actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:18px}
.btn{display:inline-block;border:0;border-radius:7px;padding:11px 16px;background:#2563eb;color:#fff;text-decoration:none;font-size:14px;cursor:pointer}
.btn.gray{background:#64748b}
.btn.green{background:#15803d}
.btn.small{padding:7px 10px;font-size:12px}
.alert{padding:13px 15px;border-radius:8px;margin-bottom:15px;font-size:14px}
.alert.error{background:#fee2e2;color:#991b1b}
.alert.success{background:#dcfce7;color:#166534}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:850px}
th,td{text-align:left;padding:12px 10px;border-bottom:1px solid #edf0f4;font-size:13px;vertical-align:middle}
th{color:#596579;background:#f8fafc;font-weight:600}
.status{display:inline-block;padding:5px 9px;border-radius:20px;font-size:11px;font-weight:600;background:#e2e8f0;color:#334155}
.status.checked_in{background:#dcfce7;color:#166534}
.status.reserved{background:#dbeafe;color:#1d4ed8}
.status.checked_out{background:#e5e7eb;color:#374151}
.status.cancelled{background:#fee2e2;color:#991b1b}
.muted{color:#778195}
.row-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.row-actions form{margin:0}
@media(max-width:800px){.grid{grid-template-columns:1fr 1fr}}
@media(max-width:540px){.grid{grid-template-columns:1fr}.container{margin:18px auto}.panel{padding:16px}}
</style>

<div class="container">

<div class="header">
    <div>
        <h1>Konaklama Yönetimi</h1>
        <div class="subtitle">DijiScreen Hotel TV · Rezervasyon ve misafir giriş/çıkış işlemleri</div>
    </div>
    <a class="btn gray" href="guests.php">Misafir Yönetimi</a>
</div>

<?php foreach ($errors as $error): ?>
    <div class="alert error"><?= htv_e($error) ?></div>
<?php endforeach; ?>

<?php if ($success): ?>
    <div class="alert success"><?= htv_e($success) ?></div>
<?php endif; ?>

<div class="panel">
    <h2><?= $form['id'] ? 'Konaklama Kaydını Düzenle' : 'Yeni Konaklama Kaydı' ?></h2>

    <form method="post">
        <input type="hidden" name="csrf" value="<?= htv_e(csrf()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int)$form['id'] ?>">

        <div class="grid">

            <div class="field">
                <label>Otel</label>
                <select name="hotel_id" id="hotel_id" required>
                    <option value="">Otel seçin</option>
                    <?php foreach ($hotels as $hotel): ?>
                        <option value="<?= (int)$hotel['id'] ?>"
                            <?= (int)$form['hotel_id'] === (int)$hotel['id'] ? 'selected' : '' ?>>
                            <?= htv_e($hotel['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Şube</label>
                <select name="branch_id" id="branch_id" required>
                    <option value="">Şube seçin</option>
                    <?php foreach ($branches as $branch): ?>
                        <option value="<?= (int)$branch['id'] ?>"
                            data-hotel="<?= (int)$branch['hotel_id'] ?>"
                            <?= (int)$form['branch_id'] === (int)$branch['id'] ? 'selected' : '' ?>>
                            <?= htv_e($branch['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Oda</label>
                <select name="room_id" id="room_id" required>
                    <option value="">Oda seçin</option>
                    <?php foreach ($rooms as $room): ?>
                        <option value="<?= (int)$room['id'] ?>"
                            data-branch="<?= (int)$room['branch_id'] ?>"
                            <?= (int)$form['room_id'] === (int)$room['id'] ? 'selected' : '' ?>>
                            <?= htv_e($room['room_number']) ?>
                            <?= $room['room_name'] ? ' - ' . htv_e($room['room_name']) : '' ?>
                            <?= $room['status'] !== 'active' ? ' (Aktif değil)' : '' ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Misafir</label>
                <select name="guest_id" id="guest_id">
                    <option value="">Misafir seçin (isteğe bağlı)</option>
                    <?php foreach ($guests as $guest): ?>
                        <option value="<?= (int)$guest['id'] ?>"
                            data-hotel="<?= (int)$guest['hotel_id'] ?>"
                            <?= (int)$form['guest_id'] === (int)$guest['id'] ? 'selected' : '' ?>>
                            <?= htv_e($guest['first_name'] . ' ' . $guest['last_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Rezervasyon Numarası</label>
                <input type="text" name="reservation_ref" maxlength="100"
                    value="<?= htv_e($form['reservation_ref']) ?>"
                    placeholder="Örn. RSV-2026-001">
            </div>

            <div class="field">
                <label>Konaklama Durumu</label>
                <select name="status" required>
                    <?php foreach ($statuses as $key => $label): ?>
                        <option value="<?= htv_e($key) ?>"
                            <?= $form['status'] === $key ? 'selected' : '' ?>>
                            <?= htv_e($label) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Giriş Tarihi ve Saati</label>
                <input type="datetime-local" name="check_in_at" required
                    value="<?= htv_e($form['check_in_at']) ?>">
            </div>

            <div class="field">
                <label>Çıkış Tarihi ve Saati</label>
                <input type="datetime-local" name="check_out_at"
                    value="<?= htv_e($form['check_out_at']) ?>">
            </div>

            <div class="field full">
                <label>Misafire Özel Karşılama Mesajı</label>
                <textarea name="welcome_message" maxlength="500"
                    placeholder="Örn. Sayın misafirimiz, otelimize hoş geldiniz."><?= htv_e($form['welcome_message']) ?></textarea>
            </div>

        </div>

        <div class="actions">
            <button type="submit" class="btn">
                <?= $form['id'] ? 'Değişiklikleri Kaydet' : 'Konaklama Kaydı Oluştur' ?>
            </button>

            <?php if ($form['id']): ?>
                <a href="stays.php" class="btn gray">Vazgeç</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="panel">
    <h2>Kayıtlı Konaklamalar</h2>

    <form method="get" class="grid" style="margin-bottom:18px">
        <div class="field">
            <label>Otele Göre Filtrele</label>
            <select name="hotel_id">
                <option value="">Tüm oteller</option>
                <?php foreach ($hotels as $hotel): ?>
                    <option value="<?= (int)$hotel['id'] ?>"
                        <?= $filterHotel === (int)$hotel['id'] ? 'selected' : '' ?>>
                        <?= htv_e($hotel['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field">
            <label>Duruma Göre Filtrele</label>
            <select name="status">
                <option value="">Tüm durumlar</option>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= htv_e($key) ?>"
                        <?= $filterStatus === $key ? 'selected' : '' ?>>
                        <?= htv_e($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field" style="justify-content:end">
            <button class="btn green" type="submit">Filtrele</button>
        </div>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Misafir</th>
                    <th>Otel / Şube</th>
                    <th>Oda</th>
                    <th>Giriş</th>
                    <th>Çıkış</th>
                    <th>Durum</th>
                    <th>İşlem</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$stays): ?>
                <tr>
                    <td colspan="7" class="muted">Henüz konaklama kaydı bulunmuyor.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($stays as $stay): ?>
                    <tr>
                        <td>
                            <?= htv_e(trim(($stay['first_name'] ?? '') . ' ' . ($stay['last_name'] ?? '')) ?: 'Misafir belirtilmemiş') ?>
                            <?php if ($stay['reservation_ref']): ?>
                                <div class="muted"><?= htv_e($stay['reservation_ref']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= htv_e($stay['hotel_name']) ?>
                            <div class="muted"><?= htv_e($stay['branch_name']) ?></div>
                        </td>
                        <td>
                            <?= htv_e($stay['room_number']) ?>
                            <?php if ($stay['room_name']): ?>
                                <div class="muted"><?= htv_e($stay['room_name']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td><?= htv_e(date('d.m.Y H:i', strtotime($stay['check_in_at']))) ?></td>
                        <td>
                            <?= $stay['check_out_at']
                                ? htv_e(date('d.m.Y H:i', strtotime($stay['check_out_at'])))
                                : '<span class="muted">Belirtilmedi</span>' ?>
                        </td>
                        <td>
                            <span class="status <?= htv_e($stay['status']) ?>">
                                <?= htv_e($statuses[$stay['status']] ?? $stay['status']) ?>
                            </span>
                        </td>
                        <td>
                            <div class="row-actions">

                                <a class="btn small" href="stays.php?edit=<?= (int)$stay['id'] ?>">
                                    Düzenle
                                </a>

                                <?php if ($stay['status'] === 'reserved'): ?>
                                    <form method="post"
                                          onsubmit="return confirm('Bu misafirin giriş işlemini yapmak istiyor musunuz?');">
                                        <input type="hidden" name="csrf" value="<?= htv_e(csrf()) ?>">
                                        <input type="hidden" name="action" value="check_in">
                                        <input type="hidden" name="stay_id" value="<?= (int)$stay['id'] ?>">

                                        <button type="submit" class="btn small green">
                                            Check-in Yap
                                        </button>
                                    </form>

                                <?php elseif ($stay['status'] === 'checked_in'): ?>
                                    <form method="post"
                                          onsubmit="return confirm('Misafirin çıkışını yapmak istiyor musunuz?');">
                                        <input type="hidden" name="csrf" value="<?= htv_e(csrf()) ?>">
                                        <input type="hidden" name="action" value="check_out">
                                        <input type="hidden" name="stay_id" value="<?= (int)$stay['id'] ?>">

                                        <button type="submit" class="btn small gray">
                                            Check-out Yap
                                        </button>
                                    </form>
                                <?php endif; ?>

                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p class="muted" style="font-size:12px;margin-top:12px">
        Güvenlik amacıyla bu listede en fazla 300 kayıt gösterilir. Konaklama kayıtları bu sayfadan silinmez.
    </p>
</div>

</div>

<script>
(function () {
    const hotel = document.getElementById('hotel_id');
    const branch = document.getElementById('branch_id');
    const room = document.getElementById('room_id');
    const guest = document.getElementById('guest_id');

    function filterSelect(select, attribute, value) {
        Array.from(select.options).forEach(function (option, index) {
            if (index === 0) return;

            const match = value !== '' && option.dataset[attribute] === value;
            option.hidden = !match;
            option.disabled = !match;
        });

        if (select.selectedOptions.length && select.selectedOptions[0].disabled) {
            select.value = '';
        }
    }

    function updateBranches() {
        filterSelect(branch, 'hotel', hotel.value);
        updateRooms();
        updateGuests();
    }

    function updateRooms() {
        filterSelect(room, 'branch', branch.value);
    }

    function updateGuests() {
        filterSelect(guest, 'hotel', hotel.value);
    }

    hotel.addEventListener('change', updateBranches);
    branch.addEventListener('change', updateRooms);

    updateBranches();
})();
</script>

<?php layout_end(); ?>
