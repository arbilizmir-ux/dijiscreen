<?php
declare(strict_types=1);
// Bu dosya tek başına çağrılmaz; bootstrap gerektiren sayfalar tarafından yüklenir.
function htvf_e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function htvf_airports(): array { return [
 'Adana'=>'COV','Adıyaman'=>'ADF','Ağrı'=>'AJI','Amasya'=>'MZH','Ankara'=>'ESB','Antalya'=>'AYT,GZP','Balıkesir'=>'EDO,BZI','Batman'=>'BAL','Bingöl'=>'BGG','Bursa'=>'YEI','Çanakkale'=>'CKZ','Denizli'=>'DNZ','Diyarbakır'=>'DIY','Elazığ'=>'EZS','Erzincan'=>'ERC','Erzurum'=>'ERZ','Eskişehir'=>'AOE','Gaziantep'=>'GZT','Hatay'=>'HTY','Iğdır'=>'IGD','Isparta'=>'ISE','İstanbul'=>'IST,SAW','İzmir'=>'ADB','Kahramanmaraş'=>'KCM','Kars'=>'KSY','Kastamonu'=>'KFS','Kayseri'=>'ASR','Kocaeli'=>'KCO','Konya'=>'KYA','Kütahya'=>'KZR','Malatya'=>'MLX','Mardin'=>'MQM','Muğla'=>'BJV,DLM','Muş'=>'MSR','Nevşehir'=>'NAV','Ordu'=>'OGU','Rize'=>'RZV','Samsun'=>'SZF','Siirt'=>'SXZ','Sinop'=>'NOP','Sivas'=>'VAS','Şanlıurfa'=>'GNY','Şırnak'=>'NKT','Tekirdağ'=>'TEQ','Tokat'=>'TJK','Trabzon'=>'TZX','Uşak'=>'USQ','Van'=>'VAN','Zonguldak'=>'ONQ'
]; }
function htvf_codes(string $value): array {
 $codes=array_values(array_unique(array_filter(array_map('trim',explode(',',strtoupper($value))),static fn($v)=>preg_match('/^[A-Z]{3}$/',$v))));
 return array_slice($codes,0,8);
}
function htvf_settings(PDO $pdo,int $hotelId): ?array {
 $q=$pdo->prepare('SELECT * FROM hotel_flight_settings WHERE hotel_id=?'); $q->execute([$hotelId]); $row=$q->fetch(PDO::FETCH_ASSOC); return $row ?: null;
}

function htvf_board(PDO $pdo, int $hotelId): array
{
    $q = $pdo->prepare('SELECT city, airport_codes, direction, enabled FROM hotel_flight_settings WHERE hotel_id=?');
    $q->execute([$hotelId]);
    $settings = $q->fetch(PDO::FETCH_ASSOC);
    $codes = htvf_codes((string)($settings['airport_codes'] ?? ''));
    if (!$settings || !(int)$settings['enabled'] || !$codes) {
        return [];
    }

    $airports = implode(',', array_fill(0, count($codes), '?'));
    $query = $pdo->prepare(
        "SELECT direction, airport_code, flight_number, destination, scheduled_at,
                estimated_at, flight_status,
                TIMESTAMPDIFF(SECOND, fetched_at, NOW()) AS age_seconds
         FROM hotel_flight_cache
         WHERE hotel_id=? AND direction=? AND airport_code IN ($airports)
           AND COALESCE(estimated_at, scheduled_at) BETWEEN NOW() - INTERVAL 3 HOUR AND NOW() + INTERVAL 36 HOUR
         ORDER BY COALESCE(estimated_at, scheduled_at), flight_number, airport_code LIMIT 100"
    );
    $directions = $settings['direction'] === 'both' ? ['departures','arrivals'] : [$settings['direction']];
    $board = [];
    foreach ($directions as $direction) {
        $query->execute(array_merge([$hotelId, $direction], $codes));
        $board[$direction] = $query->fetchAll(PDO::FETCH_ASSOC);
    }
    return $board;
}
