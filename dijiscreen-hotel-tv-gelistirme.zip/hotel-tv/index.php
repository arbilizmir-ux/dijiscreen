<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('id');
$branchScope = htv_hotel_scope('hotel_id');
$childScope = htv_branch_scope('branch_id');
$stayScope = htv_hotel_scope('s.hotel_id');
$deviceScope = htv_hotel_scope('b.hotel_id');

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function htv_index_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function htv_index_count(PDO $pdo, string $sql): int {
    return (int)$pdo->query($sql)->fetchColumn();
}

// Genel istatistikler
$stats = [
    'hotels' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_properties WHERE status = 'active' AND $hotelScope"),
    'branches' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_branches WHERE status = 'active' AND $branchScope"),
    'floors' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_floors WHERE $childScope"),
    'rooms' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_rooms WHERE status = 'active' AND $childScope"),
    'devices' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_devices WHERE status = 'active' AND $childScope"),
    'pending_devices' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_devices WHERE status = 'pending' AND $childScope"),
    'guests' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_guests WHERE $branchScope"),
    'stays' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_stays WHERE status = 'checked_in' AND $branchScope"),
    'reservations' => htv_index_count($pdo, "SELECT COUNT(*) FROM hotel_stays WHERE status = 'reserved' AND $branchScope"),
];

// Son konaklama kayıtları
$stmt = $pdo->query("
    SELECT
        s.id, s.check_in_at, s.check_out_at, s.status, s.reservation_ref,
        h.name AS hotel_name,
        b.name AS branch_name,
        r.room_number,
        g.first_name,
        g.last_name
    FROM hotel_stays s
    INNER JOIN hotel_properties h ON h.id = s.hotel_id
    INNER JOIN hotel_branches b ON b.id = s.branch_id AND b.hotel_id = s.hotel_id
    INNER JOIN hotel_rooms r ON r.id = s.room_id AND r.branch_id = s.branch_id
    LEFT JOIN hotel_guests g ON g.id = s.guest_id AND g.hotel_id = s.hotel_id
    WHERE $stayScope
    ORDER BY s.created_at DESC, s.id DESC
    LIMIT 8
");
$recentStays = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Son eklenen cihazlar
$stmt = $pdo->query("
    SELECT
        d.id, d.device_name, d.device_code, d.platform,
        d.status, d.last_seen_at,
        b.name AS branch_name,
        r.room_number
    FROM hotel_devices d
    LEFT JOIN hotel_branches b ON b.id = d.branch_id
    LEFT JOIN hotel_rooms r ON r.id = d.room_id AND r.branch_id = d.branch_id
    WHERE $deviceScope
    ORDER BY d.id DESC
    LIMIT 6
");
$recentDevices = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stayLabels = [
    'reserved' => 'Rezervasyon',
    'checked_in' => 'Konaklıyor',
    'checked_out' => 'Çıkış yaptı',
    'cancelled' => 'İptal'
];

$deviceLabels = [
    'pending' => 'Bekliyor',
    'active' => 'Aktif',
    'disabled' => 'Devre dışı',
    'blocked' => 'Engellendi'
];

$platformLabels = [
    'android' => 'Android TV',
    'samsung_tizen' => 'Samsung Tizen',
    'lg_webos' => 'LG webOS',
    'other' => 'Diğer'
];

$menu = [
    [
        'title' => 'Otel Yönetimi',
        'description' => 'Otel kayıtlarını oluşturun ve yönetin.',
        'url' => 'properties.php',
        'icon' => '🏨'
    ],
    [
        'title' => 'Şube Yönetimi',
        'description' => 'Otele bağlı şubeleri yönetin.',
        'url' => 'branches.php',
        'icon' => '🏢'
    ],
    [
        'title' => 'Kat Yönetimi',
        'description' => 'Şubelere kat ekleyin ve düzenleyin.',
        'url' => 'floors.php',
        'icon' => '🛗'
    ],
    [
        'title' => 'Oda Yönetimi',
        'description' => 'Oda numarası, kapasite ve durumlarını yönetin.',
        'url' => 'rooms.php',
        'icon' => '🚪'
    ],
    [
        'title' => 'Cihaz Yönetimi',
        'description' => 'Otel televizyonlarını ve cihaz kayıtlarını yönetin.',
        'url' => 'devices.php',
        'icon' => '📺'
    ],
    [
        'title' => 'Misafir Yönetimi',
        'description' => 'Misafir bilgilerini kaydedin ve düzenleyin.',
        'url' => 'guests.php',
        'icon' => '👤'
    ],
    [
        'title' => 'Konaklama Yönetimi',
        'description' => 'Rezervasyon, giriş ve çıkış işlemlerini yönetin.',
        'url' => 'stays.php',
        'icon' => '🛎️'
    ]
];

$menu[] = ['title'=>'TV Önizlemesi', 'description'=>'Misafir ekranını tarayıcıda açın.', 'url'=>'tv_preview.php', 'icon'=>'📺'];
$menu[] = ['title'=>'TV Modülleri', 'description'=>'Ekrandaki içerikleri yönetin.', 'url'=>'modules.php', 'icon'=>'▦'];
$menu[] = ['title'=>'PMS', 'description'=>'Otel yönetim sistemi bağlantılarını inceleyin.', 'url'=>'pms.php', 'icon'=>'↔'];
$menu[] = ['title'=>'Uçuş Ayarları', 'description'=>'Havalimanlarını ve uçuş yönlerini ayarlayın.', 'url'=>'flights_admin.php', 'icon'=>'✈'];
if (htv_is_superadmin()) {
    $menu[] = ['title'=>'Otel Yetkileri', 'description'=>'Kullanıcılara otel atayın.', 'url'=>'hotel_assignments.php', 'icon'=>'⚿'];
}

// Ortak DijiScreen tasarımı
layout_start('Hotel TV Yönetimi');
?>

<style>
.htv-intro{
    color:var(--muted);
    font-size:13px;
    margin-top:-13px;
    margin-bottom:22px;
}
.htv-stats{
    display:grid;
    grid-template-columns:repeat(5,minmax(0,1fr));
    gap:15px;
}
.htv-stat{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:12px;
    padding:19px;
    box-shadow:var(--shadow);
    min-width:0;
}
.htv-stat-label{
    font-size:13px;
    color:var(--muted);
    margin-bottom:12px;
}
.htv-stat-number{
    font-size:29px;
    font-weight:700;
    color:var(--text);
}
.htv-stat-note{
    color:var(--muted);
    font-size:11px;
    margin-top:7px;
}
.htv-menu-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:15px;
}
.htv-menu-card{
    display:block;
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:12px;
    padding:20px;
    color:var(--text);
    text-decoration:none;
    transition:.15s;
    box-shadow:var(--shadow);
}
.htv-menu-card:hover{
    border-color:#93b4f5;
    transform:translateY(-2px);
}
.htv-menu-icon{
    font-size:27px;
    margin-bottom:13px;
}
.htv-menu-title{
    font-size:16px;
    font-weight:700;
    margin-bottom:8px;
}
.htv-menu-description{
    color:var(--muted);
    font-size:12px;
    line-height:1.6;
}
.htv-columns{
    display:grid;
    grid-template-columns:1.4fr 1fr;
    gap:18px;
}
.htv-panel{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:12px;
    padding:20px;
    margin-bottom:20px;
    min-width:0;
    box-shadow:var(--shadow);
}
.htv-panel h2{
    font-size:17px;
    margin:0 0 17px;
}
.htv-table-wrap{overflow-x:auto;width:100%}
.htv-panel table{min-width:520px}
.htv-panel th,.htv-panel td{
    padding:11px 9px;
    font-size:12px;
    vertical-align:middle;
}
.htv-muted{color:var(--muted)}
.htv-pill{
    display:inline-block;
    padding:5px 8px;
    border-radius:20px;
    background:#e2e8f0;
    color:#334155;
    font-size:11px;
    white-space:nowrap;
}
.htv-pill.active,.htv-pill.checked_in{
    background:#dcfce7;
    color:#166534;
}
.htv-pill.reserved,.htv-pill.pending{
    background:#dbeafe;
    color:#1d4ed8;
}
.htv-pill.cancelled,.htv-pill.blocked{
    background:#fee2e2;
    color:#991b1b;
}
.htv-pill.disabled,.htv-pill.checked_out{
    background:#e5e7eb;
    color:#374151;
}
html[data-theme="dark"] .htv-pill{
    background:#29384f;
    color:#e5edf8;
}
html[data-theme="dark"] .htv-pill.active,
html[data-theme="dark"] .htv-pill.checked_in{
    background:#123326;
    color:#bbf7d0;
}
html[data-theme="dark"] .htv-pill.reserved,
html[data-theme="dark"] .htv-pill.pending{
    background:#172d4b;
    color:#bfdbfe;
}
html[data-theme="dark"] .htv-pill.cancelled,
html[data-theme="dark"] .htv-pill.blocked{
    background:#3a2028;
    color:#fecaca;
}
.htv-quick-links{
    display:flex;
    gap:14px;
    flex-wrap:wrap;
    margin-top:15px;
}
.htv-quick-links a{
    color:var(--primary);
    text-decoration:none;
    font-size:13px;
}
.htv-footer{
    text-align:center;
    color:var(--muted);
    font-size:11px;
    padding:20px;
}
@media(max-width:1100px){
    .htv-stats{grid-template-columns:repeat(3,minmax(0,1fr))}
    .htv-menu-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
}
@media(max-width:750px){
    .htv-columns{grid-template-columns:1fr}
    .htv-menu-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:500px){
    .htv-stats{grid-template-columns:repeat(2,minmax(0,1fr))}
    .htv-menu-grid{grid-template-columns:1fr}
    .htv-stat{padding:15px}
    .htv-stat-number{font-size:25px}
}
</style>

<p class="htv-intro">
    Otel televizyonları, odalar, misafirler ve konaklama yönetimi
</p>

<h2 style="font-size:19px;margin:25px 0 15px">Genel Durum</h2>

<div class="htv-stats">
    <div class="htv-stat">
        <div class="htv-stat-label">Aktif Oteller</div>
        <div class="htv-stat-number"><?= $stats['hotels'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Aktif Şubeler</div>
        <div class="htv-stat-number"><?= $stats['branches'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Katlar</div>
        <div class="htv-stat-number"><?= $stats['floors'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Aktif Odalar</div>
        <div class="htv-stat-number"><?= $stats['rooms'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Aktif TV Cihazları</div>
        <div class="htv-stat-number"><?= $stats['devices'] ?></div>
        <div class="htv-stat-note"><?= $stats['pending_devices'] ?> cihaz eşleştirme bekliyor</div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Kayıtlı Misafirler</div>
        <div class="htv-stat-number"><?= $stats['guests'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Şu Anda Konaklayan</div>
        <div class="htv-stat-number"><?= $stats['stays'] ?></div>
    </div>

    <div class="htv-stat">
        <div class="htv-stat-label">Bekleyen Rezervasyonlar</div>
        <div class="htv-stat-number"><?= $stats['reservations'] ?></div>
    </div>
</div>

<h2 style="font-size:19px;margin:30px 0 15px">Yönetim Modülleri</h2>

<div class="htv-menu-grid">
    <?php foreach ($menu as $item): ?>
        <a class="htv-menu-card" href="<?= htv_index_e($item['url']) ?>">
            <div class="htv-menu-icon"><?= $item['icon'] ?></div>
            <div class="htv-menu-title"><?= htv_index_e($item['title']) ?></div>
            <div class="htv-menu-description">
                <?= htv_index_e($item['description']) ?>
            </div>
        </a>
    <?php endforeach; ?>
</div>

<h2 style="font-size:19px;margin:30px 0 15px">Son İşlemler</h2>

<div class="htv-columns">

    <div class="htv-panel">
        <h2>Son Konaklama Kayıtları</h2>

        <div class="htv-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Misafir</th>
                        <th>Oda</th>
                        <th>Giriş</th>
                        <th>Durum</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$recentStays): ?>
                    <tr>
                        <td colspan="4" class="htv-muted">Henüz konaklama kaydı yok.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentStays as $stay): ?>
                        <tr>
                            <td>
                                <?= htv_index_e(
                                    trim(($stay['first_name'] ?? '') . ' ' . ($stay['last_name'] ?? ''))
                                    ?: 'Misafir belirtilmemiş'
                                ) ?>
                                <div class="htv-muted"><?= htv_index_e($stay['hotel_name']) ?></div>
                            </td>
                            <td>
                                <?= htv_index_e($stay['room_number']) ?>
                                <div class="htv-muted"><?= htv_index_e($stay['branch_name']) ?></div>
                            </td>
                            <td>
                                <?= htv_index_e(date('d.m.Y H:i', strtotime($stay['check_in_at']))) ?>
                            </td>
                            <td>
                                <span class="htv-pill <?= htv_index_e($stay['status']) ?>">
                                    <?= htv_index_e($stayLabels[$stay['status']] ?? $stay['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="htv-quick-links">
            <a href="stays.php">Tüm konaklamaları yönet →</a>
            <a href="guests.php">Misafirleri yönet →</a>
        </div>
    </div>

    <div class="htv-panel">
        <h2>Son Eklenen TV Cihazları</h2>

        <div class="htv-table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Cihaz</th>
                        <th>Platform</th>
                        <th>Durum</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$recentDevices): ?>
                    <tr>
                        <td colspan="3" class="htv-muted">Henüz cihaz kaydı yok.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentDevices as $device): ?>
                        <tr>
                            <td>
                                <?= htv_index_e($device['device_name'] ?: $device['device_code']) ?>
                                <div class="htv-muted">
                                    <?= htv_index_e($device['room_number'] ?: 'Oda atanmamış') ?>
                                </div>
                            </td>
                            <td>
                                <?= htv_index_e($platformLabels[$device['platform']] ?? $device['platform']) ?>
                            </td>
                            <td>
                                <span class="htv-pill <?= htv_index_e($device['status']) ?>">
                                    <?= htv_index_e($deviceLabels[$device['status']] ?? $device['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="htv-quick-links">
            <a href="devices.php">Tüm cihazları yönet →</a>
        </div>
    </div>

</div>

<div class="htv-footer">
    DijiScreen Hotel TV · Merkezi Otel Televizyon Yönetim Sistemi
</div>

<?php
layout_end();
