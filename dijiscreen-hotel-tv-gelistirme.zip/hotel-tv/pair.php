<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('b.hotel_id');

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function hotel_pair_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function hotel_pair_status($status): array {
    $statuses = [
        'pending'  => ['Eşleştirme Bekliyor', 'pending'],
        'active'   => ['Aktif', 'active'],
        'disabled' => ['Devre Dışı', 'disabled'],
        'blocked'  => ['Engellendi', 'blocked'],
    ];

    return $statuses[$status] ?? ['Bilinmiyor', 'unknown'];
}

$devices = $pdo->query("
    SELECT
        d.id,
        d.device_code,
        d.device_name,
        d.platform,
        d.status,
        d.app_version,
        d.last_seen_at,
        b.name AS branch_name,
        b.code AS branch_code,
        h.name AS hotel_name,
        r.room_number,
        r.room_name
    FROM hotel_devices d
    LEFT JOIN hotel_branches b ON b.id = d.branch_id
    LEFT JOIN hotel_properties h ON h.id = b.hotel_id
    LEFT JOIN hotel_rooms r ON r.id = d.room_id AND r.branch_id = d.branch_id
    WHERE $hotelScope
    ORDER BY
        CASE d.status
            WHEN 'pending' THEN 1
            WHEN 'active' THEN 2
            WHEN 'disabled' THEN 3
            WHEN 'blocked' THEN 4
            ELSE 5
        END,
        d.id DESC
")->fetchAll(PDO::FETCH_ASSOC);

$counts = [
    'total' => count($devices),
    'pending' => 0,
    'active' => 0,
    'disabled' => 0,
    'blocked' => 0,
];

foreach ($devices as $device) {
    $status = $device['status'] ?? '';
    if (isset($counts[$status])) {
        $counts[$status]++;
    }
}

$platformNames = [
    'android' => 'Android TV',
    'samsung_tizen' => 'Samsung Tizen',
    'lg_webos' => 'LG webOS',
    'other' => 'Diğer',
];

?>
<?php layout_start('Hotel TV - Cihaz Eşleştirme'); ?>
"
      dir="<?= hotel_pair_h(app_language_direction()) ?>">
<style>
* { box-sizing: border-box; }
.container {
    max-width: 1250px;
    margin: 0 auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
    margin-bottom: 22px;
}

h1 {
    margin: 0 0 7px;
    font-size: 25px;
}

.subtitle {
    color: #697586;
    font-size: 14px;
}

.actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.btn {
    display: inline-block;
    padding: 10px 15px;
    border-radius: 8px;
    background: #253b70;
    color: white;
    text-decoration: none;
    font-size: 13px;
    border: 0;
}

.btn.secondary {
    background: #e5eaf2;
    color: #253b70;
}

.stats {
    display: grid;
    grid-template-columns: repeat(5, minmax(130px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}

.stat {
    background: white;
    border-radius: 12px;
    padding: 17px;
    border: 1px solid #e5e9f0;
}

.stat-label {
    font-size: 13px;
    color: #697586;
    margin-bottom: 8px;
}

.stat-number {
    font-size: 27px;
    font-weight: bold;
}

.panel {
    background: white;
    border: 1px solid #e5e9f0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 18px;
}

.panel h2 {
    font-size: 17px;
    margin: 0 0 15px;
}

.notice {
    padding: 13px 15px;
    border-radius: 8px;
    background: #edf4ff;
    color: #254778;
    font-size: 13px;
    line-height: 1.6;
    margin-bottom: 18px;
}

.search {
    width: 100%;
    max-width: 350px;
    padding: 10px 12px;
    border: 1px solid #d8dee8;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 14px;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 850px;
}

th, td {
    padding: 13px 11px;
    text-align: left;
    border-bottom: 1px solid #edf0f4;
    font-size: 13px;
    vertical-align: middle;
}

th {
    color: #657184;
    background: #f8f9fb;
    font-weight: 600;
}

.code {
    display: inline-block;
    padding: 7px 9px;
    border-radius: 6px;
    background: #f0f2f6;
    color: #263b66;
    font-family: Consolas, monospace;
    font-weight: bold;
    letter-spacing: .4px;
    white-space: nowrap;
}

.status {
    display: inline-block;
    padding: 6px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
    white-space: nowrap;
}

.status.pending {
    background: #fff3d8;
    color: #986500;
}

.status.active {
    background: #e0f5e9;
    color: #167342;
}

.status.disabled {
    background: #edf0f4;
    color: #667085;
}

.status.blocked,
.status.unknown {
    background: #fde8e8;
    color: #a52d2d;
}

.muted {
    color: #8490a1;
}

.empty {
    padding: 35px 15px;
    text-align: center;
    color: #697586;
}

@media(max-width: 850px) {
.stats { grid-template-columns: repeat(2, 1fr); }
    .stat:last-child { grid-column: span 2; }
}
</style>
<div class="container">

    <div class="header">
        <div>
            <h1>Hotel TV · Cihaz Eşleştirme</h1>
            <div class="subtitle">
                Otel televizyonlarının bağlantı ve eşleştirme durumları
            </div>
        </div>

        <div class="actions">
            <a class="btn secondary" href="index.php">Otel Yönetimi</a>
            <a class="btn" href="devices.php">Cihaz Yönetimi</a>
        </div>
    </div>

    <div class="notice">
        Bu sayfa cihazların eşleştirme durumunu gösterir.
        Yeni TV cihazı eklemek ve oda ataması yapmak için
        <strong>Cihaz Yönetimi</strong> bölümünü kullanın.
        Gerçek eşleştirme işlemi, ayrı Hotel TV Player uygulamasının
        cihaz kodunu Hotel TV API'ye göndermesiyle gerçekleşir.
    </div>

    <div class="stats">
        <div class="stat">
            <div class="stat-label">Toplam Cihaz</div>
            <div class="stat-number"><?= (int)$counts['total'] ?></div>
        </div>

        <div class="stat">
            <div class="stat-label">Eşleştirme Bekliyor</div>
            <div class="stat-number"><?= (int)$counts['pending'] ?></div>
        </div>

        <div class="stat">
            <div class="stat-label">Aktif</div>
            <div class="stat-number"><?= (int)$counts['active'] ?></div>
        </div>

        <div class="stat">
            <div class="stat-label">Devre Dışı</div>
            <div class="stat-number"><?= (int)$counts['disabled'] ?></div>
        </div>

        <div class="stat">
            <div class="stat-label">Engellenmiş</div>
            <div class="stat-number"><?= (int)$counts['blocked'] ?></div>
        </div>
    </div>

    <div class="panel">
        <h2>Kayıtlı TV Cihazları</h2>

        <input
            type="text"
            class="search"
            id="deviceSearch"
            placeholder="Cihaz kodu, otel, şube veya oda ara..."
            oninput="filterDevices()"
        >

        <div class="table-wrap">
            <table id="deviceTable">
                <thead>
                    <tr>
                        <th>Cihaz Kodu</th>
                        <th>Cihaz Adı</th>
                        <th>Platform</th>
                        <th>Otel / Şube</th>
                        <th>Oda</th>
                        <th>Durum</th>
                        <th>Son Bağlantı</th>
                        <th>Uygulama</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (!$devices): ?>
                    <tr>
                        <td colspan="8" class="empty">
                            Henüz kayıtlı TV cihazı bulunmuyor.
                            <br><br>
                            <a class="btn" href="devices.php">İlk Cihazı Ekle</a>
                        </td>
                    </tr>
                <?php else: ?>

                    <?php foreach ($devices as $device): ?>
                        <?php
                            [$statusLabel, $statusClass] =
                                hotel_pair_status($device['status']);

                            $platform = $platformNames[$device['platform'] ?? '']
                                ?? 'Diğer';

                            $room = $device['room_number'] ?? '';

                            if ($room !== '' && !empty($device['room_name'])) {
                                $room .= ' - ' . $device['room_name'];
                            }

                            $lastSeen = $device['last_seen_at']
                                ? date('d.m.Y H:i', strtotime($device['last_seen_at']))
                                : 'Henüz bağlanmadı';
                        ?>

                        <tr>
                            <td>
                                <span class="code">
                                    <?= hotel_pair_h($device['device_code']) ?>
                                </span>
                            </td>

                            <td>
                                <?= hotel_pair_h($device['device_name'] ?: 'İsimsiz cihaz') ?>
                            </td>

                            <td><?= hotel_pair_h($platform) ?></td>

                            <td>
                                <strong><?= hotel_pair_h($device['hotel_name'] ?: '-') ?></strong>
                                <br>
                                <span class="muted">
                                    <?= hotel_pair_h($device['branch_name'] ?: '-') ?>
                                </span>
                            </td>

                            <td><?= hotel_pair_h($room ?: 'Oda atanmamış') ?></td>

                            <td>
                                <span class="status <?= hotel_pair_h($statusClass) ?>">
                                    <?= hotel_pair_h($statusLabel) ?>
                                </span>
                            </td>

                            <td><?= hotel_pair_h($lastSeen) ?></td>

                            <td>
                                <?= hotel_pair_h($device['app_version'] ?: '-') ?>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="panel">
        <h2>Eşleştirme Nasıl Çalışacak?</h2>

        <ol style="font-size:13px;line-height:2;color:#526071;padding-left:22px;">
            <li>Cihaz Yönetimi bölümünden TV cihazı kaydedilir.</li>
            <li>Cihaza otomatik olarak bir eşleştirme kodu verilir.</li>
            <li>Hotel TV Player açıldığında bu kodla sunucuya bağlanır.</li>
            <li>Sunucu cihazı doğrular ve güvenli bağlantı anahtarı üretir.</li>
            <li>TV, bağlı olduğu otel ve oda bilgilerine göre yayın almaya başlar.</li>
        </ol>
    </div>

</div>

<script>
function filterDevices() {
    const input = document.getElementById('deviceSearch');
    const filter = input.value.toLocaleLowerCase('tr-TR');
    const rows = document.querySelectorAll('#deviceTable tbody tr');

    rows.forEach(function(row) {
        const text = row.innerText.toLocaleLowerCase('tr-TR');
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}
</script>
<?php layout_end(); ?>
