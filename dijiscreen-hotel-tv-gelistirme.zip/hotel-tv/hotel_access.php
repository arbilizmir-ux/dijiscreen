<?php
declare(strict_types=1);

function htv_require_manager(): void
{
    require_login();
    $actor = user();
    if (!in_array($actor['role'] ?? '', ['superadmin', 'admin', 'customer'], true)
        || (int) ($actor['id'] ?? 0) <= 0) {
        htv_access_denied();
    }
}

function htv_access_denied(): void
{
    http_response_code(403);
    exit('Bu otel kaydına erişim yetkiniz yok.');
}

function htv_is_superadmin(): bool
{
    return (user()['role'] ?? '') === 'superadmin';
}

// Expressions passed here are column names written in application code.
function htv_hotel_scope(string $column): string
{
    if (htv_is_superadmin()) {
        return '1=1';
    }
    $userId = (int) (user()['id'] ?? 0);
    return "$column IN (
        SELECT member.hotel_id
        FROM hotel_user_access member
        INNER JOIN users account ON account.id = member.user_id
        WHERE member.user_id = $userId AND account.status = 'active'
          AND account.role IN ('admin', 'customer')
    )";
}

function htv_branch_scope(string $column): string
{
    if (htv_is_superadmin()) {
        return '1=1';
    }
    $hotelScope = htv_hotel_scope('access_branch.hotel_id');
    return "$column IN (SELECT access_branch.id FROM hotel_branches access_branch WHERE $hotelScope)";
}

function htv_require_hotel(PDO $pdo, int $hotelId): void
{
    if (htv_is_superadmin()) {
        return;
    }
    $scope = htv_hotel_scope('id');
    $stmt = $pdo->prepare("SELECT 1 FROM hotel_properties WHERE id = ? AND $scope");
    $stmt->execute([$hotelId]);
    if (!$stmt->fetchColumn()) {
        htv_access_denied();
    }
}

function htv_check_csrf(): void
{
    $expected = $_SESSION['csrf'] ?? null;
    $submitted = $_POST['csrf'] ?? null;
    if (!is_string($expected) || $expected === '' || !is_string($submitted)
        || !hash_equals($expected, $submitted)) {
        http_response_code(419);
        exit('Oturum doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.');
    }
}
