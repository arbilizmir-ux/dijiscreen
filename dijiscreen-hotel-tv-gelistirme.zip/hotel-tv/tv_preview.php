<?php
declare(strict_types=1);
/** DijiScreen Hotel TV - Admin-only television preview. No Android/API changes. */
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('id');
require_once __DIR__.'/flights_common.php';
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
function htv_tv_escape($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$types = ['restaurant'=>'Restoran','services'=>'Otel Hizmetleri','tv'=>'Canlı TV','radio'=>'Radyo','flights'=>'Uçuş Bilgileri'];
$hotels=[]; $items=[]; $error='';
try {
    $hotels=$pdo->query("SELECT id,name,timezone FROM hotel_properties WHERE status='active' AND $hotelScope ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $ex) { error_log('[HTV preview hotels] '.$ex->getMessage()); $error='Otel kayıtları okunamadı.'; }
$hotelId=filter_input(INPUT_GET,'hotel_id',FILTER_VALIDATE_INT) ?: 0;
$validIds=array_map(static fn($h)=>(int)$h['id'],$hotels);
if (!$hotelId && $validIds) $hotelId=$validIds[0];
if ($hotelId && !in_array($hotelId,$validIds,true)) { http_response_code(403); exit('Geçersiz otel.'); }
$hotelName='Otel'; $timezone='Europe/Istanbul'; $flights=[]; $flightError=false;
foreach ($hotels as $hotel) if ((int)$hotel['id']===$hotelId) { $hotelName=(string)$hotel['name']; $timezone=(string)$hotel['timezone']; }
if ($hotelId) {
    try {
        $q=$pdo->prepare("SELECT module_type,title,subtitle,description,resource_url,price,currency,sort_order FROM hotel_tv_module_items WHERE hotel_id=? AND status='active' AND module_type IN ('restaurant','services','tv','radio','flights') ORDER BY sort_order ASC,id DESC LIMIT 500");
        $q->execute([$hotelId]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $item) $items[$item['module_type']][]=$item;
    } catch (Throwable $ex) { error_log('[HTV preview modules] '.$ex->getMessage()); $error='Modül içerikleri okunamadı. SQL tablosunu kontrol edin.'; }
}
if ($hotelId) {
    try {
        $flights=htvf_board($pdo,$hotelId);
    } catch (Throwable $ex) {
        error_log('[HTV preview flights] '.$ex->getMessage());
        $flightError=true;
    }
}
$nonce=base64_encode(random_bytes(18));
$payload=json_encode(['items'=>$items,'flights'=>$flights,'flightError'=>$flightError,'timezone'=>$timezone], JSON_INVALID_UTF8_SUBSTITUTE| JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
if ($payload===false) $payload='{}';
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; style-src 'self'; script-src 'self' 'nonce-$nonce'; media-src https:; base-uri 'none'; form-action 'self'; frame-ancestors 'self'");
?><!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DijiScreen Hotel TV</title>
    <link rel="stylesheet" href="tv_preview.css">
    <script nonce="<?= htv_tv_escape($nonce) ?>" type="application/json" id="tv-data"><?= $payload ?></script>
    <script defer src="tv_preview.js"></script>
</head>
<body>
    <div class="toolbar">
        <a href="modules.php?hotel_id=<?= $hotelId ?>">Modül yönetimi</a>
        <form method="get">
            <label for="hotel">Otel</label>
            <select id="hotel" name="hotel_id">
                <?php foreach ($hotels as $h): ?>
                    <option value="<?= (int)$h['id'] ?>" <?= (int)$h['id']===$hotelId?'selected':'' ?>><?= htv_tv_escape($h['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Göster</button>
        </form>
    </div>
    <header class="masthead">
        <div><p class="brand">DIJISCREEN HOTEL TV</p><h1><?= htv_tv_escape($hotelName) ?></h1></div>
        <div class="clock"><time id="clock"></time><p id="date"></p></div>
    </header>
    <?php if ($error): ?><p class="message" role="alert"><?= htv_tv_escape($error) ?></p><?php endif; ?>
    <nav class="menu" aria-label="Hotel TV">
        <button type="button" data-type="home">Ana ekran</button>
        <?php foreach ($types as $key=>$label): ?>
            <button type="button" data-type="<?= htv_tv_escape($key) ?>"><?= htv_tv_escape($label) ?></button>
        <?php endforeach; ?>
    </nav>
    <main>
        <h2 id="section-title">Hoş geldiniz</h2>
        <div id="section" aria-live="polite"></div>
    </main>
</body>
</html>
