<?php
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/i18n.php';
require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
$hotelScope = htv_hotel_scope('b.hotel_id');
$deviceScope = htv_branch_scope('branch_id');

if (!function_exists('hotel_device_e')) {
    function hotel_device_e($value): string {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

$errors = [];
$success = '';
$editDevice = null;

$selectedBranch = (int)($_GET['branch_id'] ?? $_POST['branch_id'] ?? 0);
$editId = (int)($_GET['edit'] ?? 0);

$platforms = [
    'android' => 'Android TV / Android Box',
    'samsung_tizen' => 'Samsung Tizen',
    'lg_webos' => 'LG webOS',
    'other' => 'Diğer'
];

$statuses = [
    'pending' => 'Eşleştirme Bekliyor',
    'active' => 'Aktif',
    'disabled' => 'Pasif',
    'blocked' => 'Engellendi'
];

try {
    $branches = $pdo->query("
        SELECT b.id, b.name, b.code, b.hotel_id, p.name AS hotel_name
        FROM hotel_branches b
        INNER JOIN hotel_properties p ON p.id = b.hotel_id
        WHERE b.status = 'active'
          AND p.status = 'active' AND $hotelScope
        ORDER BY p.name, b.name
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $branches = [];
    $errors[] = 'Şube bilgileri alınamadı. Veritabanı tablolarını kontrol edin.';
}

$branchIds = array_map('intval', array_column($branches, 'id'));

if ($selectedBranch && !in_array($selectedBranch, $branchIds, true)) {
    $selectedBranch = 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    htv_check_csrf();

    $action = $_POST['action'] ?? '';
    $deviceId = (int)($_POST['device_id'] ?? 0);
    $branchId = (int)($_POST['branch_id'] ?? 0);
    $roomId = (int)($_POST['room_id'] ?? 0);
    $deviceName = trim($_POST['device_name'] ?? '');
    $platform = $_POST['platform'] ?? 'android';
    $status = $_POST['status'] ?? 'pending';

    try {
        if (!in_array($branchId, $branchIds, true)) {
            throw new RuntimeException('Lütfen geçerli bir şube seçin.');
        }

        if (!isset($platforms[$platform])) {
            throw new RuntimeException('Geçersiz cihaz platformu.');
        }

        if (!isset($statuses[$status])) {
            throw new RuntimeException('Geçersiz cihaz durumu.');
        }

        if (mb_strlen($deviceName) > 190) {
            throw new RuntimeException('Cihaz adı en fazla 190 karakter olabilir.');
        }

        if ($roomId > 0) {
            $roomCheck = $pdo->prepare("
                SELECT id
                FROM hotel_rooms
                WHERE id = ?
                  AND branch_id = ?
                LIMIT 1
            ");
            $roomCheck->execute([$roomId, $branchId]);

            if (!$roomCheck->fetchColumn()) {
                throw new RuntimeException('Seçilen oda bu şubeye ait değil.');
            }
        } else {
            $roomId = null;
        }

        if ($action === 'save') {
            if ($deviceId > 0) {
                $check = $pdo->prepare("
                    SELECT id
                    FROM hotel_devices
                    WHERE id = ? AND $deviceScope
                    LIMIT 1
                ");
                $check->execute([$deviceId]);

                if (!$check->fetchColumn()) {
                    throw new RuntimeException('Düzenlenecek cihaz bulunamadı.');
                }

                $stmt = $pdo->prepare("
                    UPDATE hotel_devices
                    SET branch_id = ?,
                        room_id = ?,
                        device_name = ?,
                        platform = ?,
                        status = ?
                    WHERE id = ? AND $deviceScope
                ");

                $stmt->execute([
                    $branchId,
                    $roomId,
                    $deviceName !== '' ? $deviceName : null,
                    $platform,
                    $status,
                    $deviceId
                ]);

                $success = 'Cihaz bilgileri güncellendi.';
            } else {
                // Benzersiz cihaz eşleştirme kodu üret.
                $deviceCode = 'HTV-' . strtoupper(bin2hex(random_bytes(6)));

                $stmt = $pdo->prepare("
                    INSERT INTO hotel_devices
                        (branch_id, room_id, device_code, device_name, platform, status)
                    VALUES
                        (?, ?, ?, ?, ?, 'pending')
                ");

                $stmt->execute([
                    $branchId,
                    $roomId,
                    $deviceCode,
                    $deviceName !== '' ? $deviceName : null,
                    $platform
                ]);

                $success = 'Cihaz kaydedildi. Eşleştirme kodu: ' . $deviceCode;
            }
        } elseif ($action === 'disable') {
            $stmt = $pdo->prepare("
                UPDATE hotel_devices
                SET status = 'disabled'
                WHERE id = ? AND $deviceScope
            ");
            $stmt->execute([$deviceId]);

            if (!$stmt->rowCount() && !htv_is_superadmin()) {
                $check = $pdo->prepare("SELECT 1 FROM hotel_devices WHERE id = ? AND $deviceScope");
                $check->execute([$deviceId]);
                if (!$check->fetchColumn()) htv_access_denied();
            }
            $success = 'Cihaz pasife alındı.';
        } else {
            throw new RuntimeException('Geçersiz işlem.');
        }

        $selectedBranch = $branchId;
        $editId = 0;

    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            $errors[] = 'Bu cihaz kodu zaten kullanılıyor. Lütfen tekrar deneyin.';
        } else {
            $errors[] = 'Veritabanı işlemi sırasında hata oluştu.';
        }
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

// Düzenlenecek cihaz
if ($editId > 0) {
    $stmt = $pdo->prepare("
        SELECT *
        FROM hotel_devices
        WHERE id = ? AND $deviceScope
        LIMIT 1
    ");
    $stmt->execute([$editId]);
    $editDevice = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($editDevice) {
        $selectedBranch = (int)$editDevice['branch_id'];
    }
}

// Seçilen şubenin odaları
$rooms = [];

if ($selectedBranch > 0) {
    $stmt = $pdo->prepare("
        SELECT id, room_number, room_name
        FROM hotel_rooms
        WHERE branch_id = ? AND $deviceScope
        ORDER BY room_number
    ");
    $stmt->execute([$selectedBranch]);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Cihaz listesi
$params = [];
$sql = "
    SELECT
        d.*,
        b.name AS branch_name,
        p.name AS hotel_name,
        r.room_number,
        r.room_name
    FROM hotel_devices d
    INNER JOIN hotel_branches b ON b.id = d.branch_id
    INNER JOIN hotel_properties p ON p.id = b.hotel_id
    LEFT JOIN hotel_rooms r ON r.id = d.room_id AND r.branch_id = d.branch_id
    WHERE $hotelScope
";

if ($selectedBranch > 0) {
    $sql .= " AND d.branch_id = ?";
    $params[] = $selectedBranch;
}

$sql .= " ORDER BY d.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$devices = $stmt->fetchAll(PDO::FETCH_ASSOC);

$onlineLimit = 150;
?>
<?php layout_start('Hotel TV - Cihaz Yönetimi'); ?>
<style>
.container{max-width:1200px;margin:auto}
h1{margin:0 0 8px;font-size:26px}
.subtitle{color:#697586;margin-bottom:24px}
.panel{background:#fff;border:1px solid #e4e8ef;border-radius:12px;padding:22px;margin-bottom:22px}
h2{font-size:19px;margin:0 0 18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.field label{display:block;font-size:13px;font-weight:bold;margin-bottom:7px}
input,select{width:100%;padding:11px;border:1px solid #d5dbe5;border-radius:7px;background:#fff;font-size:14px}
button,.btn{display:inline-block;border:0;border-radius:7px;padding:11px 16px;background:#2457d6;color:#fff;font-weight:bold;text-decoration:none;cursor:pointer;font-size:14px}
.btn-secondary{background:#687386}
.btn-danger{background:#b83232}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:18px}
.notice{padding:12px 15px;border-radius:8px;margin-bottom:16px;background:#e8f6ed;color:#176534}
.error{padding:12px 15px;border-radius:8px;margin-bottom:16px;background:#fdecec;color:#9b2525}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:850px}
th,td{text-align:left;padding:12px;border-bottom:1px solid #edf0f4;font-size:13px;vertical-align:middle}
th{background:#f8f9fb;color:#596579}
.code{font-family:monospace;font-weight:bold;letter-spacing:1px}
.status{display:inline-block;padding:5px 9px;border-radius:20px;background:#edf0f4;font-size:12px}
.status.active{background:#e5f6eb;color:#176534}
.status.pending{background:#fff4d8;color:#8a5a00}
.status.disabled,.status.blocked{background:#fdeaea;color:#9b2525}
.small{color:#778195;font-size:12px}
@media(max-width:700px){.grid{grid-template-columns:1fr}.panel{padding:16px}}
</style>
<div class="container">

<h1>Hotel TV Cihaz Yönetimi</h1>
<div class="subtitle">
DijiScreen Hotel TV · Otel televizyonları ve cihaz eşleştirme yönetimi
</div>

<?php if ($success): ?>
<div class="notice"><?= hotel_device_e($success) ?></div>
<?php endif; ?>

<?php foreach ($errors as $error): ?>
<div class="error"><?= hotel_device_e($error) ?></div>
<?php endforeach; ?>

<div class="panel">
<h2><?= $editDevice ? 'Cihazı Düzenle' : 'Yeni Cihaz Ekle' ?></h2>

<?php if (!$branches): ?>
<div class="error">Önce aktif bir otel ve şube oluşturmalısınız.</div>
<?php else: ?>

<form method="post">
<input type="hidden" name="csrf" value="<?= hotel_device_e(csrf()) ?>">
<input type="hidden" name="action" value="save">
<input type="hidden" name="device_id" value="<?= (int)($editDevice['id'] ?? 0) ?>">

<div class="grid">

<div class="field">
<label>Otel Şubesi</label>
<select name="branch_id" required onchange="this.form.querySelector('[name=room_id]').value='';">
<option value="">Şube seçin</option>
<?php foreach ($branches as $branch): ?>
<option value="<?= (int)$branch['id'] ?>"
<?= $selectedBranch === (int)$branch['id'] ? 'selected' : '' ?>>
<?= hotel_device_e($branch['hotel_name'] . ' / ' . $branch['name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<div class="field">
<label>Oda</label>
<select name="room_id">
<option value="0">Oda seçilmedi</option>
<?php foreach ($rooms as $room): ?>
<option value="<?= (int)$room['id'] ?>"
<?= (int)($editDevice['room_id'] ?? 0) === (int)$room['id'] ? 'selected' : '' ?>>
<?= hotel_device_e($room['room_number'] . ($room['room_name'] ? ' - ' . $room['room_name'] : '')) ?>
</option>
<?php endforeach; ?>
</select>
<div class="small">Oda seçmeden de cihaz kaydedebilirsiniz.</div>
</div>

<div class="field">
<label>Cihaz Adı</label>
<input type="text" name="device_name" maxlength="190"
placeholder="Örn. Oda 101 Televizyonu"
value="<?= hotel_device_e($editDevice['device_name'] ?? '') ?>">
</div>

<div class="field">
<label>Cihaz Platformu</label>
<select name="platform" required>
<?php foreach ($platforms as $key => $label): ?>
<option value="<?= hotel_device_e($key) ?>"
<?= ($editDevice['platform'] ?? 'android') === $key ? 'selected' : '' ?>>
<?= hotel_device_e($label) ?>
</option>
<?php endforeach; ?>
</select>
</div>

<?php if ($editDevice): ?>
<div class="field">
<label>Cihaz Durumu</label>
<select name="status">
<?php foreach ($statuses as $key => $label): ?>
<option value="<?= hotel_device_e($key) ?>"
<?= ($editDevice['status'] ?? 'pending') === $key ? 'selected' : '' ?>>
<?= hotel_device_e($label) ?>
</option>
<?php endforeach; ?>
</select>
</div>
<?php endif; ?>

</div>

<div class="actions">
<button type="submit"><?= $editDevice ? 'Değişiklikleri Kaydet' : 'Cihaz Oluştur' ?></button>
<?php if ($editDevice): ?>
<a class="btn btn-secondary" href="devices.php?branch_id=<?= $selectedBranch ?>">Vazgeç</a>
<?php endif; ?>
</div>
</form>

<?php endif; ?>
</div>

<div class="panel">
<h2>Kayıtlı Cihazlar</h2>

<form method="get" style="max-width:420px;margin-bottom:18px">
<div class="field">
<label>Şubeye Göre Filtrele</label>
<select name="branch_id" onchange="this.form.submit()">
<option value="0">Tüm şubeler</option>
<?php foreach ($branches as $branch): ?>
<option value="<?= (int)$branch['id'] ?>"
<?= $selectedBranch === (int)$branch['id'] ? 'selected' : '' ?>>
<?= hotel_device_e($branch['hotel_name'] . ' / ' . $branch['name']) ?>
</option>
<?php endforeach; ?>
</select>
</div>
</form>

<div class="table-wrap">
<table>
<thead>
<tr>
<th>Otel / Şube</th>
<th>Oda</th>
<th>Cihaz</th>
<th>Platform</th>
<th>Eşleştirme Kodu</th>
<th>Durum</th>
<th>Son Bağlantı</th>
<th>İşlem</th>
</tr>
</thead>
<tbody>

<?php if (!$devices): ?>
<tr><td colspan="8">Henüz cihaz kaydı bulunmuyor.</td></tr>
<?php endif; ?>

<?php foreach ($devices as $device): ?>
<?php
$lastSeen = $device['last_seen_at']
    ? strtotime($device['last_seen_at'])
    : false;

$isOnline = $lastSeen && (time() - $lastSeen <= $onlineLimit);
$statusClass = $device['status'];
?>
<tr>
<td>
<strong><?= hotel_device_e($device['hotel_name']) ?></strong><br>
<span class="small"><?= hotel_device_e($device['branch_name']) ?></span>
</td>

<td>
<?= $device['room_number']
    ? hotel_device_e($device['room_number'] . ($device['room_name'] ? ' - ' . $device['room_name'] : ''))
    : '<span class="small">Atanmamış</span>' ?>
</td>

<td>
<strong><?= hotel_device_e($device['device_name'] ?: 'İsimsiz cihaz') ?></strong><br>
<span class="small">ID: <?= (int)$device['id'] ?></span>
</td>

<td><?= hotel_device_e($platforms[$device['platform']] ?? $device['platform']) ?></td>

<td class="code"><?= hotel_device_e($device['device_code']) ?></td>

<td>
<span class="status <?= hotel_device_e($statusClass) ?>">
<?= hotel_device_e($statuses[$device['status']] ?? $device['status']) ?>
</span>
<br>
<span class="small">
<?= $isOnline ? 'Çevrimiçi' : 'Çevrimdışı' ?>
</span>
</td>

<td>
<?= $lastSeen ? hotel_device_e(date('d.m.Y H:i', $lastSeen)) : 'Henüz bağlanmadı' ?>
<?php if (!empty($device['app_version'])): ?>
<br><span class="small">Sürüm: <?= hotel_device_e($device['app_version']) ?></span>
<?php endif; ?>
</td>

<td>
<div class="actions" style="margin:0">
<a class="btn btn-secondary"
href="devices.php?edit=<?= (int)$device['id'] ?>">Düzenle</a>

<?php if ($device['status'] !== 'disabled'): ?>
<form method="post" onsubmit="return confirm('Bu cihaz pasife alınsın mı?')">
<input type="hidden" name="csrf" value="<?= hotel_device_e(csrf()) ?>">
<input type="hidden" name="action" value="disable">
<input type="hidden" name="device_id" value="<?= (int)$device['id'] ?>">
<input type="hidden" name="branch_id" value="<?= (int)$device['branch_id'] ?>">
<button type="submit" class="btn btn-danger">Pasife Al</button>
</form>
<?php endif; ?>
</div>
</td>
</tr>
<?php endforeach; ?>

</tbody>
</table>
</div>
</div>

<div class="panel">
<h2>Önemli Bilgi</h2>
<p class="small">
Yeni cihaz oluşturulduğunda sistem otomatik bir eşleştirme kodu üretir.
Bu aşamada cihaz kaydı ve kod üretimi yapılmaktadır. Televizyonun sunucuya
bağlanması, güvenli cihaz token'ı oluşturulması ve otomatik aktifleşmesi için
ayrı Hotel TV API ve Player eşleştirme akışı hazırlanacaktır.
</p>
</div>

</div>
<?php layout_end(); ?>