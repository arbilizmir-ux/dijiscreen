<?php
declare(strict_types=1);
// CLI-only cron: php /home/ACCOUNT/public_html/server/public/hotel-tv/flights_sync.php
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
require dirname(__DIR__,2).'/app/bootstrap.php';require_once __DIR__.'/flights_common.php';
require_once __DIR__.'/flights_airlabs.php';
function htvf_fetch(string $template,string $airport,string $direction,?string $key): array {
 if($template===HTVF_AIRLABS_ENDPOINT){
  $key=getenv('HTV_AIRLABS_API_KEY');
  if(!$key)throw new RuntimeException('AirLabs API anahtarı eksik.');
  $parameter=$direction==='arrivals'?'arr_iata':'dep_iata';
  $offset=0;
  $rows=[];
  for($page=0;$page<10;$page++){
   $query=http_build_query([$parameter=>$airport,'api_key'=>$key,'limit'=>1000,'offset'=>$offset]);
   $data=htvf_fetch_json(HTVF_AIRLABS_ENDPOINT.'?'.$query,null);
   $rows=array_merge($rows,htvf_airlabs_rows($data,$airport,$direction));
   if(empty($data['request']['has_more']))return $rows;
   $count=count($data['response']);
   if(!$count)break;
   $offset+=$count;
  }
  throw new RuntimeException('AirLabs sayfalaması tamamlanamadı.');
 }
 $url=str_replace(['{airport}','{direction}'],[rawurlencode($airport),rawurlencode($direction)],$template);
 $data=htvf_fetch_json($url,$key);
 $rows=$data['flights']??null;
 if(!is_array($rows)||!array_is_list($rows))throw new RuntimeException('JSON flights dizisi yok.');
 return array_slice($rows,0,2000);
}
function htvf_fetch_json(string $url,?string $key): array {
 $parts=parse_url($url);$host=$parts['host']??'';
 if(($parts['scheme']??'')!=='https'||!$host||isset($parts['user'])||isset($parts['pass']))throw new RuntimeException('Geçersiz HTTPS sağlayıcı URL.');
 $ips=gethostbynamel($host);if(!$ips)throw new RuntimeException('Sağlayıcı DNS çözümlenemedi.');
 foreach($ips as $ip){if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE))throw new RuntimeException('Özel ağ adresine bağlantı yasak.');}
 if(!function_exists('curl_init'))throw new RuntimeException('PHP cURL gerekli.');
 $ch=curl_init($url);$headers=['Accept: application/json'];if($key)$headers[]='Authorization: Bearer '.$key;
 curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_HTTPHEADER=>$headers,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_MAXREDIRS=>0]);
 curl_setopt($ch,CURLOPT_RESOLVE,[$host.':'.($parts['port']??443).':'.$ips[0]]);
 curl_setopt($ch,CURLOPT_PROXY,'');
 $body='';
 curl_setopt($ch,CURLOPT_WRITEFUNCTION,static function($handle,string $chunk)use(&$body):int{
  if(strlen($body)+strlen($chunk)>3000000)return 0;
  $body.=$chunk;
  return strlen($chunk);
 });
 $ok=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 if($ok===false||$status!==200)throw new RuntimeException('API yanıtı başarısız: HTTP '.$status);
 $data=json_decode($body,true,512,JSON_THROW_ON_ERROR);if(!is_array($data))throw new RuntimeException('JSON nesnesi bekleniyor.');
 return $data;
}
try{$settings=$pdo->query('SELECT * FROM hotel_flight_settings WHERE enabled=1')->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){error_log('[HTV flights sync] '.$e->getMessage());exit(1);}
$failed=false;
// PDO ile PHP aynı sunucu saat dilimine ayarlı olmalıdır.
foreach($settings as $s){$hotel=(int)$s['hotel_id'];$dirs=$s['direction']==='both'?['departures','arrivals']:[$s['direction']];
 foreach(htvf_codes((string)$s['airport_codes']) as $airport)foreach($dirs as $dir){
  try{$rows=htvf_fetch((string)$s['provider_url'],$airport,$dir,$s['api_key']);$valid=[];
   foreach($rows as $r){if(!is_array($r))continue;
    $num=substr(trim((string)($r['flight_number']??'')),0,30);if($num==='')continue;
    $date=(string)($r['scheduled_at']??'');$timestamp=strtotime($date);if(!$timestamp)continue;
    $valid[]=[$hotel,$airport,$dir,$num,substr((string)($r['destination']??''),0,150),date('Y-m-d H:i:s',$timestamp),!empty($r['estimated_at'])&&strtotime((string)$r['estimated_at'])?date('Y-m-d H:i:s',strtotime((string)$r['estimated_at'])):null,substr((string)($r['status']??''),0,80)];
   }
   if($rows!==[] && $valid===[])throw new RuntimeException('Geçerli uçuş kaydı bulunamadı.');
   $pdo->beginTransaction();
   // Sadece başarılı ve şeması doğrulanmış yanıt sonrası bu havalimanı/yön verileri yenilenir.
   $del=$pdo->prepare('DELETE FROM hotel_flight_cache WHERE hotel_id=? AND airport_code=? AND direction=?');$del->execute([$hotel,$airport,$dir]);
   $ins=$pdo->prepare('INSERT IGNORE INTO hotel_flight_cache(hotel_id,airport_code,direction,flight_number,destination,scheduled_at,estimated_at,flight_status,fetched_at) VALUES(?,?,?,?,?,?,?,?,NOW())');
   foreach($valid as $v)$ins->execute($v);
   $pdo->commit();echo "OK hotel=$hotel airport=$airport direction=$dir count=".count($valid)."\n";
  }catch(Throwable $e){$failed=true;if($pdo->inTransaction())$pdo->rollBack();error_log('[HTV flights sync] hotel='.$hotel.' airport='.$airport.' '.$e->getMessage());echo "ERROR hotel=$hotel airport=$airport direction=$dir\n";}
 }
}
exit($failed ? 1 : 0);
