# DijiScreen Hotel TV geliştirme raporu

Geliştirme için hotel-tv (2).zip içindeki PHP dosyaları ile 53 tablolu SQL şeması kullanıldı. Paket, mevcut hotel-tv klasörüne uygulanacak dosyaları ve otel atamaları için ayrı bir SQL migration dosyasını içerir. Çalışma izole kopyada yürütüldü.

## Hotel TV

- Yönetim ana sayfasındaki TV Önizlemesi kartı, sistem yöneticisinin otel seçip misafir ekranını açmasını sağlar. Ana ekran, otel saat dilimine göre saat ve beş modül için kumanda ya da klavyeyle seçilebilen kartlar gösterir.
- Restoran ve hizmet kartları mevcut modül kayıtlarını kullanır. Menü fiyatları kayıtlı para birimiyle biçimlenir. Yönetim ekranına para birimi girişi ve önizleme kısayolu eklendi.
- Radyo ve canlı TV, HTTPS yayınlarını tarayıcının yerleşik ses ve video oynatıcısında kullanıcı etkileşimiyle açar. Oynatım başarısız olursa kaynak bağlantısı kullanılabilir. HLS ve diğer biçimlerin desteği tarayıcı ve cihaza bağlıdır.
- Uçuş sekmesi otelin etkin havalimanı ve yön ayarlarını kullanır. Planlanan ve tahmini saatler, eski veri uyarısı ve manuel duyurular gösterilir. Ekrandaki otomatik uçuş verisi sayfa açılışında okunur.
- Paylaşılan SQL'deki ds_restaurants ve hotel_iptv_sources gibi ayrı kataloglar bu önizlemenin modül kayıtlarına otomatik bağlanmadı. Restoran ve yayın verisi için mevcut hotel_tv_module_items akışı kullanıldı.

## AirLabs kurulumu

Geliştirme ortamındaki Uçuş Ayarları sayfasında sağlayıcı URL'sine https://airlabs.co/api/v9/schedules yazın. IATA kodlarını ve yönü seçip otomatik güncellemeyi etkinleştirin. Anahtarı PHP cron işleminin gizli HTV_AIRLABS_API_KEY ortam değişkeninde saklayın. Genel sağlayıcı için kullanılan form anahtarı AirLabs'a gönderilmez. Aynı otelde eşzamanlı çalışan alternatif AeroDataBox cron görevi önbelleğe aynı kapsamda yazabilir. Geliştirme testinde otel başına bir yazıcı kullanın.

Sunucu PHP varsayılan saat dilimi ile MySQL oturumunun saat dilimi eşleşmeli. AirLabs UTC saatleri mevcut önbellek biçimine yazılırken PHP'nin saat dilimine dönüştürülür. Bir havalimanı ve yön için API veya sayfalama hatasında eski önbellek korunur. CLI en az bir kapsam başarısız olduğunda hata çıkış kodu döndürür. Sağlayıcının kota ve tazelik hedeflerine göre cron sıklığı belirlenmeli. Her havalimanı ve yön en az bir istek kullanır.

## PMS ve güvenlik incelemesi

- PMS bağlantı ayarları, şifrelenmiş sağlayıcı bilgileri, oda eşleme, imzalı webhook ve staging inceleme kodları var. İncelenen webhook yollarından biri olay üstverisini, diğeri hazırlanacak kaydı yazar. İnceleme akışı staging durumunu günceller. Gerçek sağlayıcı hesabı veya rezervasyon eşitlemesi doğrulanmadı.
- Modül yönetimi ve önizlemede kayıtlı yayın URL'leri HTTPS ve kullanıcı bilgisi açısından denetlenir. Önizlemede CSP kullanılır ve metin girdileri DOM'a metin olarak yazılır.
- Genel uçuş sağlayıcısı isteği doğrulanan DNS sonucuna sabitlenir. Yönlendirmeler kapalı, yanıt gövdesi aktarım sırasında 3 MB ile sınırlı. Cron hataları sağlayıcı URL'sini veya ham cURL hatasını yazmaz.
- Misafir, konaklama, cihaz ve bazı yönetim sayfalarında arşiv kapsamındaki erişim kontrolü require_login() çağrısına bağlı. Oturum açmış kullanıcıların rol ve otel kapsamını doğrulamak için ortak bootstrap ve yönlendirme kuralları gerekiyor.
- Cihaz eşleştirme uç noktasında bu klasör kapsamında device_pair_attempts tablosuna bağlı hız sınırlaması bulunamadı. Sunucu katmanında ek kontrol olup olmadığı incelenmeli.
- Orijinal ZIP, web klasöründe error_log içeriyordu. Sunucu engeli paylaşılan arşivden doğrulanamadı. Dosya geliştirme paketine alınmadı.

## Doğrulama

PHP 8.4 sözdizimi kontrolü 32 PHP dosyasında, Node.js sözdizimi kontrolü önizleme betiğinde geçti. Chromium ve yerel PHP sunucusunda örnek PDO ile yönetici ve otel kontrolleri, kumanda gezinmesi, beş modül, güvensiz URL engellemesi, yayın hata durumu, eski uçuş uyarısı ve dar ekran test edildi. AirLabs örnek yanıtı ile geliş/gidiş, UTC saatleri, boş yanıt ve hata işleme test edildi.

İlk tur örnek PDO ile yürütüldü. Sonraki MariaDB ve bootstrap doğrulaması aşağıda yer alıyor.

## Bootstrap ile yerel entegrasyon

Sonradan paylaşılan gerçek bootstrap ile MariaDB 11.8 üzerinde kaynak SQL'in 53 tablosu kuruldu. Yalnızca tablo yapısı ve sentetik kayıtlar kullanıldı. Oturumsuz yönlendirme, önizleme yönetici yetkisi, otel seçimi, modül ekleme ve para birimi, uçuş havalimanı filtresi, tahmini saat ve veri yaşının okunması geçti. PMS yönetim, operasyon ve inceleme sayfaları boş entegrasyon verisiyle açıldı. Gerçek PMS ve AirLabs sağlayıcı çağrıları bu testin dışında.

Kod incelemesi `require_login()` işlevinin yalnızca oturum kontrol ettiğini doğruladı. Misafir, konaklama, oda, cihaz ve Hotel TV yönetim ana sayfasında rol veya otele göre kapsam denetimi bu iki arşivde görülmedi. Sunucu giriş kuralları ayrı değerlendirilmelidir. Sonraki sürümde aşağıdaki otel atamaları uygulandı.

## Otel bazlı yetkilendirme

- Paylaşılan şemada kullanıcı–otel kaydı bulunmadığından `hotel_user_access` tablosu eklendi. Yalnızca `superadmin` Otel Yetkileri ekranından atama yapabilir veya kaldırabilir. Her kullanıcı birden fazla otele atanabilir. Ataması olmayan kullanıcılar otel kayıtlarını göremez.
- `admin` ve `customer` atandıkları oteller için yönetim özeti, otel bilgileri, şube, kat, oda, cihaz, eşleştirme paneli, misafir, konaklama, modül içerikleri, TV önizlemesi ve uçuş ayarlarını kullanabilir. Uçuş ekranında havalimanı ve yönü düzenleyebilirler. PMS bağlantı ve senkronizasyon durumunu okuyabilirler.
- Yeni otel oluşturma, kullanıcı–otel ataması, uçuş sağlayıcısı ve kimlik bilgileri ile PMS sağlayıcı yapılandırması `superadmin` yetkisindedir. Mevcut Android cihaz uç noktaları geliştirme paketinin dışındadır.
- Geliştirme ortamında önce `migrations/001_hotel_user_access.sql` çalıştırılır. Geçişten önce mevcut admin/customer hesapları için doğru otel atamaları hazırlanmalı. Migration mevcut hesaplara otomatik atama yapmaz. Yetkili kullanıcılar Hotel TV → Otel Yetkileri ekranından atanır.

Gerçek bootstrap ve yerel MariaDB ile iki örnek otel, iki yetkili hesap ve bir atamasız hesap kullanıldı. 13 giriş noktası, atama ve kaldırma, modül/kat/uçuş ayarlarına yazma, sağlayıcı bilgilerinin gizlenmesi ve genel yönetici kapsamı geçti. Canlı sistemde migration çalıştırılmadı.
