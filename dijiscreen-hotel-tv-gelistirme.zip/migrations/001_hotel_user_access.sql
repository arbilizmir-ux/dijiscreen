CREATE TABLE IF NOT EXISTS hotel_user_access (
    user_id INT UNSIGNED NOT NULL,
    hotel_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (user_id, hotel_id),
    KEY idx_hotel_user_access_hotel (hotel_id),
    CONSTRAINT fk_hotel_user_access_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_hotel_user_access_hotel FOREIGN KEY (hotel_id) REFERENCES hotel_properties(id) ON DELETE CASCADE
) ENGINE=InnoDB;
