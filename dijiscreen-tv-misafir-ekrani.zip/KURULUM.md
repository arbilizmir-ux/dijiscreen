# DijiScreen Hotel TV misafir ekranı

1. ZIP içindeki dört dosyayı test sunucusunda mevcut `server/public/hotel-tv/` klasörüne birlikte yükleyin.
2. Yönetimden **Hotel TV → TV Önizlemesi** bölümünde oteli seçin. **Misafir ekranını aç** bağlantısını kullanın.
3. Bağlantıyı test TV'sinin tarayıcısında açın. Yönetici oturumuna gerek yok. Tarayıcı destekliyorsa **Tam ekran** düğmesi kullanılabilir.
4. Kumandada yön tuşları, OK ve Geri işlevlerini ve varsa radyo/canlı TV oynatımını kontrol edin.

Bağlantı, seçili otelin modüllerini ve uçuş panosunu açan, 24 saat geçerli bir görüntüleme bağlantısıdır. Süresi dolarsa TV Önizlemesi'nden yenisini açın. Bağlantıyı yalnızca ilgili ekranlarla paylaşın. Ekranda yönetim işlemleri veya konaklama bilgisi yer almaz.

Bağlantı oluşturmak için mevcut sunucu yapılandırmasında en az 32 karakterlik bir `app_key` gerekir. Eğer bağlantı yerine sunucu anahtarı uyarısı çıkarsa yapılandırmayı sunucu yöneticisi kontrol etmelidir. SQL geçişi veya Android APK güncellemesi gerekmez.

Yerel MariaDB ve 1920×1080 Chromium ile beş modülün açılması, kumanda tuşlarının klavye karşılıkları, tam ekran ve bağlantı denetimi doğrulandı. Fiziksel TV, uzun süreli kiosk kullanımı ve TV tarayıcısında medya oynatımı ayrı test gerektirir.
