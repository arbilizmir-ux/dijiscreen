<?php
declare(strict_types=1);

$guestScreen = true;
require __DIR__ . '/tv_preview.php';
