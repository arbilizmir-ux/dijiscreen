<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once __DIR__ . '/hotel_access.php';
require_once __DIR__ . '/flights_common.php';

$guestScreen = $guestScreen ?? false;
$displayKey = $config['app_key'] ?? '';
$displayKey = is_string($displayKey) && strlen($displayKey) >= 32 ? $displayKey : '';
$hotelId = filter_input(INPUT_GET, 'hotel_id', FILTER_VALIDATE_INT) ?: 0;

function htv_tv_escape($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function htv_display_signature(string $key, int $hotelId, int $expires): string
{
    return hash_hmac('sha256', "hotel-tv-guest:v1:$hotelId:$expires", $key);
}

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
if ($guestScreen) {
    header('X-Robots-Tag: noindex, nofollow');
    $expires = filter_input(INPUT_GET, 'expires', FILTER_VALIDATE_INT) ?: 0;
    $ticket = filter_input(INPUT_GET, 'ticket') ?? '';
    if (!$displayKey || $hotelId < 1 || $expires <= time() || $expires > time() + 86400
        || !is_string($ticket) || !hash_equals(htv_display_signature($displayKey, $hotelId, $expires), $ticket)) {
        http_response_code(403);
        exit('TV bağlantısı geçersiz veya süresi dolmuş. Resepsiyondan yeni bağlantı alın.');
    }
} else {
    htv_require_manager();
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$types = ['restaurant'=>'Restoran','services'=>'Otel Hizmetleri','tv'=>'Canlı TV','radio'=>'Radyo','flights'=>'Uçuş Bilgileri'];
$hotels = [];
$items = [];
$error = '';
try {
    if ($guestScreen) {
        $query = $pdo->prepare("SELECT id, name, timezone FROM hotel_properties WHERE id = ? AND status = 'active'");
        $query->execute([$hotelId]);
        $hotels = $query->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $hotelScope = htv_hotel_scope('id');
        $hotels = $pdo->query("SELECT id, name, timezone FROM hotel_properties WHERE status = 'active' AND $hotelScope ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $ex) {
    error_log('[HTV display hotels] '.$ex->getMessage());
    if ($guestScreen) {
        http_response_code(503);
        exit('TV ekranı şu anda açılamıyor.');
    }
    $error = 'Otel kayıtları okunamadı.';
}
$validIds = array_map(static fn($h) => (int)$h['id'], $hotels);
if (!$hotelId && $validIds) $hotelId = $validIds[0];
if ($hotelId && !in_array($hotelId, $validIds, true)) {
    http_response_code(403);
    exit('Geçersiz otel.');
}
$guestUrl = '';
if (!$guestScreen && $hotelId && $displayKey) {
    $expires = time() + 86400;
    $guestUrl = 'tv_guest.php?' . http_build_query([
        'hotel_id' => $hotelId,
        'expires' => $expires,
        'ticket' => htv_display_signature($displayKey, $hotelId, $expires),
    ]);
}

$hotelName='Otel'; $timezone='Europe/Istanbul'; $flights=[]; $flightError=false;
foreach ($hotels as $hotel) if ((int)$hotel['id']===$hotelId) { $hotelName=(string)$hotel['name']; $timezone=(string)$hotel['timezone']; }
if ($hotelId) {
    try {
        $q=$pdo->prepare("SELECT module_type,title,subtitle,description,resource_url,price,currency,sort_order FROM hotel_tv_module_items WHERE hotel_id=? AND status='active' AND module_type IN ('restaurant','services','tv','radio','flights') ORDER BY sort_order ASC,id DESC LIMIT 500");
        $q->execute([$hotelId]);
        foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $item) $items[$item['module_type']][]=$item;
    } catch (Throwable $ex) { error_log('[HTV preview modules] '.$ex->getMessage()); $error=$guestScreen ? 'İçerikler şu anda açılamıyor.' : 'Modül içerikleri okunamadı. SQL tablosunu kontrol edin.'; }
}
if ($hotelId) {
    try {
        $flights=htvf_board($pdo,$hotelId);
    } catch (Throwable $ex) {
        error_log('[HTV preview flights] '.$ex->getMessage());
        $flightError=true;
    }
}
$nonce=base64_encode(random_bytes(18));
$payload=json_encode(['items'=>$items,'flights'=>$flights,'flightError'=>$flightError,'timezone'=>$timezone], JSON_INVALID_UTF8_SUBSTITUTE| JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
if ($payload===false) $payload='{}';
header("Content-Security-Policy: default-src 'none'; style-src 'self'; script-src 'self' 'nonce-$nonce'; media-src https:; base-uri 'none'; form-action 'self'; frame-ancestors 'self'");
?><!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DijiScreen Hotel TV</title>
    <link rel="stylesheet" href="tv_preview.css">
    <script nonce="<?= htv_tv_escape($nonce) ?>" type="application/json" id="tv-data"><?= $payload ?></script>
    <script defer src="tv_preview.js"></script>
</head>
<body<?= $guestScreen ? ' class="guest-screen"' : '' ?>>
    <?php if (!$guestScreen): ?>
    <div class="toolbar">
        <a href="modules.php?hotel_id=<?= $hotelId ?>">Modül yönetimi</a>
        <form method="get">
            <label for="hotel">Otel</label>
            <select id="hotel" name="hotel_id">
                <?php foreach ($hotels as $h): ?>
                    <option value="<?= (int)$h['id'] ?>" <?= (int)$h['id']===$hotelId?'selected':'' ?>><?= htv_tv_escape($h['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Göster</button>
        </form>
        <?php if ($guestUrl): ?>
            <a href="<?= htv_tv_escape($guestUrl) ?>" target="_blank" rel="noopener noreferrer">Misafir ekranını aç</a>
        <?php elseif ($hotelId): ?>
            <span>Misafir ekranı için sunucu anahtarı yapılandırılmalı.</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <header class="masthead">
        <div><p class="brand"><?= $guestScreen ? 'OTEL REHBERİ' : 'DIJISCREEN HOTEL TV' ?></p><h1><?= htv_tv_escape($hotelName) ?></h1></div>
        <div class="clock"><time id="clock"></time><p id="date"></p><?php if ($guestScreen): ?><button type="button" id="fullscreen" hidden>Tam ekran</button><?php endif; ?></div>
    </header>
    <?php if ($error): ?><p class="message" role="alert"><?= htv_tv_escape($error) ?></p><?php endif; ?>
    <nav class="menu" aria-label="Hotel TV">
        <button type="button" data-type="home">Ana ekran</button>
        <?php foreach ($types as $key=>$label): ?>
            <button type="button" data-type="<?= htv_tv_escape($key) ?>"><?= htv_tv_escape($label) ?></button>
        <?php endforeach; ?>
    </nav>
    <main>
        <h2 id="section-title">Hoş geldiniz</h2>
        <div id="section" aria-live="polite"></div>
        <?php if ($guestScreen): ?><p class="remote-hint">Yön tuşlarıyla gezin · OK ile seçin · Geri ile ana ekrana dönün</p><?php endif; ?>
    </main>
</body>
</html>
