'use strict';

const config = JSON.parse(document.getElementById('tv-data').textContent);
const tabs = Array.from(document.querySelectorAll('[data-type]'));
const section = document.getElementById('section');
const guestScreen = document.body.classList.contains('guest-screen');
const fullscreen = document.getElementById('fullscreen');

if (fullscreen && document.fullscreenEnabled && document.documentElement.requestFullscreen) {
    fullscreen.hidden = false;
    fullscreen.addEventListener('click', async () => {
        try {
            if (document.fullscreenElement) await document.exitFullscreen();
            else await document.documentElement.requestFullscreen();
        } catch {
            fullscreen.textContent = 'Tam ekran kullanılamıyor';
        }
    });
    document.addEventListener('fullscreenchange', () => {
        fullscreen.textContent = document.fullscreenElement ? 'Tam ekrandan çık' : 'Tam ekran';
    });
}
const labels = Object.fromEntries(tabs.map(tab => [tab.dataset.type, tab.textContent.trim()]));

function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text != null) node.textContent = text;
    if (className) node.className = className;
    return node;
}

function sourceUrl(value) {
    try {
        const url = new URL(value);
        return url.protocol === 'https:' && !url.username && !url.password ? url : null;
    } catch {
        return null;
    }
}

function addSource(card, item, type) {
    const url = sourceUrl(item.resource_url);
    if (!url) return;
    const mediaType = type === 'tv' ? 'video' : type === 'radio' ? 'audio' : null;
    if (mediaType) {
        const play = element('button', 'Yayını oynat');
        play.type = 'button';
        play.addEventListener('click', () => {
            const player = element(mediaType);
            const status = element('p');
            status.setAttribute('role', 'status');
            player.controls = true;
            player.tabIndex = 0;
            player.preload = 'none';
            player.setAttribute('aria-label', item.title);
            if (mediaType === 'video') player.playsInline = true;
            const unavailable = () => {
                status.textContent = 'Yayın bu cihazda oynatılamadı. Yayın bağlantısını açabilirsiniz.';
            };
            player.addEventListener('error', unavailable);
            player.src = url.href;
            play.replaceWith(player, status);
            player.focus();
            const attempt = player.play();
            if (attempt) attempt.catch(unavailable);
        });
        card.append(play);
    }
    const link = element('a', mediaType ? 'Yayın bağlantısı' : 'Ayrıntıları aç');
    link.href = url.href;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    const actions = element('p');
    card.append(actions);
    actions.append(link);
}

function renderCard(item, type) {
    const card = element('article', null, 'card');
    card.append(element('h3', item.title));
    if (item.subtitle) card.append(element('p', item.subtitle, 'subtitle'));
    if (item.description) card.append(element('p', item.description));
    if (item.price != null && item.price !== '' && Number.isFinite(Number(item.price))) {
        const currency = /^[A-Z]{3}$/.test(item.currency) ? item.currency : 'TRY';
        const price = new Intl.NumberFormat('tr-TR', {style: 'currency', currency}).format(Number(item.price));
        card.append(element('strong', price));
    }
    addSource(card, item, type);
    return card;
}

function renderFlights() {
    if (config.flightError) section.append(element('p', 'Otomatik uçuş verisi okunamadı.', 'message'));
    for (const [direction, rows] of Object.entries(config.flights || {})) {
        const title = direction === 'arrivals' ? 'Gelen uçuşlar' : 'Giden uçuşlar';
        if (!rows.length) {
            section.append(element('p', title + ' için güncel kayıt bulunamadı.', 'message'));
            continue;
        }
        if (rows.some(row => Number(row.age_seconds) > 900)) {
            section.append(element('p', title + ' listesindeki bazı kayıtlar 15 dakikadan eski.', 'message'));
        }
        const table = element('table');
        table.append(element('caption', title));
        const head = table.createTHead().insertRow();
        for (const title of ['Planlanan', 'Tahmini', 'Uçuş', 'Havalimanı', 'Güzergâh', 'Durum']) {
            const label = element('th', title);
            label.scope = 'col';
            head.append(label);
        }
        const body = table.createTBody();
        for (const flight of rows) {
            const row = body.insertRow();
            for (const value of [flight.scheduled_at, flight.estimated_at, flight.flight_number,
                flight.airport_code, flight.destination, flight.flight_status]) {
                row.insertCell().textContent = value || '—';
            }
        }
        const wrap = element('div', null, 'table-wrap');
        if (guestScreen) {
            wrap.tabIndex = 0;
            wrap.setAttribute('aria-label', title);
        }
        wrap.append(table);
        section.append(wrap);
    }
}

function show(type) {
    tabs.forEach(tab => tab.setAttribute('aria-current', tab.dataset.type === type ? 'page' : 'false'));
    document.getElementById('section-title').textContent = type === 'home' ? 'Hoş geldiniz' : labels[type];
    section.querySelectorAll('audio, video').forEach(player => player.pause());
    section.textContent = '';
    const tiles = element('div', null, 'tiles');

    if (type === 'home') {
        for (const tab of tabs.slice(1)) {
            const tile = element('button', labels[tab.dataset.type], 'card');
            tile.type = 'button';
            tile.addEventListener('click', () => {
                show(tab.dataset.type);
                tab.focus();
            });
            tiles.append(tile);
        }
    } else {
        if (type === 'flights') renderFlights();
        for (const item of config.items[type] || []) tiles.append(renderCard(item, type));
    }
    if (tiles.childElementCount) section.append(tiles);
    if (!section.childElementCount) section.append(element('p', 'Bu bölümde henüz içerik yok.', 'message'));
}

tabs.forEach(tab => tab.addEventListener('click', () => show(tab.dataset.type)));
document.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.defaultPrevented) return;
    const target = event.target;
    if (guestScreen && ['Escape', 'Backspace', 'BrowserBack', 'GoBack', 'Back'].includes(event.key)
        && tabs[0].getAttribute('aria-current') !== 'page') {
        if (document.fullscreenElement) return;
        event.preventDefault();
        show('home');
        section.querySelector('button').focus();
        return;
    }
    if (target.closest && target.closest('.toolbar, audio, video')) return;
    const keys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'];
    if (!keys.includes(event.key)) return;
    if (guestScreen && target.classList && target.classList.contains('table-wrap')
        && ['ArrowDown', 'ArrowUp'].includes(event.key) && target.scrollHeight > target.clientHeight) {
        const down = event.key === 'ArrowDown';
        const end = target.scrollTop + target.clientHeight >= target.scrollHeight - 1;
        if ((down && !end) || (!down && target.scrollTop > 0)) {
            event.preventDefault();
            target.scrollTop += down ? 110 : -110;
            return;
        }
    }
    const controls = tabs.concat(Array.from(section.querySelectorAll('button, a, audio, video, .table-wrap[tabindex]')));
    if (fullscreen && !fullscreen.hidden) controls.unshift(fullscreen);
    const index = controls.indexOf(target);
    if (index < 0 && target !== document.body) return;
    event.preventDefault();
    if (index < 0) {
        tabs.find(tab => tab.getAttribute('aria-current') === 'page').focus();
        return;
    }
    const step = ['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1;
    controls[(index + step + controls.length) % controls.length].focus();
});

function tick() {
    const now = new Date();
    let timezone = config.timezone;
    try {
        new Intl.DateTimeFormat('tr-TR', {timeZone: timezone});
    } catch {
        timezone = 'Europe/Istanbul';
    }
    document.getElementById('clock').textContent = now.toLocaleTimeString('tr-TR',
        {hour: '2-digit', minute: '2-digit', timeZone: timezone});
    document.getElementById('date').textContent = now.toLocaleDateString('tr-TR',
        {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: timezone});
}
show('home');
if (guestScreen) section.querySelector('button').focus();
tick();
setInterval(tick, 30000);
