# Mews demo adaptörü

Geliştirme paketi, evrensel PMS ve 003 migration kurulu izole test ortamı içindir. Üretim bağlantısı ve otomatik konaklama yazımı içermez.

tools/mews_demo_pull.py Python standart kütüphanesini kullanır. Yalnızca resmi Mews demo sunucusunda tesis yapılandırmasını ve varsayılan olarak bir, --pages seçeneğiyle en fazla beş sayfa rezervasyonu okur. Müşteriler için sadece ilgili rezervasyonların kimliklerini sorgular ve çıktı alanlarını ad, soyad ve kimlikle sınırlar. Token'lar HTV_MEWS_DEMO_CLIENT_TOKEN ve HTV_MEWS_DEMO_ACCESS_TOKEN ortam değişkenlerinden alınır. HTTP 429 yanıtında araç Retry-After başlığındaki süreye uyar. Her istek için en fazla iki tekrar yapar. Toplam bekleme sınırı varsayılan 90 saniyedir ve --rate-limit-wait ile en fazla 180 saniye yapılabilir. Geçerli süre yoksa ya da bütçeyi aşıyorsa araç hata verir ve kısmi çıktı üretmez.

pms_mews_demo_snapshot.php, özet sayıları göstermek için bu JSON çıktısını standart girdiden alır. HTV_MEWS_DEMO_ENTERPRISE_ID değişkeni beklenen demo tesisini belirler. Kuyruğa yazmak için izole test ortamında HTV_MEWS_DEMO_ALLOW_QUEUE=1 ve --hotel=ID --connection=ID seçenekleri gerekir. Bu işlem yalnızca ilgili oteldeki Mews API test profiline izin verir. Ardından mevcut pms_event_worker.php kuyruğu işleyebilir. Harici oda kodu Mews AssignedResourceId değeridir.

Resmi ortak demo API'sinden 10 rezervasyon okundu. Dokuz iptal edilmiş kayıt atlandı. Bir çıkış kaydı gerçek demo cevabından çevrilip yerel MariaDB hazırlık tablosuna ulaştı. Aynı kayıt tekrar verildiğinde çift kayıt oluşmadı. Farklı otel için yazma reddedildi. Rezervasyon oluşturma, güncelleme ve giriş eşlemeleri sentetik örneklerle geçti. Sayfalama için kursörün sonraki isteğe geçirilmesi, boş/biten sayfada durma ve yinelenen kursörde işlemin kesilmesi örnek yanıtlarla doğrulandı. Gerçek iki sayfalı deneme ortak demo ortamının HTTP 429 sınırına takıldı. Önceden alınan demo verisi yeni izole veritabanında tekrar işlendi ve çift kayıt oluşmadı. Oda değişikliği, iptal yönetimi, webhook ve üretim Mews erişimi doğrulanmadı.

Resmi belgeler: https://docs.mews.com/connector-api/guidelines/environments
https://docs.mews.com/connector-api/operations/reservations

Retry-After başlığının saniye ve HTTP tarih biçimleri, deneme sınırı ve toplam bekleme bütçesi sentetik yanıtlarla doğrulandı.

Güncelleme doğrulaması: sınırlı bekleme desteği eklendikten sonra Mews ortak demo ortamından iki sayfada 20 farklı rezervasyon ve 20 eşleşen müşteri okundu. 20 kayıt ayrı yerel MariaDB kuyruğunda hazırlık aşamasına ulaştı. Aynı veri ikinci kez gönderildiğinde 20 kayıt tekrar olarak tanındı; yeni kayıt açılmadı. Üretim hesabı veya otomatik konaklama yazımı denenmedi.

## Artımlı demo senkronizasyonu

tools/mews_demo_sync.py mevcut demo okuyucuyu ve PHP kuyruk girişini kullanır. Ayrı Linux test ortamında aynı test bağlantısı için aynı --state ve --start-utc kullanılmalıdır. State dosyasını web kökü dışındaki yazılabilir bir dizinde tutun. --snapshot-command PHP giriş dosyasının yolunu, --php PHP CLI çalıştırıcısını, --hotel ve --connection test profilini belirtir. --start-utc ilk tarama anıdır ve UTC ISO biçimindedir. Mevcut HTV_MEWS_DEMO_* ortam değişkenleri gereklidir.

Mews UpdatedUtc filtresiyle, bir günden uzun olmayan sabit aralıklar işlenir. Başlangıçta önceki sınırdan 30 saniye örtüşme kullanılır ve canlı demo zamanından iki dakika geride kalınır. Araç her çalışmada en fazla --pages kadar sayfa işler. Çıktıda pending=true ise aynı ayarlarla sonraki çalıştırma kaldığı sayfadan sürer. Kuyruk her sayfayı onayladıktan sonra kursör atomik olarak kaydedilir. Ağ kesintisi ya da işleyici yanıtının kaybı halinde son onaylanmış nokta kalır. Çift kayıt kontrolü sayesinde commit edilmiş bir sayfanın tekrar okutulması yeni olay açmaz. Tamamlanan aralık ancak son sayfa onaylanınca ilerler.

Yalnızca demo API test profili ve hazırlık kuyruğu kullanılır. İptal edilmiş kayıtlar ve henüz odaya bağlanmamış ya da kişiye ait olmayan kayıtlar bu sürümün kapsamı dışındadır. Oda atanmış kişisel rezervasyonda müşteri verisi eksikse sayfa ilerletilmez. Oda değişikliği ve webhook üretimi eklenmedi. Otomatik konaklama yazımı yoktur.

Gerçek Mews demo API’sinin UpdatedUtc filtreli isteği 10 kayıt ve bir devam kursörü döndürdü. Kesinti, kuyruk onayı kaybı ve devam testleri, örnek API cevapları ve gerçek izole MariaDB kuyruğu ile yürütüldü. Aynı rezervasyonun oluşturma ve güncelleme olayları aynı harici rezervasyon kimliğine bağlandı. Üretim hesabı, uzun süreli sunucu zamanlaması ve gerçek kesinti bu pakette doğrulanmadı.

## Oda değişikliği doğrulaması

Artımlı araç, son onaylanan rezervasyon sürümünü ve oda eşleştirme anahtarını yerel durum dosyasında tutar. Aynı rezervasyon ve durum için daha yeni bir yanıtta atanan oda değişmişse bir room.changed olayı hazırlanır. İlk okuma, eski sürüm veya aynı sürüm yeniden geldiğinde oda değişikliği üretilmez. Oda ve rezervasyon durumunun aynı güncellemede değişmesi bu sürümde ayrı bir oda değişikliği olarak çıkarılmaz. Durum dosyasını web kökü dışında tutun ve aynı profil için bir durum dosyası kullanın.

Resmi Mews yanıt biçimindeki sentetik rezervasyonlar, mevcut PHP adaptörü, izole MariaDB kuyruğu, yönetici test onayı ve iki eşleştirilmiş oda ekranı uç noktasıyla doğrulandı. Oluşturma → giriş → 101'den 102'ye oda değişikliği → çıkış akışı geçti. Eski oda sürümü tekrar okutulduğunda yeni olay üretilmedi. Bu, Mews resepsiyon ekranında yapılan gerçek işlemin veya üretim PMS erişiminin doğrulandığı anlamına gelmez.
