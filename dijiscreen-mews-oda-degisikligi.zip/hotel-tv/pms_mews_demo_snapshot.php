<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit;
}
require_once __DIR__ . '/pms/mews_snapshot.php';

// Input is a bounded JSON envelope produced by the Mews demo client.
// Without --connection, the command validates and counts without opening a database.
$options = getopt('', ['connection:', 'hotel:']);
try {
    $raw = stream_get_contents(STDIN, 1048577);
    if (!is_string($raw) || strlen($raw) > 1048576) throw new InvalidArgumentException('Girdi sınırı 1 MiB.');
    $snapshot = json_decode($raw, true, 48, JSON_THROW_ON_ERROR);
    if (!is_array($snapshot) || !is_string($snapshot['EnterpriseId'] ?? null)
        || !is_array($snapshot['Reservations'] ?? null) || !is_array($snapshot['Customers'] ?? null)
        || (isset($snapshot['RoomMoves']) && !is_array($snapshot['RoomMoves']))) {
        throw new InvalidArgumentException('EnterpriseId, Reservations ve Customers gerekli.');
    }
    $expectedEnterprise = getenv('HTV_MEWS_DEMO_ENTERPRISE_ID');
    if (!$expectedEnterprise || $expectedEnterprise !== $snapshot['EnterpriseId']) {
        throw new InvalidArgumentException('Girdi yapılandırılmış Mews demo tesisiyle eşleşmiyor.');
    }
    $result = htv_pms_mews_snapshot($expectedEnterprise, $snapshot['Reservations'], $snapshot['Customers'], $snapshot['RoomMoves'] ?? []);
    $counts = ['normalized'=>count($result['events']), 'skipped'=>$result['skipped']];
    if (isset($options['connection']) || isset($options['hotel'])) {
        $hotel = filter_var($options['hotel'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        $id = filter_var($options['connection'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        if (!$id || !$hotel || getenv('HTV_MEWS_DEMO_ALLOW_QUEUE') !== '1') {
            throw new InvalidArgumentException('Kuyruk için test izni, otel ve bağlantı kimliği gerekli.');
        }
        require dirname(__DIR__, 2) . '/app/bootstrap.php';
        require_once __DIR__ . '/pms/inbox.php';
        $connection = htv_pms_connection($pdo, $id, $hotel);
        if (!htv_pms_can_receive($connection, 'api') || $connection['provider_code'] !== 'mews'
            || $connection['status'] !== 'testing') {
            throw new InvalidArgumentException('Seçili otelin Mews API test profili gerekli.');
        }
        if ($counts['normalized']) $counts += htv_pms_queue($pdo, $connection, $result['events']);
    }
    echo json_encode($counts, JSON_THROW_ON_ERROR) . PHP_EOL;
} catch (InvalidArgumentException | DomainException | JsonException $ex) {
    fwrite(STDERR, $ex->getMessage() . PHP_EOL);
    exit(1);
} catch (Throwable $ex) {
    fwrite(STDERR, "Mews demo kayıtları işlenemedi. Test yapılandırmasını kontrol edin.\n");
    exit(1);
}
