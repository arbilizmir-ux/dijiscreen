"""Resume a Mews demo import into a DijiScreen test queue. Linux only."""

import argparse
from datetime import datetime, timedelta, timezone
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from urllib.error import HTTPError

from mews_demo_pull import demo_reader, reservation_page, snapshot_for_rows

OVERLAP = timedelta(seconds=30)
PROVIDER_LAG = timedelta(minutes=2)


def utc(value):
    parsed = datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    if iso(parsed) != value:
        raise ValueError("Invalid UTC timestamp")
    return parsed


def iso(value):
    return value.strftime("%Y-%m-%dT%H:%M:%SZ")


def save(path, state):
    with tempfile.NamedTemporaryFile("w", dir=path.parent, prefix=path.name + ".", delete=False) as output:
        temporary = Path(output.name)
        try:
            json.dump(state, output)
            output.flush()
            os.fsync(output.fileno())
            os.replace(temporary, path)
            directory = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        finally:
            if temporary.exists():
                temporary.unlink()


def room_versions(prior, reservations):
    changes = {}
    moves = {}
    seen = set()
    for row in reservations:
        reservation = row.get("Id")
        room = row.get("AssignedResourceId")
        updated = row.get("UpdatedUtc")
        status = row.get("State")
        if (row.get("AccountType") != "Customer" or status not in ("Confirmed", "Started", "Processed")
                or not all(isinstance(v, str) and v for v in (reservation, room, updated))):
            continue
        if reservation in seen:
            raise ValueError("Duplicate reservation identity in Mews page")
        seen.add(reservation)
        if not updated.endswith("Z"):
            raise ValueError("Mews update must be UTC")
        # Normalize fractional formatting before comparing snapshots.
        version = datetime.fromisoformat(updated).isoformat(timespec="microseconds")
        previous = prior.get(reservation)
        if previous and previous["updated"] >= version:
            continue
        if previous and previous["status"] == status and status != "Processed" and previous["room"] != room:
            moves[reservation] = previous["room"]
        changes[reservation] = {"updated": version, "status": status, "room": room}
    return changes, moves


def run(state_path, scope, start, now, pages, read, enqueue):
    summary = {"pages": 0, "queued": 0, "duplicates": 0, "skipped": 0, "room_changes": 0}
    enterprise = read("configuration/get", {})["Enterprise"]["Id"]
    if enterprise != scope["enterprise"]:
        raise ValueError("Mews demo property mismatch")
    if state_path.exists():
        state = json.loads(state_path.read_text())
        if state.get("scope") != scope:
            raise ValueError("State belongs to another test profile")
    else:
        state = {"scope": scope, "completed_through": iso(start), "active": None}
    room_history = state.setdefault("room_history", {})
    active = state["active"]
    if active is None:
        completed = utc(state["completed_through"])
        end = min(now - PROVIDER_LAG, completed + timedelta(days=1))
        if end <= completed:
            return {**summary, "completed_through": iso(completed), "pending": False}
        active = {"start": iso(max(start, completed - OVERLAP)), "end": iso(end), "cursors": []}
        state["active"] = active
        save(state_path, state)

    for _ in range(pages):
        cursors = active["cursors"]
        batch, next_cursor = reservation_page(read, enterprise, cursors[-1] if cursors else None,
                                                (active["start"], active["end"]))
        if next_cursor is not None and (next_cursor in cursors or len(cursors) >= 10000):
            raise ValueError("Repeated Mews cursor or cursor limit reached")
        if batch:
            snapshot = snapshot_for_rows(read, enterprise, batch, require_customer=True)
            changes, moves = room_versions(room_history, snapshot["Reservations"])
            # Equal-version overlap rows are already acknowledged, including moves.
            fresh_rows = [row for row in snapshot["Reservations"] if row.get("Id") not in room_history
                          or row.get("Id") in changes]
            if fresh_rows:
                snapshot["Reservations"] = fresh_rows
                snapshot["RoomMoves"] = moves
                result = enqueue(snapshot)
                for key in ("queued", "duplicates", "skipped"):
                    summary[key] += result.get(key, 0)
                summary["room_changes"] += len(moves)
                room_history.update(changes)
        summary["pages"] += 1
        if next_cursor is None:
            state["completed_through"] = active["end"]
            state["active"] = None
            save(state_path, state)
            break
        cursors.append(next_cursor)
        save(state_path, state)
    return {**summary, "completed_through": state["completed_through"], "pending": state["active"] is not None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--snapshot-command", type=Path, required=True, help="Path to pms_mews_demo_snapshot.php")
    parser.add_argument("--php", default="php")
    parser.add_argument("--hotel", type=int, required=True)
    parser.add_argument("--connection", type=int, required=True)
    parser.add_argument("--start-utc", required=True, help="First scan time, YYYY-MM-DDTHH:MM:SSZ")
    parser.add_argument("--pages", choices=range(1, 6), type=int, default=2)
    parser.add_argument("--rate-limit-wait", type=int, default=90)
    args = parser.parse_args()
    if args.hotel < 1 or args.connection < 1 or not 0 <= args.rate_limit_wait <= 180:
        parser.error("Invalid hotel, connection or wait limit")
    if os.environ.get("HTV_MEWS_DEMO_ALLOW_QUEUE") != "1":
        parser.error("Test queue authorization required")
    enterprise = os.environ["HTV_MEWS_DEMO_ENTERPRISE_ID"]
    start = utc(args.start_utc)
    target = args.snapshot_command.resolve(strict=True)
    scope = {"enterprise": enterprise, "hotel": args.hotel, "connection": args.connection,
             "snapshot": str(target), "start": iso(start)}

    def enqueue(snapshot):
        child = subprocess.run(
            [args.php, str(target), f"--hotel={args.hotel}", f"--connection={args.connection}"],
            input=json.dumps(snapshot), text=True, capture_output=True, timeout=30,
        )
        if child.returncode:
            raise RuntimeError("Test queue did not confirm the page")
        result = json.loads(child.stdout)
        if any(type(result.get(key)) is not int or result[key] < 0 for key in ("normalized", "skipped")):
            raise ValueError("Invalid test queue acknowledgement")
        accepted = result.get("queued", 0)
        duplicates = result.get("duplicates", 0)
        if type(accepted) is not int or type(duplicates) is not int or min(accepted, duplicates) < 0:
            raise ValueError("Invalid test queue counters")
        if accepted + duplicates != result["normalized"] or result["normalized"] + result["skipped"] != len(snapshot["Reservations"]):
            raise ValueError("Incomplete test queue acknowledgement")
        return result

    path = args.state.resolve()
    lock = os.open(path.with_name(path.name + ".lock"), os.O_CREAT | os.O_RDWR, 0o600)
    with os.fdopen(lock, "w") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        print(json.dumps(run(path, scope, start, datetime.now(timezone.utc), args.pages,
                             demo_reader([args.rate_limit_wait]), enqueue)))


if __name__ == "__main__":
    try:
        main()
    except BlockingIOError:
        print("Mews demo eşitlemesi bu test profili için zaten çalışıyor.", file=sys.stderr)
        sys.exit(1)
    except HTTPError as error:
        print(f"Mews demo HTTP {error.code}. İlerleme noktası korunuyor.", file=sys.stderr)
        sys.exit(1)
    except (OSError, KeyError, RuntimeError, TypeError, ValueError, subprocess.SubprocessError):
        print("Mews demo eşitlemesi tamamlanamadı. Son onaylanan ilerleme noktası korunuyor.", file=sys.stderr)
        sys.exit(1)
