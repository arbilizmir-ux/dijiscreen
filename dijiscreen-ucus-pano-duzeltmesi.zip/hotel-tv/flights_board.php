<?php
declare(strict_types=1);
require dirname(__DIR__,2).'/app/bootstrap.php';require_once __DIR__ . '/hotel_access.php';
htv_require_manager();
require_once __DIR__.'/flights_common.php';

$hotel=(int)($_GET['hotel_id']??0);$direction=(string)($_GET['direction']??'departures');if(!in_array($direction,['departures','arrivals'],true))$direction='departures';
htv_require_hotel($pdo,$hotel);
$settings = null;
$rows = [];
$error = '';
try {
    $settings = htvf_settings($pdo, $hotel);
    $codes = htvf_codes((string) ($settings['airport_codes'] ?? ''));
    if ($codes) {
        $placeholders = implode(',', array_fill(0, count($codes), '?'));
        $query = $pdo->prepare(
            "SELECT airport_code, flight_number, destination, scheduled_at, estimated_at, flight_status, fetched_at
             FROM hotel_flight_cache
             WHERE hotel_id = ? AND direction = ? AND airport_code IN ($placeholders)
               AND scheduled_at BETWEEN NOW() - INTERVAL 3 HOUR AND NOW() + INTERVAL 36 HOUR
             ORDER BY scheduled_at LIMIT 150"
        );
        $query->execute(array_merge([$hotel, $direction], $codes));
        $rows = $query->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {
    $error = 'Veritabanı okunamadı.';
    error_log('[HTV flights board] ' . $e->getMessage());
}
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta http-equiv="refresh" content="120"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hotel TV · Uçuşlar</title><style>body{font-family:system-ui;background:#071321;color:#f3f5fa;margin:0}main{max-width:1200px;margin:30px auto;padding:0 24px}h1{color:#d5b36a;font-size:36px}a{color:#d5b36a;margin-right:20px}table{width:100%;border-collapse:collapse;font-size:21px}td,th{text-align:left;padding:18px 12px;border-bottom:1px solid #28384d}th{color:#d5b36a}p{color:#b8c5d7}.warn{color:#ffc5a5}@media(max-width:600px){table{font-size:14px}td,th{padding:10px 4px}}</style></head><body><main><p><a href="flights_admin.php?hotel_id=<?=$hotel?>">← Yönetim</a><a href="?hotel_id=<?=$hotel?>&amp;direction=departures">Giden</a><a href="?hotel_id=<?=$hotel?>&amp;direction=arrivals">Gelen</a></p><h1>✈ <?= $direction==='departures'?'Giden Uçuşlar':'Gelen Uçuşlar' ?></h1><p><?=htvf_e($settings['city']??'İl seçilmedi')?> · <?=htvf_e($settings['airport_codes']??'')?></p><?php if($error):?><p class="warn"><?=htvf_e($error)?></p><?php endif;?><?php if(!$settings):?><p>Bu otel için uçuş ayarları bulunamadı.</p><?php elseif(!$rows):?><p>Henüz doğrulanmış uçuş verisi alınmadı. API sağlayıcısını ve cron görevini kontrol edin.</p><?php else:?><p>Son veri alımı: <?=htvf_e(max(array_column($rows,'fetched_at')))?> (sunucu saati)</p><?php if(strtotime(max(array_column($rows,'fetched_at')))<time()-900):?><p class="warn">Dikkat: Veriler 15 dakikadan eski olabilir.</p><?php endif;?><table><thead><tr><th>Saat</th><th>Uçuş</th><th>Havalimanı</th><th>Güzergâh</th><th>Durum</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=htvf_e(substr((string)$r['scheduled_at'],11,5))?></td><td><?=htvf_e($r['flight_number'])?></td><td><?=htvf_e($r['airport_code'])?></td><td><?=htvf_e($r['destination'])?></td><td><?=htvf_e($r['flight_status'])?></td></tr><?php endforeach;?></tbody></table><?php endif;?></main></body></html>
